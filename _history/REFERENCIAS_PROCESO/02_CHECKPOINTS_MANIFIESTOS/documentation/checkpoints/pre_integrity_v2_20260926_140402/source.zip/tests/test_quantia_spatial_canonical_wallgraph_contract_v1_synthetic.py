from __future__ import annotations

import numpy as np

from app.quantia_spatialV1.adaptive_reconstruction.contracts import (
    AdaptiveReconstructionRuntime,
    AdaptiveRoutePlan,
    LogicalGap,
    ModuleDecision,
    PhysicalWallTrack,
    ReconstructionDiagnostics,
    SingleLineWall,
    SingleLineWallGraph,
    SpaceTopology,
)
from app.quantia_spatialV1.canonical_wallgraph import CanonicalWallGraphFinalizer
from app.quantia_spatialV1.models.level_view import LevelView, LevelViewTransform, PixelBBox
from app.quantia_spatialV1.post_reconstruction_filters.contracts import (
    CanonicalWallMapping,
    FilterDecision,
    PostFilterDiagnostics,
    PostFilterPlan,
    PostReconstructionFilterResult,
)


def _route() -> AdaptiveRoutePlan:
    modules = [
        ModuleDecision(module="F03_STRUCTURAL_SEED", enabled=True, reason="synthetic"),
        ModuleDecision(module="CONTEXT_NEGATIVE_MASK", enabled=False, reason="synthetic"),
        ModuleDecision(module="WALL_MASK_RECOVERY", enabled=True, reason="synthetic"),
        ModuleDecision(module="WALL_CANONICALIZATION", enabled=True, reason="synthetic"),
        ModuleDecision(module="STRICT_CONNECTIVITY", enabled=True, reason="synthetic"),
        ModuleDecision(module="ROOM_TOPOLOGY", enabled=True, reason="synthetic"),
        ModuleDecision(module="MULTIMODAL_CALL2", enabled=False, reason="synthetic"),
    ]
    return AdaptiveRoutePlan(mode="BALANCED", modules=modules, recovery_strength=0.6)


def _wall(wall_id: str, start: tuple[float, float], end: tuple[float, float]) -> SingleLineWall:
    return SingleLineWall(
        id=wall_id,
        start_px=start,
        end_px=end,
        thickness_px=10.0,
        role="REVIEW",
        confidence=0.8,
        source_candidate_ids=[f"C_{wall_id}"],
        evidence_ids=[],
        source_names=["SYNTHETIC"],
        f03_seed_protected=True,
    )


def _track(wall: SingleLineWall) -> PhysicalWallTrack:
    dx = wall.end_px[0] - wall.start_px[0]
    dy = wall.end_px[1] - wall.start_px[1]
    return PhysicalWallTrack(
        wall_id=wall.id,
        start=wall.start_px,
        end=wall.end_px,
        length_px=(dx * dx + dy * dy) ** 0.5,
        thickness_px=wall.thickness_px,
        confidence=wall.confidence,
        source_candidate_ids=tuple(wall.source_candidate_ids),
        evidence_ids=(),
        source_names=("SYNTHETIC",),
        region_support=0.9,
        thickness_support=0.9,
        vector_support=0.9,
        raster_line_support=0.9,
        source_consensus=0.9,
        axis_support=0.0,
        dashed_penalty=0.0,
    )


def test_finalizer_rebuilds_relations_and_contract() -> None:
    walls = [
        _wall("W1", (40, 40), (160, 40)),
        _wall("W2", (160, 40), (160, 160)),
        _wall("W3", (160, 160), (40, 160)),
        _wall("W4", (40, 160), (40, 40)),
    ]
    diagnostics = ReconstructionDiagnostics(
        level_view_id="LV1",
        f03_seed_count=4,
        discovered_candidate_count=4,
        quarantined_candidate_count=0,
        hybrid_candidate_count=4,
        selected_wall_count=99,  # deliberadamente obsoleto
        component_count=9,
        junction_count=0,
        virtual_bridge_count=1,
        interior_space_count=0,
        review_wall_count=99,
        perimeter_wall_count=0,
        divider_wall_count=0,
        seed_coverage_ratio=1.0,
        quarantine_ratio=0.0,
        review_ratio=1.0,
    )
    adaptive_graph = SingleLineWallGraph(
        level_view_id="LV1",
        level_name="Synthetic",
        image_size_px=(200, 200),
        px_per_m=100.0,
        walls=walls,
        logical_gaps=[
            LogicalGap(
                id="STALE",
                kind="OLD",
                start_px=(0, 0),
                end_px=(1, 1),
                gap_px=1.4,
                wall_ids=["W1", "REMOVED_WALL"],
            )
        ],
        interior_space_count=0,
        route_plan=_route(),
        diagnostics=diagnostics,
    )
    runtime = AdaptiveReconstructionRuntime(
        graph=adaptive_graph,
        wall_tracks=[_track(wall) for wall in walls],
        bridges=[],
        topology=SpaceTopology(
            labels=np.zeros((200, 200), dtype=np.int32),
            exterior_labels=frozenset(),
            interior_labels=frozenset(),
            areas_px2={},
        ),
        context_quarantined_count=0,
        artifacts={},
    )
    decisions = [
        FilterDecision(
            source_wall_id=wall.id,
            output_class="WALL",
            included_in_wallgraph=True,
            confidence=0.9,
            source_candidate_ids=wall.source_candidate_ids,
        )
        for wall in walls
    ]
    post = PostReconstructionFilterResult(
        level_view_id="LV1",
        plan=PostFilterPlan(),
        decisions=decisions,
        filtered_wall_graph=adaptive_graph,
        canonical_mapping=[
            CanonicalWallMapping(
                canonical_wall_id=wall.id,
                source_wall_ids=[wall.id],
                source_candidate_ids=wall.source_candidate_ids,
                reason="single_hypothesis",
            )
            for wall in walls
        ],
        diagnostics=PostFilterDiagnostics(
            input_wall_count=4,
            wall_class_count=4,
            architectural_element_count=0,
            excluded_graphic_count=0,
            unresolved_count=0,
            canonical_wall_count=4,
            collapsed_hypothesis_count=0,
        ),
    )
    level = LevelView(
        id="LV1",
        level_name="Synthetic",
        source_document_id="DOC",
        source_page_number=1,
        source_bbox_px=PixelBBox(x_min=0, y_min=0, x_max=200, y_max=200),
        source_page_width_px=200,
        source_page_height_px=200,
        raster_width_px=200,
        raster_height_px=200,
        raster_mime_type="image/png",
        raster_bytes=b"synthetic",
        transform=LevelViewTransform(
            offset_x_px=0,
            offset_y_px=0,
            source_page_width_px=200,
            source_page_height_px=200,
            local_width_px=200,
            local_height_px=200,
        ),
        state="DETECTADO",
    )

    result = CanonicalWallGraphFinalizer().finalize(
        level_view=level,
        evidence=[],
        runtime=runtime,
        post_filter=post,
    )

    assert result.integrity.valid is True
    assert result.integrity.invalid_gap_reference_count == 0
    assert result.graph.diagnostics.selected_wall_count == len(result.graph.walls) == 4
    assert result.graph.diagnostics.review_wall_count == sum(w.role == "REVIEW" for w in result.graph.walls)
    assert result.graph.diagnostics.perimeter_wall_count == sum(w.role == "PERIMETER" for w in result.graph.walls)
    assert result.graph.diagnostics.divider_wall_count == sum(w.role == "DIVIDER" for w in result.graph.walls)
    assert result.graph.diagnostics.interior_space_count == result.graph.interior_space_count
    assert all("REMOVED_WALL" not in gap.wall_ids for gap in result.graph.logical_gaps)
    assert result.audit["post_filter_wall_geometry_unchanged"] is True
    assert result.evidence_bundle.final_wall_ids == [wall.id for wall in result.graph.walls]
