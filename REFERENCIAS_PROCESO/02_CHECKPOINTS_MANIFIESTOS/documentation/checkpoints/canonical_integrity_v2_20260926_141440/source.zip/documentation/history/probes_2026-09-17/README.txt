PROBES HISTÓRICOS — NO SUITE ACTIVA

Estos archivos se preservan como evidencia de evolución y comparación. No deben usarse como fuente de lógica productiva ni ejecutarse en la suite activa salvo investigación histórica explícita.

La lógica vigente está en:
- adaptive_reconstruction/
- post_reconstruction_filters/
- process_engine.py
- reconstruction_core/
- architectural_elements/
