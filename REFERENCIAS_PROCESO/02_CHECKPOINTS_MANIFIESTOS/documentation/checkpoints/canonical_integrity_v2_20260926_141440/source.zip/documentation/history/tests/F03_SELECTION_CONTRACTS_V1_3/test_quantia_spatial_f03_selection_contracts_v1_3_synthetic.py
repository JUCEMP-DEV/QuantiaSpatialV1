from __future__ import annotations

from app.quantia_spatialV1.reconstruction_core.candidate_context_gate import CandidateContextGate
from app.quantia_spatialV1.reconstruction_core.candidate_models import WallCandidate, WallEvidenceVector
from app.quantia_spatialV1.reconstruction_core.context_models import ContextRegion, RepetitiveAxisProfile
from app.quantia_spatialV1.reconstruction_core.drawing_model import DrawingBBox, DrawingPoint


def _candidate(
    candidate_id: str,
    *,
    x1: float,
    y1: float,
    x2: float,
    y2: float,
    thickness: float = 12.0,
    metadata: dict | None = None,
) -> WallCandidate:
    dx, dy = x2 - x1, y2 - y1
    angle = 0.0 if abs(dy) < 1e-9 else 90.0 if abs(dx) < 1e-9 else 45.0
    return WallCandidate(
        id=candidate_id,
        generator="DOUBLE_FACE",
        start=DrawingPoint(x=x1, y=y1),
        end=DrawingPoint(x=x2, y=y2),
        angle_deg=angle,
        length_px=(dx * dx + dy * dy) ** 0.5,
        thickness_px=thickness,
        face_ids=[f"{candidate_id}_A", f"{candidate_id}_B"],
        evidence_ids=[],
        source_names=["LSD_LOCAL", "OPENCV"],
        evidence=WallEvidenceVector(
            pair_overlap=0.96,
            thickness_support=0.88,
            vector_support=0.0,
            raster_line_support=1.0,
            region_support=0.94,
            source_consensus=0.50,
            perimeter_containment=1.0,
            semantic_support=0.0,
            axis_support=0.35,
            dashed_penalty=0.0,
        ),
        prior_score=0.78,
        metadata=metadata or {
            "metric_thickness_support": 1.0,
            "metric_slenderness_support": 1.0,
            "metric_wall_band_support": 1.0,
        },
    )


def _stair_region(*, include_candidate_faces: bool = False) -> ContextRegion:
    member_ids = [f"S{i}" for i in range(6)]
    if include_candidate_faces:
        member_ids += ["SIDE_WALL_A", "SIDE_WALL_B"]
    return ContextRegion(
        id="STAIR",
        region_type="STAIR_FLIGHT_REGION",
        bbox=DrawingBBox(x_min=45, y_min=45, x_max=250, y_max=205),
        confidence=0.90,
        quarantine_enabled=True,
        profiles=[
            RepetitiveAxisProfile(
                angle_deg=0.0,
                spacing_px=20.0,
                spacing_cv=0.02,
                member_count=6,
                median_length_px=180.0,
                common_span_ratio=0.95,
                length_similarity=0.95,
                track_coordinates=[70, 90, 110, 130, 150, 170],
                member_line_ids=member_ids,
            )
        ],
        member_line_ids=member_ids,
        metadata={
            "pattern_segments": [
                [52.0, 70.0, 230.0, 70.0],
                [52.0, 90.0, 230.0, 90.0],
                [52.0, 110.0, 230.0, 110.0],
                [52.0, 130.0, 230.0, 130.0],
                [52.0, 150.0, 230.0, 150.0],
                [52.0, 170.0, 230.0, 170.0],
            ]
        },
    )


def test_perpendicular_wall_receiving_repetitive_tracks_is_review_not_quarantine() -> None:
    candidate = _candidate("SIDE_WALL", x1=50, y1=55, x2=50, y2=190)
    region = _stair_region(include_candidate_faces=True)
    decision = CandidateContextGate().apply(candidates=[candidate], regions=[region]).decisions[0]
    assert decision.metadata["region_boundary_support"] >= 0.62
    assert decision.metadata["pattern_pair_support"] < 0.45
    assert decision.state == "REVIEW"


def test_perpendicular_line_inside_repetitive_tracks_remains_quarantined() -> None:
    candidate = _candidate("INNER_LINE", x1=150, y1=55, x2=150, y2=190)
    region = _stair_region()
    decision = CandidateContextGate().apply(candidates=[candidate], regions=[region]).decisions[0]
    assert decision.metadata["region_boundary_support"] < 0.62
    assert decision.state == "QUARANTINE"


def test_pattern_member_on_floor_boundary_is_not_lost_only_for_member_id() -> None:
    candidate = _candidate("FLOOR_WALL", x1=50, y1=50, x2=250, y2=50)
    region = ContextRegion(
        id="FLOOR",
        region_type="FLOOR_FINISH_GRID_REGION",
        bbox=DrawingBBox(x_min=45, y_min=45, x_max=255, y_max=150),
        confidence=0.96,
        quarantine_enabled=True,
        profiles=[],
        member_line_ids=["FLOOR_WALL_A", "FLOOR_WALL_B"],
        metadata={
            "pattern_segments": [
                [50.0, 64.0, 250.0, 64.0],
                [50.0, 78.0, 250.0, 78.0],
                [50.0, 92.0, 250.0, 92.0],
            ]
        },
    )
    decision = CandidateContextGate().apply(candidates=[candidate], regions=[region]).decisions[0]
    assert decision.face_pattern_support >= 0.50
    assert decision.metadata["region_boundary_support"] >= 0.60
    assert decision.state == "REVIEW"
    assert decision.reason in {
        "REVIEW_PATTERN_MEMBER_BOUNDARY_WALL_CANDIDATE",
        "REVIEW_FLOOR_REGION_BOUNDARY_WALL_CANDIDATE",
    }


def test_profile_aligned_boundary_wall_overrides_pattern_derived_quarantine_only_to_review() -> None:
    candidate = _candidate("PROFILE_WALL", x1=50, y1=50, x2=250, y2=50)
    profile = RepetitiveAxisProfile(
        angle_deg=0.0,
        spacing_px=14.0,
        spacing_cv=0.03,
        member_count=6,
        median_length_px=200.0,
        common_span_ratio=0.95,
        length_similarity=0.95,
        track_coordinates=[50, 64, 78, 92, 106, 120],
        member_line_ids=["PROFILE_WALL_A", "PROFILE_WALL_B", "P1", "P2", "P3", "P4"],
    )
    region = ContextRegion(
        id="FLOOR_PROFILE",
        region_type="FLOOR_FINISH_GRID_REGION",
        bbox=DrawingBBox(x_min=45, y_min=45, x_max=255, y_max=130),
        confidence=0.96,
        quarantine_enabled=True,
        profiles=[profile],
        member_line_ids=list(profile.member_line_ids),
        metadata={
            "pattern_segments": [
                [50.0, 64.0, 250.0, 64.0],
                [50.0, 78.0, 250.0, 78.0],
                [50.0, 92.0, 250.0, 92.0],
                [50.0, 106.0, 250.0, 106.0],
            ]
        },
    )
    decision = CandidateContextGate().apply(candidates=[candidate], regions=[region]).decisions[0]
    assert decision.metadata["region_boundary_support"] >= 0.62
    assert decision.state == "REVIEW"
    assert decision.reason.startswith("REVIEW_PATTERN_BOUNDARY_WALL_OVER_")
