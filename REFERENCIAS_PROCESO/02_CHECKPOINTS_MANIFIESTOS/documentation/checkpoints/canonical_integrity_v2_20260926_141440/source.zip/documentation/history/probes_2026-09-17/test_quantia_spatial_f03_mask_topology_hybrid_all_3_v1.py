from __future__ import annotations

import json
import math
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

import cv2
import numpy as np
import pytest
from shapely.geometry import LineString, Point, box

from app.quantia_spatialV1.reconstruction_core import ProposalCReconstructionPipeline
from app.quantia_spatialV1.reconstruction_core.candidate_models import WallCandidate
from app.quantia_spatialV1.reconstruction_core.wall_track_consolidator import WallTrackConsolidator
from app.quantia_spatialV1.tests.quantia_case_loader import CASE_LOADERS, LoadedCase
from app.quantia_spatialV1.tests.test_quantia_spatial_perimeter_wall_tracks_all_3_v2 import (
    _decode,
    _draw_segment,
    _physical_walls,
    _safe,
    _wall_draw_thickness,
)


PROBE_VERSION = "F03_MASK_TOPOLOGY_HYBRID_ALL_3_V1"
BASELINE = (
    "F03_ARCHITECTURAL_CORE_VISUAL_V1 + "
    "CONTEXT_GATE_V5/V6_2 + "
    "WALL_CANONICALIZATION_ISOLATED_V1 + "
    "WALL_MASK_RECONSTRUCTION_V1"
)
CASE_IDS = ("casa_viri", "miguel_h", "miguel_v")
TARGET_PX_PER_M = 90.0
TARGET_RELATIVE_TOLERANCE = 0.05

TESTS_DIR = Path(__file__).resolve().parent
OUTPUT_ROOT = TESTS_DIR / "output" / "f03_mask_topology_hybrid_v1"


@dataclass(frozen=True)
class _VirtualBridge:
    bridge_id: str
    kind: str
    start: tuple[float, float]
    end: tuple[float, float]
    gap_px: float
    wall_ids: tuple[str, ...]
    protected_by_seed: bool


@dataclass(frozen=True)
class _SpaceTopology:
    labels: np.ndarray
    exterior_labels: frozenset[int]
    interior_labels: frozenset[int]
    areas_px2: dict[int, int]


@dataclass(frozen=True)
class _WallRole:
    wall_id: str
    role: str
    confidence: float
    perimeter_votes: int
    divider_votes: int
    review_votes: int
    left_labels: tuple[int, ...]
    right_labels: tuple[int, ...]


# OBJETIVO
# -------
# Probar la fusión de las lógicas que ya demostraron valor en pruebas previas:
#   1) F03 selected walls = structural seed protegido.
#   2) Context Gate = limpieza negativa de cotas/ejes gráficos/hatch/baldosas.
#   3) Candidate Discovery sin usar F02 como fuente de muro y SIN penalizar
#      axis_support (un muro puede estar correctamente alineado con un eje).
#   4) WallMask + conectividad conservadora + topología de espacios.
#   5) PERIMETER/DIVIDER se decide por adyacencia espacial, no por footprint.
#
# F02 se usa solo para escala/proyección del pipeline existente; su perímetro no
# se incorpora como seed de muro ni se considera verdad final de geometría.


def _line(candidate_or_wall) -> LineString:
    start = candidate_or_wall.start
    end = candidate_or_wall.end
    if hasattr(start, "x"):
        return LineString([(float(start.x), float(start.y)), (float(end.x), float(end.y))])
    return LineString([(float(start[0]), float(start[1])), (float(end[0]), float(end[1]))])


def _point_tuple(value) -> tuple[float, float]:
    if hasattr(value, "x"):
        return float(value.x), float(value.y)
    return float(value[0]), float(value[1])


def _vector(wall) -> tuple[float, float, float]:
    x1, y1 = _point_tuple(wall.start)
    x2, y2 = _point_tuple(wall.end)
    dx = x2 - x1
    dy = y2 - y1
    length = max(math.hypot(dx, dy), 1e-9)
    ux, uy = dx / length, dy / length
    if ux < -1e-9 or (abs(ux) <= 1e-9 and uy < 0.0):
        ux, uy = -ux, -uy
    return ux, uy, length


def _angle_deg(wall) -> float:
    ux, uy, _ = _vector(wall)
    return math.degrees(math.atan2(uy, ux)) % 180.0


def _angle_diff(a: float, b: float) -> float:
    diff = abs((a - b) % 180.0)
    return min(diff, 180.0 - diff)


def _interval(wall, ux: float, uy: float) -> tuple[float, float]:
    start = _point_tuple(wall.start)
    end = _point_tuple(wall.end)
    values = (
        start[0] * ux + start[1] * uy,
        end[0] * ux + end[1] * uy,
    )
    return min(values), max(values)


def _normal_offset(wall, ux: float, uy: float) -> float:
    nx, ny = -uy, ux
    start = _point_tuple(wall.start)
    end = _point_tuple(wall.end)
    mx = (start[0] + end[0]) * 0.5
    my = (start[1] + end[1]) * 0.5
    return mx * nx + my * ny


def _candidate_overlap_ratio(first: WallCandidate, second: WallCandidate) -> float:
    ux, uy, _ = _vector(first)
    a0, a1 = _interval(first, ux, uy)
    b0, b1 = _interval(second, ux, uy)
    overlap = max(0.0, min(a1, b1) - max(a0, b0))
    denom = max(1e-6, min(a1 - a0, b1 - b0))
    return max(0.0, min(1.0, overlap / denom))


def _seed_match(candidate, seed, *, px_per_m: float) -> bool:
    if _angle_diff(_angle_deg(candidate), _angle_deg(seed)) > 5.0:
        return False
    distance = float(_line(candidate).distance(_line(seed)))
    thickness = max(
        float(getattr(candidate, "thickness_px", 0.0) or 0.0),
        float(getattr(seed, "thickness_px", 0.0) or 0.0),
        0.10 * px_per_m,
    )
    if distance > max(0.16 * px_per_m, 1.2 * thickness):
        return False
    overlap = _candidate_overlap_ratio(candidate, seed)
    if overlap >= 0.20:
        return True
    endpoint_distance = min(
        Point(_point_tuple(candidate.start)).distance(_line(seed)),
        Point(_point_tuple(candidate.end)).distance(_line(seed)),
        Point(_point_tuple(seed.start)).distance(_line(candidate)),
        Point(_point_tuple(seed.end)).distance(_line(candidate)),
    )
    return endpoint_distance <= 0.18 * px_per_m


def _discover_without_f02_perimeter(*, pipeline, full, scale_profile) -> list[WallCandidate]:
    drawing = full.drawing_model
    generator = pipeline.candidate_generator
    constraints = full.reference_constraints
    mask = generator._mask(drawing)
    face_lines = [item for item in drawing.lines if item.kind == "LINE"]
    region_lines = [item for item in drawing.lines if item.kind == "REGION_CENTERLINE"]
    representatives = generator._representative_lines(face_lines, drawing=drawing)
    profiles = generator._thickness_profiles(representatives, drawing=drawing)

    # Polígono neutro del LevelView completo. No representa el edificio; solo evita
    # usar F02 como condición de existencia de un muro durante Candidate Discovery.
    neutral_polygon = box(-4.0, -4.0, drawing.width_px + 4.0, drawing.height_px + 4.0)

    candidates = generator._double_face_candidates(
        drawing=drawing,
        lines=representatives,
        thickness_profiles=profiles,
        perimeter_polygon_geom=neutral_polygon,
        wall_region_mask=mask,
        constraints=constraints,
    )
    candidates.extend(
        generator._region_candidates(
            drawing=drawing,
            region_lines=region_lines,
            face_lines=representatives,
            thickness_profiles=profiles,
            perimeter_polygon_geom=neutral_polygon,
            wall_region_mask=mask,
            constraints=constraints,
        )
    )
    candidates = generator._dedupe_candidates(candidates)
    candidates = WallTrackConsolidator().consolidate(
        candidates=candidates,
        width_px=drawing.width_px,
        height_px=drawing.height_px,
    )
    # Reutiliza la parametrización métrica F03, pero NO modifica axis_support ni lo
    # convierte en penalización. axis_support es compatible con muro real.
    return pipeline._annotate_metric_thickness(
        candidates=candidates,
        scale_profile=scale_profile,
    )


def _merge_seed_and_context_cleaned(
    *,
    pipeline,
    discovered: Sequence[WallCandidate],
    regions,
    seeds: Sequence[WallCandidate],
    px_per_m: float,
    drawing_width: int,
    drawing_height: int,
) -> tuple[list[WallCandidate], set[str], dict[str, str], list[WallCandidate]]:
    gate = pipeline.context_gate.apply(candidates=discovered, regions=regions)
    decisions = {item.candidate_id: item for item in gate.decisions}

    seed_matching_discovered: set[str] = set()
    for candidate in discovered:
        if any(_seed_match(candidate, seed, px_per_m=px_per_m) for seed in seeds):
            seed_matching_discovered.add(candidate.id)

    # ACTIVE/PROTECTED + REVIEW permanecen. QUARANTINE solo se rescata si F03 ya
    # había demostrado una geometría equivalente como structural seed.
    kept: dict[str, WallCandidate] = {}
    for candidate in discovered:
        decision = decisions.get(candidate.id)
        state = decision.state if decision is not None else "ACTIVE"
        if state != "QUARANTINE" or candidate.id in seed_matching_discovered:
            metadata = dict(candidate.metadata)
            metadata.update({
                "hybrid_context_state": state,
                "hybrid_context_region_type": decision.region_type if decision else None,
                "hybrid_structural_seed_match": candidate.id in seed_matching_discovered,
            })
            kept[candidate.id] = candidate.model_copy(update={"metadata": metadata})

    # Si un seed F03 no tiene candidato equivalente en la red nueva, se conserva
    # explícitamente. Esto evita la regresión observada en Miguel V.
    for seed in seeds:
        if any(_seed_match(candidate, seed, px_per_m=px_per_m) for candidate in kept.values()):
            continue
        metadata = dict(seed.metadata)
        metadata.update({
            "hybrid_context_state": "PROTECTED",
            "hybrid_context_region_type": "F03_STRUCTURAL_SEED",
            "hybrid_structural_seed_match": True,
            "hybrid_seed_injected": True,
        })
        kept[f"SEED::{seed.id}"] = seed.model_copy(update={"metadata": metadata})

    merged = pipeline.candidate_generator._dedupe_candidates(list(kept.values()))
    merged = WallTrackConsolidator().consolidate(
        candidates=merged,
        width_px=drawing_width,
        height_px=drawing_height,
    )

    # La consolidación crea ids nuevos. Protegemos por geometría respecto a seeds.
    protected_ids = {
        candidate.id
        for candidate in merged
        if any(_seed_match(candidate, seed, px_per_m=px_per_m) for seed in seeds)
    }
    state_by_id = {
        candidate.id: str(candidate.metadata.get("hybrid_context_state") or "ACTIVE")
        for candidate in merged
    }
    return merged, protected_ids, state_by_id, gate.quarantined_candidates


def _physical_seed_ids(physical, seeds: Sequence[WallCandidate], *, px_per_m: float) -> set[str]:
    return {
        wall.wall_id
        for wall in physical
        if any(_seed_match(wall, seed, px_per_m=px_per_m) for seed in seeds)
    }


def _strict_collinear_bridge(first, second, *, seed_ids: set[str], px_per_m: float) -> _VirtualBridge | None:
    if _angle_diff(_angle_deg(first), _angle_deg(second)) > 3.0:
        return None
    thickness_ratio = max(first.thickness_px, second.thickness_px) / max(
        min(first.thickness_px, second.thickness_px), 1e-6
    )
    if thickness_ratio > 2.0:
        return None

    ux, uy, _ = _vector(first)
    first_offset = _normal_offset(first, ux, uy)
    second_offset = _normal_offset(second, ux, uy)
    thickness = float(np.median([first.thickness_px, second.thickness_px]))
    lateral_limit = max(0.06 * px_per_m, 0.90 * thickness)
    if abs(first_offset - second_offset) > lateral_limit:
        return None

    a0, a1 = _interval(first, ux, uy)
    b0, b1 = _interval(second, ux, uy)
    if a1 < b0:
        t0, t1 = a1, b0
    elif b1 < a0:
        t0, t1 = b1, a0
    else:
        return None

    gap = t1 - t0
    protected = first.wall_id in seed_ids or second.wall_id in seed_ids
    max_gap = (1.20 if protected else 0.70) * px_per_m
    if gap < 0.04 * px_per_m or gap > max_gap:
        return None

    # Sin soporte de banda en ambos extremos, un gap no se cierra por pura
    # colinealidad. Un seed F03 puede rescatar uno de los extremos.
    if not protected and min(first.region_support, second.region_support) < 0.38:
        return None
    if min(first.thickness_support, second.thickness_support) < 0.28:
        return None

    nx, ny = -uy, ux
    offset = (first_offset + second_offset) * 0.5
    p0 = (ux * t0 + nx * offset, uy * t0 + ny * offset)
    p1 = (ux * t1 + nx * offset, uy * t1 + ny * offset)
    return _VirtualBridge(
        bridge_id=f"HB_COL_{first.wall_id}_{second.wall_id}",
        kind="COLLINEAR_LOGICAL_CONTINUITY",
        start=p0,
        end=p1,
        gap_px=float(gap),
        wall_ids=(first.wall_id, second.wall_id),
        protected_by_seed=protected,
    )


def _strict_junction_bridge(source, host, *, endpoint, seed_ids: set[str], px_per_m: float) -> _VirtualBridge | None:
    angle = _angle_diff(_angle_deg(source), _angle_deg(host))
    if not (78.0 <= angle <= 102.0):
        return None
    host_line = _line(host)
    point = Point(endpoint)
    projected = host_line.interpolate(host_line.project(point))
    distance = float(point.distance(projected))
    protected = source.wall_id in seed_ids or host.wall_id in seed_ids
    max_distance = (0.18 if protected else 0.10) * px_per_m
    if distance <= 1e-6 or distance > max_distance:
        return None
    if not protected and min(source.region_support, host.region_support) < 0.42:
        return None
    return _VirtualBridge(
        bridge_id=f"HB_JNC_{source.wall_id}_{host.wall_id}_{round(endpoint[0], 2)}_{round(endpoint[1], 2)}",
        kind="JUNCTION_LOGICAL_CONTINUITY",
        start=(float(endpoint[0]), float(endpoint[1])),
        end=(float(projected.x), float(projected.y)),
        gap_px=distance,
        wall_ids=(source.wall_id, host.wall_id),
        protected_by_seed=protected,
    )


def _strict_virtual_bridges(walls, *, seed_ids: set[str], px_per_m: float) -> list[_VirtualBridge]:
    bridges: list[_VirtualBridge] = []
    seen: set[tuple] = set()

    for i, first in enumerate(walls):
        for second in walls[i + 1 :]:
            bridge = _strict_collinear_bridge(first, second, seed_ids=seed_ids, px_per_m=px_per_m)
            if bridge is None:
                continue
            key = (bridge.kind, tuple(sorted(bridge.wall_ids)), round(bridge.gap_px, 2))
            if key not in seen:
                seen.add(key)
                bridges.append(bridge)

    for source in walls:
        for endpoint in (source.start, source.end):
            best: _VirtualBridge | None = None
            for host in walls:
                if host.wall_id == source.wall_id:
                    continue
                bridge = _strict_junction_bridge(
                    source,
                    host,
                    endpoint=endpoint,
                    seed_ids=seed_ids,
                    px_per_m=px_per_m,
                )
                if bridge is None:
                    continue
                if best is None or bridge.gap_px < best.gap_px:
                    best = bridge
            if best is None:
                continue
            key = (best.kind, best.wall_ids, round(best.start[0], 1), round(best.start[1], 1))
            if key not in seen:
                seen.add(key)
                bridges.append(best)

    return bridges


def _component_membership(walls, bridges: list[_VirtualBridge], *, px_per_m: float) -> tuple[list[list[int]], list[set[int]]]:
    lines = [_line(item) for item in walls]
    adjacency: list[set[int]] = [set() for _ in walls]
    junction_tolerance = 0.14 * px_per_m

    for i in range(len(walls)):
        for j in range(i + 1, len(walls)):
            if lines[i].distance(lines[j]) <= junction_tolerance:
                adjacency[i].add(j)
                adjacency[j].add(i)

    index = {wall.wall_id: idx for idx, wall in enumerate(walls)}
    for bridge in bridges:
        a = index.get(bridge.wall_ids[0])
        b = index.get(bridge.wall_ids[1])
        if a is None or b is None:
            continue
        adjacency[a].add(b)
        adjacency[b].add(a)

    remaining = set(range(len(walls)))
    components: list[list[int]] = []
    while remaining:
        seed = next(iter(remaining))
        stack = [seed]
        component: list[int] = []
        while stack:
            current = stack.pop()
            if current not in remaining:
                continue
            remaining.remove(current)
            component.append(current)
            stack.extend(adjacency[current])
        components.append(component)

    components.sort(key=lambda group: sum(walls[index].length_px for index in group), reverse=True)
    return components, adjacency


def _select_hybrid_network(walls, components: list[list[int]], *, seed_ids: set[str], px_per_m: float):
    selected_indices: set[int] = set()
    membership: dict[str, int] = {}
    component_report: list[dict] = []

    for component_index, component in enumerate(components, 1):
        total_length_px = sum(walls[index].length_px for index in component)
        total_length_m = total_length_px / px_per_m
        seed_count = sum(1 for index in component if walls[index].wall_id in seed_ids)
        strong_wall_count = sum(
            1
            for index in component
            if walls[index].region_support >= 0.42
            and walls[index].thickness_support >= 0.32
        )
        keep = (
            seed_count > 0
            or (len(component) >= 3 and strong_wall_count >= 2)
            or (total_length_m >= 3.0 and strong_wall_count >= 1)
        )
        if keep:
            selected_indices.update(component)
        for index in component:
            membership[walls[index].wall_id] = component_index
        component_report.append({
            "component_id": component_index,
            "wall_count": len(component),
            "total_length_px": total_length_px,
            "total_length_m": total_length_m,
            "seed_count": seed_count,
            "strong_wall_count": strong_wall_count,
            "selected": keep,
            "wall_ids": [walls[index].wall_id for index in component],
        })

    selected = [wall for index, wall in enumerate(walls) if index in selected_indices]
    return selected, membership, component_report


def _render_wall_mask(walls, *, shape: tuple[int, int], px_per_m: float) -> np.ndarray:
    mask = np.zeros(shape, dtype=np.uint8)
    for wall in walls:
        _draw_segment(mask, wall.start, wall.end, 255, _wall_draw_thickness(wall, px_per_m))
    return mask


def _logical_seal_mask(walls, bridges: Sequence[_VirtualBridge], *, shape: tuple[int, int], px_per_m: float) -> np.ndarray:
    mask = _render_wall_mask(walls, shape=shape, px_per_m=px_per_m)
    by_id = {wall.wall_id: wall for wall in walls}
    for bridge in bridges:
        widths = [by_id[wall_id].thickness_px for wall_id in bridge.wall_ids if wall_id in by_id]
        thickness = float(np.median(widths)) if widths else 0.12 * px_per_m
        _draw_segment(mask, bridge.start, bridge.end, 255, max(2, int(round(thickness))))

    kernel_size = max(3, int(round(0.05 * px_per_m)))
    if kernel_size % 2 == 0:
        kernel_size += 1
    kernel = np.ones((kernel_size, kernel_size), dtype=np.uint8)
    return cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=1)


def _space_topology(logical_mask: np.ndarray, *, px_per_m: float) -> _SpaceTopology:
    background = (logical_mask == 0).astype(np.uint8)
    count, labels, stats, _ = cv2.connectedComponentsWithStats(background, connectivity=8)
    height, width = logical_mask.shape
    exterior: set[int] = set()
    interior: set[int] = set()
    areas: dict[int, int] = {}
    min_room_area_px2 = 0.40 * px_per_m * px_per_m

    for label in range(1, count):
        x, y, w, h, area = [int(value) for value in stats[label]]
        areas[label] = area
        touches_border = x == 0 or y == 0 or (x + w) >= width or (y + h) >= height
        if touches_border:
            exterior.add(label)
        elif area >= min_room_area_px2:
            interior.add(label)

    return _SpaceTopology(
        labels=labels,
        exterior_labels=frozenset(exterior),
        interior_labels=frozenset(interior),
        areas_px2=areas,
    )


def _sample_label(topology: _SpaceTopology, point: tuple[float, float]) -> int:
    x = int(round(point[0]))
    y = int(round(point[1]))
    if x < 0 or y < 0 or y >= topology.labels.shape[0] or x >= topology.labels.shape[1]:
        return -1
    return int(topology.labels[y, x])


def _classify_wall(wall, topology: _SpaceTopology, *, px_per_m: float) -> _WallRole:
    ux, uy, length = _vector(wall)
    nx, ny = -uy, ux
    sample_offset = max(wall.thickness_px * 0.5 + 0.08 * px_per_m, 3.0)
    sample_ts = (0.15, 0.30, 0.50, 0.70, 0.85) if length >= 12.0 else (0.50,)

    perimeter_votes = 0
    divider_votes = 0
    review_votes = 0
    left_labels: list[int] = []
    right_labels: list[int] = []

    for t in sample_ts:
        start = _point_tuple(wall.start)
        end = _point_tuple(wall.end)
        cx = start[0] + (end[0] - start[0]) * t
        cy = start[1] + (end[1] - start[1]) * t
        left = _sample_label(topology, (cx + nx * sample_offset, cy + ny * sample_offset))
        right = _sample_label(topology, (cx - nx * sample_offset, cy - ny * sample_offset))
        left_labels.append(left)
        right_labels.append(right)

        left_ext = left in topology.exterior_labels
        right_ext = right in topology.exterior_labels
        left_int = left in topology.interior_labels
        right_int = right in topology.interior_labels

        if (left_ext and right_int) or (right_ext and left_int):
            perimeter_votes += 1
        elif left_int and right_int and left != right:
            divider_votes += 1
        else:
            review_votes += 1

    total = len(sample_ts)
    minimum_votes = max(1, math.ceil(total * 0.60))
    if perimeter_votes >= minimum_votes and perimeter_votes > divider_votes:
        role = "PERIMETER"
        confidence = perimeter_votes / total
    elif divider_votes >= minimum_votes and divider_votes > perimeter_votes:
        role = "DIVIDER"
        confidence = divider_votes / total
    else:
        role = "REVIEW"
        confidence = max(perimeter_votes, divider_votes) / total

    return _WallRole(
        wall_id=wall.wall_id,
        role=role,
        confidence=float(confidence),
        perimeter_votes=perimeter_votes,
        divider_votes=divider_votes,
        review_votes=review_votes,
        left_labels=tuple(left_labels),
        right_labels=tuple(right_labels),
    )


def _wall_junctions(walls, *, px_per_m: float) -> list[tuple[float, float]]:
    tolerance = 0.12 * px_per_m
    lines = [_line(wall) for wall in walls]
    points: list[tuple[float, float]] = []
    for i, first in enumerate(lines):
        for second in lines[i + 1 :]:
            if first.distance(second) > tolerance:
                continue
            intersection = first.intersection(second)
            if intersection.geom_type == "Point":
                points.append((float(intersection.x), float(intersection.y)))
    deduped: list[tuple[float, float]] = []
    for point in points:
        if not any(math.hypot(point[0] - other[0], point[1] - other[1]) <= 3.0 for other in deduped):
            deduped.append(point)
    return deduped


def _draw_centerlines(image: np.ndarray, walls, *, thickness: int = 2, color=(0, 0, 0)) -> None:
    for wall in walls:
        _draw_segment(image, _point_tuple(wall.start), _point_tuple(wall.end), color, thickness)


def _draw_room_contours(image: np.ndarray, topology: _SpaceTopology) -> None:
    for label in sorted(topology.interior_labels):
        component = np.where(topology.labels == label, 255, 0).astype(np.uint8)
        contours, _ = cv2.findContours(component, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(image, contours, -1, (0, 0, 0), 2, cv2.LINE_AA)


def _serialize_bridge(item: _VirtualBridge, *, px_per_m: float) -> dict:
    return {
        "id": item.bridge_id,
        "kind": item.kind,
        "start": list(item.start),
        "end": list(item.end),
        "gap_px": item.gap_px,
        "gap_m": item.gap_px / px_per_m,
        "wall_ids": list(item.wall_ids),
        "protected_by_seed": item.protected_by_seed,
        "physical_wall_present": False,
        "logical_continuity_only": True,
    }


def _serialize_role(item: _WallRole) -> dict:
    return {
        "wall_id": item.wall_id,
        "role": item.role,
        "confidence": item.confidence,
        "perimeter_votes": item.perimeter_votes,
        "divider_votes": item.divider_votes,
        "review_votes": item.review_votes,
        "left_labels": list(item.left_labels),
        "right_labels": list(item.right_labels),
    }


def _run_level(*, pipeline, loaded, output_dir: Path, case_id: str, scale_profile) -> dict:
    level_result = loaded.level_result
    perimeter = level_result.perimeter.editable_perimeter
    assert perimeter is not None
    px_per_m = 1.0 / float(scale_profile.local_m_per_px)

    # F03 se ejecuta sin cambios: de aquí solo tomamos la selección estructural y
    # las regiones contextuales ya validadas por pruebas anteriores.
    full = pipeline.run(
        level_view=level_result.level_view,
        perimeter=perimeter,
        evidence=list(level_result.evidence.evidence),
        scale_profile=scale_profile,
    )
    graph_by_id = {candidate.id: candidate for candidate in full.candidate_graph.candidates}
    seeds = [
        graph_by_id[candidate_id]
        for candidate_id in full.solution.selected_candidate_ids
        if candidate_id in graph_by_id
    ]

    discovered = _discover_without_f02_perimeter(
        pipeline=pipeline,
        full=full,
        scale_profile=scale_profile,
    )
    hybrid_candidates, protected_candidate_ids, context_state_by_id, quarantined = _merge_seed_and_context_cleaned(
        pipeline=pipeline,
        discovered=discovered,
        regions=[region for region in full.context_gate.regions if region.region_type != "WALL_PROTECTED_REGION"],
        seeds=seeds,
        px_per_m=px_per_m,
        drawing_width=full.drawing_model.width_px,
        drawing_height=full.drawing_model.height_px,
    )

    physical = _physical_walls(hybrid_candidates)
    assert physical, "La fusión híbrida no produjo WallTracks físicos."
    seed_wall_ids = _physical_seed_ids(physical, seeds, px_per_m=px_per_m)

    bridges_all = _strict_virtual_bridges(
        physical,
        seed_ids=seed_wall_ids,
        px_per_m=px_per_m,
    )
    components, adjacency = _component_membership(physical, bridges_all, px_per_m=px_per_m)
    selected, component_membership, component_report = _select_hybrid_network(
        physical,
        components,
        seed_ids=seed_wall_ids,
        px_per_m=px_per_m,
    )
    selected_ids = {wall.wall_id for wall in selected}
    bridges = [
        bridge
        for bridge in bridges_all
        if all(wall_id in selected_ids for wall_id in bridge.wall_ids)
    ]
    assert selected, "La red híbrida seleccionada quedó vacía."

    raster = _decode(level_result.level_view.raster_bytes)
    wall_mask = _render_wall_mask(selected, shape=raster.shape[:2], px_per_m=px_per_m)
    logical_mask = _logical_seal_mask(selected, bridges, shape=raster.shape[:2], px_per_m=px_per_m)
    topology = _space_topology(logical_mask, px_per_m=px_per_m)
    roles = [_classify_wall(wall, topology, px_per_m=px_per_m) for wall in selected]
    junctions = _wall_junctions(selected, px_per_m=px_per_m)

    white = np.full_like(raster, 255)
    seed_visual = white.copy()
    context_clean_visual = white.copy()
    wallgraph_clean = white.copy()
    rooms_clean = white.copy()
    audit = cv2.addWeighted(raster, 0.12, np.full_like(raster, 255), 0.88, 0.0)
    exclusion_audit = cv2.addWeighted(raster, 0.12, np.full_like(raster, 255), 0.88, 0.0)

    _draw_centerlines(seed_visual, seeds, thickness=3)
    _draw_centerlines(context_clean_visual, hybrid_candidates, thickness=2)
    _draw_centerlines(wallgraph_clean, selected, thickness=3)
    _draw_room_contours(rooms_clean, topology)

    _draw_centerlines(audit, selected, thickness=2)
    for bridge in bridges:
        _draw_segment(audit, bridge.start, bridge.end, (0, 165, 255), 2)
    for x, y in junctions:
        cv2.circle(audit, (int(round(x)), int(round(y))), 4, (255, 0, 255), -1, cv2.LINE_AA)

    # Solo auditoría de contexto: rojo = candidato quarantined por V5/V6.x.
    _draw_centerlines(exclusion_audit, quarantined, thickness=2, color=(0, 0, 255))
    _draw_centerlines(exclusion_audit, seeds, thickness=3, color=(0, 0, 0))

    safe = _safe(loaded.level_name)
    paths = {
        "seed": output_dir / f"{case_id}__{safe}__01_f03_structural_seed.png",
        "context": output_dir / f"{case_id}__{safe}__02_context_clean_candidates.png",
        "mask": output_dir / f"{case_id}__{safe}__03_hybrid_wall_mask.png",
        "logical": output_dir / f"{case_id}__{safe}__04_hybrid_logical_seal_mask.png",
        "wallgraph": output_dir / f"{case_id}__{safe}__05_hybrid_wallgraph_clean.png",
        "rooms": output_dir / f"{case_id}__{safe}__06_hybrid_rooms_clean.png",
        "audit": output_dir / f"{case_id}__{safe}__07_hybrid_topology_audit.png",
        "exclusion": output_dir / f"{case_id}__{safe}__08_context_exclusion_audit.png",
    }
    cv2.imwrite(str(paths["seed"]), seed_visual)
    cv2.imwrite(str(paths["context"]), context_clean_visual)
    cv2.imwrite(str(paths["mask"]), wall_mask)
    cv2.imwrite(str(paths["logical"]), logical_mask)
    cv2.imwrite(str(paths["wallgraph"]), wallgraph_clean)
    cv2.imwrite(str(paths["rooms"]), rooms_clean)
    cv2.imwrite(str(paths["audit"]), audit)
    cv2.imwrite(str(paths["exclusion"]), exclusion_audit)

    role_counts = {
        role: sum(1 for item in roles if item.role == role)
        for role in ("PERIMETER", "DIVIDER", "REVIEW")
    }
    region_counts: dict[str, int] = {}
    effective_regions = [region for region in full.context_gate.regions if region.region_type != "WALL_PROTECTED_REGION"]
    for region in effective_regions:
        region_counts[region.region_type] = region_counts.get(region.region_type, 0) + 1

    return {
        "level": loaded.level_name,
        "level_view_id": level_result.level_view.id,
        "px_per_m": px_per_m,
        "f03_seed_count": len(seeds),
        "raw_discovered_count": len(discovered),
        "context_quarantined_count": len(quarantined),
        "hybrid_candidate_count": len(hybrid_candidates),
        "physical_wall_count": len(physical),
        "protected_seed_wall_count": len(seed_wall_ids),
        "selected_network_wall_count": len(selected),
        "network_component_count": len(components),
        "virtual_bridge_count": len(bridges),
        "seed_protected_bridge_count": sum(1 for item in bridges if item.protected_by_seed),
        "junction_count": len(junctions),
        "interior_space_count": len(topology.interior_labels),
        "exterior_component_count": len(topology.exterior_labels),
        "role_counts": role_counts,
        "roles": [_serialize_role(item) for item in roles],
        "virtual_bridges": [_serialize_bridge(item, px_per_m=px_per_m) for item in bridges],
        "components": component_report,
        "component_membership": component_membership,
        "context_region_counts": region_counts,
        "context_state_by_candidate_id": context_state_by_id,
        "visuals": {key: str(path) for key, path in paths.items()},
    }


def _run_case(case: LoadedCase) -> None:
    output_dir = OUTPUT_ROOT / case.case_id
    if output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    pipeline = ProposalCReconstructionPipeline()
    scale_inputs = []
    for loaded in case.levels:
        perimeter = loaded.level_result.perimeter.editable_perimeter
        assert perimeter is not None
        scale_inputs.append((loaded.level_result.level_view, perimeter))

    project_scale = pipeline.build_project_scale_context(levels=scale_inputs)
    assert project_scale.state == "RESOLVED"

    report = {
        "probe_version": PROBE_VERSION,
        "baseline": BASELINE,
        "case_id": case.case_id,
        "case": case.case_name,
        "gemini_calls_added": 0,
        "engine_files_modified": 0,
        "f02_policy": "SCALE_REFERENCE_ONLY_NOT_WALL_TRUTH",
        "axis_policy": "AXIS_SUPPORT_IS_NOT_A_WALL_PENALTY; ONLY_DIRECT_AXIS_GRAPHICS_CAN_BE_QUARANTINED",
        "context_policy": "REUSE_CONTEXT_GATE_V5_V6_X_AS_NEGATIVE_CONTEXT_FILTER_WITH_STRUCTURAL_RESCUE",
        "seed_policy": "F03_SELECTED_WALLS_ARE_PROTECTED_STRUCTURAL_SEEDS",
        "wall_truth_policy": "HYBRID_F03_SEED_PLUS_CONTEXT_CLEAN_DRAWING_MODEL_DISCOVERY",
        "bridge_policy": "STRICT_LOGICAL_CONTINUITY_ONLY_NOT_SOLID_WALL",
        "role_policy": {
            "PERIMETER": "EXTERIOR_TO_INTERIOR_ADJACENCY",
            "DIVIDER": "INTERIOR_TO_DIFFERENT_INTERIOR_ADJACENCY",
            "REVIEW": "INSUFFICIENT_TOPOLOGY_DO_NOT_FORCE",
        },
        "visual_contract": {
            "05_hybrid_wallgraph_clean": "WHITE_BACKGROUND_BLACK_PHYSICAL_WALL_CENTERLINES",
            "06_hybrid_rooms_clean": "WHITE_BACKGROUND_BLACK_ROOM_CONTOURS",
        },
        "project_scale": project_scale.model_dump(mode="json"),
        "levels": [],
        "failures": [],
    }

    for loaded in case.levels:
        profile = project_scale.for_level(loaded.level_result.level_view.id)
        assert profile.local_m_per_px is not None
        px_per_m = 1.0 / profile.local_m_per_px
        relative_error = abs(px_per_m - TARGET_PX_PER_M) / TARGET_PX_PER_M
        if profile.state != "RESOLVED" or relative_error > TARGET_RELATIVE_TOLERANCE:
            report["failures"].append(
                f"{loaded.level_name}:SCALE_GUARD:{profile.state}:{px_per_m:.6f}"
            )
            continue

        level_report = _run_level(
            pipeline=pipeline,
            loaded=loaded,
            output_dir=output_dir,
            case_id=case.case_id,
            scale_profile=profile,
        )
        report["levels"].append(level_report)
        print("\n" + "=" * 100)
        print(f"F03 + MASK + TOPOLOGY HYBRID V1 — {case.case_name} — {loaded.level_name}")
        print({
            "f03_seed": level_report["f03_seed_count"],
            "raw_discovered": level_report["raw_discovered_count"],
            "context_quarantined": level_report["context_quarantined_count"],
            "hybrid_candidates": level_report["hybrid_candidate_count"],
            "selected_network": level_report["selected_network_wall_count"],
            "bridges": level_report["virtual_bridge_count"],
            "junctions": level_report["junction_count"],
            "rooms": level_report["interior_space_count"],
            "roles": level_report["role_counts"],
        })

    report["passed"] = not report["failures"]
    json_path = output_dir / f"{case.case_id}__f03_mask_topology_hybrid_v1.json"
    json_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\nJSON: {json_path}")
    assert not report["failures"], json.dumps(report["failures"], ensure_ascii=False)


@pytest.mark.parametrize("case_id", CASE_IDS)
def test_quantia_spatial_f03_mask_topology_hybrid_all_3_v1(case_id: str) -> None:
    _run_case(CASE_LOADERS[case_id]())


if __name__ == "__main__":
    for _case_id in CASE_IDS:
        _run_case(CASE_LOADERS[_case_id]())
