from __future__ import annotations

import json
import math
import shutil
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import pytest
from shapely.geometry import LineString, box

from app.quantia_spatialV1.reconstruction_core import ProposalCReconstructionPipeline
from app.quantia_spatialV1.tests.quantia_case_loader import CASE_LOADERS, LoadedCase


PROBE_VERSION = "F03_ELEMENT_ISOLATION_PROBE_ALL_3_V1"
BASELINE = "F03_ELEMENT_CONTEXT_ISOLATION_V1 + F03_SELECTION_CONTRACTS_V1_4 + CANONICAL_METRIC_RASTER_V2_3_VALIDATED"
CASE_IDS = ("casa_viri", "miguel_h", "miguel_v")
TARGET_PX_PER_M = 90.0
TARGET_RELATIVE_TOLERANCE = 0.05

ELEMENT_TYPES = (
    "DOOR_REGION",
    "WINDOW_REGION",
    "OPENING_REGION",
    "STAIR_FLIGHT_REGION",
    "COLUMN_REGION",
    "SYMBOL_FIXTURE_REGION",
    "FURNITURE_MODULE_REGION",
    "FLOOR_FINISH_GRID_REGION",
    "TEXT_SYMBOL_REGION",
    "DIMENSION_REGION",
)

ELEMENT_SLUG = {
    "DOOR_REGION": "door",
    "WINDOW_REGION": "window",
    "OPENING_REGION": "opening",
    "STAIR_FLIGHT_REGION": "stair",
    "COLUMN_REGION": "column",
    "SYMBOL_FIXTURE_REGION": "fixture",
    "FURNITURE_MODULE_REGION": "furniture",
    "FLOOR_FINISH_GRID_REGION": "floor_finish",
    "TEXT_SYMBOL_REGION": "text_symbol",
    "DIMENSION_REGION": "dimension",
}

TESTS_DIR = Path(__file__).resolve().parent
OUTPUT_ROOT = TESTS_DIR / "output" / "f03_element_isolation_probe_v1"


def _safe_name(value: str) -> str:
    cleaned = "".join(ch.lower() if ch.isalnum() else "_" for ch in value.strip())
    while "__" in cleaned:
        cleaned = cleaned.replace("__", "_")
    return cleaned.strip("_") or "level"


def _decode(data: bytes) -> np.ndarray:
    image = cv2.imdecode(np.frombuffer(data, dtype=np.uint8), cv2.IMREAD_COLOR)
    if image is None:
        raise RuntimeError("No se pudo decodificar raster LevelView.")
    return image


def _save(path: Path, image: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not cv2.imwrite(str(path), image):
        raise RuntimeError(f"No se pudo guardar {path}")


def _faded_base(raster: np.ndarray) -> np.ndarray:
    white = np.full_like(raster, 255)
    return cv2.addWeighted(raster, 0.22, white, 0.78, 0.0)


def _draw_f02_perimeter(image: np.ndarray, perimeter) -> None:
    vertices = {vertex.id: vertex.point_px for vertex in perimeter.vertices}
    for wall in perimeter.walls:
        a = vertices[wall.start_vertex_id]
        b = vertices[wall.end_vertex_id]
        cv2.line(
            image,
            (int(round(a.x)), int(round(a.y))),
            (int(round(b.x)), int(round(b.y))),
            (0, 0, 0),
            4,
            cv2.LINE_AA,
        )


def _draw_selected_walls(image: np.ndarray, selected_candidates) -> None:
    for candidate in selected_candidates:
        cv2.line(
            image,
            (int(round(candidate.start.x)), int(round(candidate.start.y))),
            (int(round(candidate.end.x)), int(round(candidate.end.y))),
            (0, 0, 0),
            4,
            cv2.LINE_AA,
        )


def _bezier_point(points, t: float) -> tuple[int, int]:
    p0, p1, p2, p3 = points
    u = 1.0 - t
    x = (
        u * u * u * p0.x
        + 3.0 * u * u * t * p1.x
        + 3.0 * u * t * t * p2.x
        + t * t * t * p3.x
    )
    y = (
        u * u * u * p0.y
        + 3.0 * u * u * t * p1.y
        + 3.0 * u * t * t * p2.y
        + t * t * t * p3.y
    )
    return int(round(x)), int(round(y))


def _draw_region_evidence(image: np.ndarray, *, region, drawing) -> None:
    # Una imagen = un tipo de elemento. Sin candidatos globales ni nomenclaturas.
    p1 = (int(round(region.bbox.x_min)), int(round(region.bbox.y_min)))
    p2 = (int(round(region.bbox.x_max)), int(round(region.bbox.y_max)))
    cv2.rectangle(image, p1, p2, (0, 0, 255), 2, cv2.LINE_AA)

    members = set(region.member_line_ids)
    for line in drawing.lines:
        if line.id not in members:
            continue
        cv2.line(
            image,
            (int(round(line.start.x)), int(round(line.start.y))),
            (int(round(line.end.x)), int(round(line.end.y))),
            (255, 255, 0),
            3,
            cv2.LINE_AA,
        )

    curve_id = str(region.metadata.get("curve_id") or "")
    if curve_id:
        curve = next((item for item in drawing.curves if item.id == curve_id), None)
        if curve is not None:
            pts = [_bezier_point(curve.control_points, i / 24.0) for i in range(25)]
            cv2.polylines(image, [np.asarray(pts, dtype=np.int32)], False, (255, 0, 255), 3, cv2.LINE_AA)


def _candidate_line(candidate) -> LineString:
    return LineString([
        (float(candidate.start.x), float(candidate.start.y)),
        (float(candidate.end.x), float(candidate.end.y)),
    ])


def _all_discovered(full):
    by_id = {}
    for candidate in (
        list(full.context_gate.active_candidates)
        + list(full.context_gate.review_candidates)
        + list(full.context_gate.quarantined_candidates)
    ):
        by_id[candidate.id] = candidate
    return list(by_id.values())


def _region_probe(*, pipeline, full, region, selected_ids: set[str]) -> dict[str, Any]:
    counts = Counter()
    direct_members = 0
    selected_intersections = 0
    selected_states = Counter()
    evaluations = []

    region_geom = box(region.bbox.x_min, region.bbox.y_min, region.bbox.x_max, region.bbox.y_max)
    for candidate in _all_discovered(full):
        line = _candidate_line(candidate)
        if not line.intersects(region_geom):
            continue
        containment = line.intersection(region_geom).length / max(line.length, 1e-6)
        if containment < 0.30:
            continue
        decision = pipeline.context_gate._evaluate(candidate=candidate, region=region)
        if decision is None:
            continue
        counts[decision.state] += 1
        direct = float(
            decision.metadata.get("direct_element_member_support", decision.metadata.get("member_pattern_support", 0.0))
            or 0.0
        )
        if direct > 0.0:
            direct_members += 1
        if candidate.id in selected_ids:
            selected_intersections += 1
            selected_states[decision.state] += 1
        evaluations.append({
            "candidate_id": candidate.id,
            "selected": candidate.id in selected_ids,
            "state": decision.state,
            "reason": decision.reason,
            "containment": float(decision.spatial_containment),
            "direct_member_support": direct,
            "metric_wall_band_support": float(decision.metadata.get("metric_wall_band_support", 0.0) or 0.0),
        })

    return {
        "region_id": region.id,
        "region_type": region.region_type,
        "confidence": float(region.confidence),
        "quarantine_enabled": bool(region.quarantine_enabled),
        "member_line_count": len(region.member_line_ids),
        "candidate_intersection_count": len(evaluations),
        "direct_member_candidate_count": direct_members,
        "selected_intersection_count": selected_intersections,
        "state_counts": dict(sorted(counts.items())),
        "selected_state_counts": dict(sorted(selected_states.items())),
        "source": region.metadata.get("source"),
        "negative_mask": bool(region.metadata.get("negative_mask", False)),
        "evaluations": evaluations,
    }


def _run_level(*, pipeline, loaded, output_dir: Path, case_id: str, scale_profile) -> dict[str, Any]:
    level_result = loaded.level_result
    perimeter = level_result.perimeter.editable_perimeter
    assert perimeter is not None

    full = pipeline.run(
        level_view=level_result.level_view,
        perimeter=perimeter,
        evidence=list(level_result.evidence.evidence),
        scale_profile=scale_profile,
    )
    assert full.diagnostics.graph_candidate_limit_drop_count == 0

    selected_ids = set(full.solution.selected_candidate_ids)
    graph_by_id = {candidate.id: candidate for candidate in full.candidate_graph.candidates}
    selected_candidates = [graph_by_id[cid] for cid in full.solution.selected_candidate_ids]

    raster = _decode(level_result.level_view.raster_bytes)
    safe = _safe_name(loaded.level_name)

    # Visual principal: SOLO los muros ya seleccionados. Sin cajas, candidatos,
    # ejes, nomenclaturas ni colores de estado. Se conserva un raster muy tenue
    # únicamente para ubicación visual.
    walls = _faded_base(raster)
    _draw_f02_perimeter(walls, perimeter)
    _draw_selected_walls(walls, selected_candidates)
    walls_path = output_dir / f"{case_id}__{safe}__walls_only.png"
    _save(walls_path, walls)

    regions_by_type = defaultdict(list)
    for region in full.context_gate.regions:
        if region.region_type in ELEMENT_TYPES:
            regions_by_type[region.region_type].append(region)

    element_report: dict[str, Any] = {}
    element_visuals: dict[str, str | None] = {}

    for region_type in ELEMENT_TYPES:
        regions = regions_by_type.get(region_type, [])
        probes = [
            _region_probe(
                pipeline=pipeline,
                full=full,
                region=region,
                selected_ids=selected_ids,
            )
            for region in regions
        ]

        aggregate_states = Counter()
        aggregate_selected_states = Counter()
        for probe in probes:
            aggregate_states.update(probe["state_counts"])
            aggregate_selected_states.update(probe["selected_state_counts"])

        element_report[region_type] = {
            "region_count": len(regions),
            "candidate_intersection_count": sum(p["candidate_intersection_count"] for p in probes),
            "direct_member_candidate_count": sum(p["direct_member_candidate_count"] for p in probes),
            "selected_intersection_count": sum(p["selected_intersection_count"] for p in probes),
            "state_counts": dict(sorted(aggregate_states.items())),
            "selected_state_counts": dict(sorted(aggregate_selected_states.items())),
            "regions": probes,
        }

        if not regions:
            element_visuals[region_type] = None
            continue

        isolated = _faded_base(raster)
        for region in regions:
            _draw_region_evidence(isolated, region=region, drawing=full.drawing_model)

        # Solo mostramos muros seleccionados que realmente intersectan este tipo
        # de elemento. No se dibujan todos los candidatos.
        for candidate in selected_candidates:
            line = _candidate_line(candidate)
            if any(
                line.intersection(box(r.bbox.x_min, r.bbox.y_min, r.bbox.x_max, r.bbox.y_max)).length
                / max(line.length, 1e-6) >= 0.30
                for r in regions
            ):
                cv2.line(
                    isolated,
                    (int(round(candidate.start.x)), int(round(candidate.start.y))),
                    (int(round(candidate.end.x)), int(round(candidate.end.y))),
                    (0, 0, 0),
                    4,
                    cv2.LINE_AA,
                )

        slug = ELEMENT_SLUG[region_type]
        path = output_dir / f"{case_id}__{safe}__element_{slug}.png"
        _save(path, isolated)
        element_visuals[region_type] = str(path)

    return {
        "level": loaded.level_name,
        "level_view_id": level_result.level_view.id,
        "scale_profile": scale_profile.model_dump(mode="json"),
        "selected_wall_count": len(selected_ids),
        "walls_only_visual": str(walls_path),
        "region_type_counts": dict(sorted(Counter(r.region_type for r in full.context_gate.regions).items())),
        "element_visuals": element_visuals,
        "elements": element_report,
    }


def _run_case(case: LoadedCase) -> None:
    output_dir = OUTPUT_ROOT / case.case_id
    if output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    pipeline = ProposalCReconstructionPipeline()
    scale_inputs = []
    for loaded in case.levels:
        perimeter = loaded.level_result.perimeter.editable_perimeter
        assert perimeter is not None
        scale_inputs.append((loaded.level_result.level_view, perimeter))

    project_scale = pipeline.build_project_scale_context(levels=scale_inputs)
    assert project_scale.state == "RESOLVED"

    report = {
        "probe_version": PROBE_VERSION,
        "baseline": BASELINE,
        "case_id": case.case_id,
        "case": case.case_name,
        "gemini_calls_added": 0,
        "project_scale": project_scale.model_dump(mode="json"),
        "levels": [],
    }

    failures = []
    for loaded in case.levels:
        profile = project_scale.for_level(loaded.level_result.level_view.id)
        assert profile.local_m_per_px is not None
        px_per_m = 1.0 / profile.local_m_per_px
        relative_error = abs(px_per_m - TARGET_PX_PER_M) / TARGET_PX_PER_M
        if profile.state != "RESOLVED" or relative_error > TARGET_RELATIVE_TOLERANCE:
            failures.append(f"{loaded.level_name}:SCALE_GUARD:{profile.state}:{px_per_m:.6f}")
            continue

        level_report = _run_level(
            pipeline=pipeline,
            loaded=loaded,
            output_dir=output_dir,
            case_id=case.case_id,
            scale_profile=profile,
        )
        report["levels"].append(level_report)

        compact = {
            key: {
                "regions": value["region_count"],
                "intersections": value["candidate_intersection_count"],
                "selected": value["selected_intersection_count"],
                "states": value["state_counts"],
            }
            for key, value in level_report["elements"].items()
            if value["region_count"] > 0 or key in {"DOOR_REGION", "WINDOW_REGION", "STAIR_FLIGHT_REGION"}
        }
        print("\n" + "=" * 104)
        print(f"F03 ELEMENT ISOLATION PROBE V1 — {case.case_name} — {loaded.level_name}")
        print({
            "px_m": round(px_per_m, 3),
            "selected_walls": level_report["selected_wall_count"],
            "walls_visual": level_report["walls_only_visual"],
            "elements": compact,
        })

    report["failures"] = failures
    report["passed"] = not failures
    json_path = output_dir / f"{case.case_id}__f03_element_isolation_probe_v1.json"
    json_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\nJSON: {json_path}")

    assert not failures, json.dumps(failures, ensure_ascii=False)


@pytest.mark.parametrize("case_id", CASE_IDS)
def test_f03_element_isolation_probe_all_3_v1(case_id: str) -> None:
    _run_case(CASE_LOADERS[case_id]())


if __name__ == "__main__":
    for _case_id in CASE_IDS:
        _run_case(CASE_LOADERS[_case_id]())
