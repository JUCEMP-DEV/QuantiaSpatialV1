from app.quantia_spatialV1.reconstruction_core.candidate_context_gate import CandidateContextGate
from app.quantia_spatialV1.reconstruction_core.candidate_models import WallCandidate, WallEvidenceVector
from app.quantia_spatialV1.reconstruction_core.drawing_model import (
    DrawingBBox,
    DrawingCurve,
    DrawingLine,
    DrawingModel,
    DrawingModelDiagnostics,
    DrawingPoint,
    DrawingText,
    SemanticObservation,
)
from app.quantia_spatialV1.reconstruction_core.element_context_detector import ElementContextDetector
from app.quantia_spatialV1.reconstruction_core.level_scale_normalizer import LevelScaleProfile


def _profile():
    return LevelScaleProfile(
        level_view_id="LV",
        state="RESOLVED",
        local_m_per_px=1.0 / 90.0,
        canonical_m_per_px=1.0 / 90.0,
        scale_factor_to_canonical=1.0,
        local_min_dim_px=800.0,
        normalized_min_dim_px=800.0,
        project_reference_min_dim_normalized_px=800.0,
        project_reference_area_normalized_px2=800000.0,
        source="TEST",
        confidence=1.0,
    )


def _line(ident, a, b):
    import math
    dx = b[0] - a[0]
    dy = b[1] - a[1]
    return DrawingLine(
        id=ident,
        start=DrawingPoint(x=a[0], y=a[1]),
        end=DrawingPoint(x=b[0], y=b[1]),
        length_px=math.hypot(dx, dy),
        angle_deg=math.degrees(math.atan2(dy, dx)) % 180.0,
        evidence_ids=[ident],
        sources=["PYMUPDF"],
    )


def _drawing(*, lines=None, curves=None, semantics=None, texts=None):
    return DrawingModel(
        level_view_id="LV",
        width_px=1200,
        height_px=900,
        lines=list(lines or []),
        curves=list(curves or []),
        semantic_observations=list(semantics or []),
        texts=list(texts or []),
        diagnostics=DrawingModelDiagnostics(
            raw_evidence_count=0,
            normalized_line_count=len(lines or []),
            normalized_region_count=0,
            normalized_curve_count=len(curves or []),
            text_count=len(texts or []),
            semantic_observation_count=len(semantics or []),
            lsd_line_count=0,
            region_centerline_count=0,
            source_counts={},
        ),
    )


def _candidate(ident, a, b, *, face_ids, metric=0.9):
    import math
    dx = b[0] - a[0]
    dy = b[1] - a[1]
    return WallCandidate(
        id=ident,
        generator="DOUBLE_FACE",
        start=DrawingPoint(x=a[0], y=a[1]),
        end=DrawingPoint(x=b[0], y=b[1]),
        angle_deg=math.degrees(math.atan2(dy, dx)) % 180.0,
        length_px=math.hypot(dx, dy),
        thickness_px=12.0,
        face_ids=list(face_ids),
        evidence_ids=list(face_ids),
        source_names=["PYMUPDF"],
        evidence=WallEvidenceVector(
            pair_overlap=1.0,
            thickness_support=0.9,
            vector_support=1.0,
            raster_line_support=1.0,
            region_support=0.9,
            source_consensus=0.75,
            perimeter_containment=1.0,
        ),
        prior_score=0.8,
        metadata={"metric_wall_band_support": metric},
    )


def test_bezier_door_arc_creates_opening_context_and_leaf_membership():
    # Cuarto de círculo aproximado, radio ~90 px = 1 m.
    curve = DrawingCurve(
        id="CURVE_DOOR",
        control_points=[
            DrawingPoint(x=100, y=190),
            DrawingPoint(x=100, y=140),
            DrawingPoint(x=140, y=100),
            DrawingPoint(x=190, y=100),
        ],
        bbox=DrawingBBox(x_min=100, y_min=100, x_max=190, y_max=190),
        evidence_ids=["CURVE_DOOR"],
        sources=["PYMUPDF"],
    )
    leaf = _line("LEAF", (100, 190), (100, 105))
    host = _line("HOST", (40, 100), (260, 100))
    drawing = _drawing(lines=[leaf, host], curves=[curve])

    regions = ElementContextDetector().detect(drawing=drawing, scale_profile=_profile())
    doors = [r for r in regions if r.region_type == "DOOR_REGION"]
    assert len(doors) == 1
    assert doors[0].metadata["source"] == "CUBIC_BEZIER_DOOR_SWING"
    assert "LEAF" in doors[0].member_line_ids


def test_opening_gate_quarantines_direct_symbol_but_preserves_host_wall():
    region = ElementContextDetector().detect(
        drawing=_drawing(
            lines=[
                _line("LEAF", (100, 190), (100, 105)),
                _line("HOST", (40, 100), (260, 100)),
            ],
            curves=[
                DrawingCurve(
                    id="CURVE_DOOR",
                    control_points=[
                        DrawingPoint(x=100, y=190),
                        DrawingPoint(x=100, y=140),
                        DrawingPoint(x=140, y=100),
                        DrawingPoint(x=190, y=100),
                    ],
                    bbox=DrawingBBox(x_min=100, y_min=100, x_max=190, y_max=190),
                    sources=["PYMUPDF"],
                )
            ],
        ),
        scale_profile=_profile(),
    )[0]

    leaf_candidate = _candidate("C_LEAF", (100, 188), (100, 108), face_ids=["LEAF"], metric=0.35)
    host_candidate = _candidate("C_HOST", (40, 100), (260, 100), face_ids=["HOST"], metric=1.0)
    result = CandidateContextGate().apply(candidates=[leaf_candidate, host_candidate], regions=[region])
    decisions = {d.candidate_id: d for d in result.decisions}
    assert decisions["C_LEAF"].state == "QUARANTINE"
    assert decisions["C_HOST"].state == "ACTIVE"
    assert decisions["C_HOST"].metadata["opening_bridge_candidate"] is True


def test_semantic_elements_become_typed_context_without_turning_bbox_into_wall_mask():
    semantics = [
        SemanticObservation(
            id="S_DOOR",
            family="DOOR",
            bbox=DrawingBBox(x_min=300, y_min=200, x_max=390, y_max=300),
            confidence=0.92,
        ),
        SemanticObservation(
            id="S_COLUMN",
            family="COLUMN",
            bbox=DrawingBBox(x_min=500, y_min=300, x_max=535, y_max=335),
            confidence=0.88,
        ),
        SemanticObservation(
            id="S_FIX",
            family="FIXTURE",
            bbox=DrawingBBox(x_min=650, y_min=420, x_max=720, y_max=500),
            confidence=0.84,
        ),
    ]
    regions = ElementContextDetector().detect(
        drawing=_drawing(semantics=semantics),
        scale_profile=_profile(),
    )
    types = {r.region_type for r in regions}
    assert {"DOOR_REGION", "COLUMN_REGION", "SYMBOL_FIXTURE_REGION"}.issubset(types)
    door = next(r for r in regions if r.region_type == "DOOR_REGION")
    assert door.metadata["negative_mask"] is False


def test_text_bbox_is_context_only_not_direct_quarantine_without_membership():
    drawing = _drawing(
        texts=[
            DrawingText(
                id="TXT",
                text="A101",
                bbox=DrawingBBox(x_min=50, y_min=50, x_max=100, y_max=70),
                sources=["PYMUPDF"],
            )
        ]
    )
    region = next(
        r for r in ElementContextDetector().detect(drawing=drawing, scale_profile=_profile())
        if r.region_type == "TEXT_SYMBOL_REGION"
    )
    candidate = _candidate("C", (45, 60), (110, 60), face_ids=["UNRELATED"], metric=0.95)
    decision = CandidateContextGate().apply(candidates=[candidate], regions=[region]).decisions[0]
    assert decision.state != "QUARANTINE"
