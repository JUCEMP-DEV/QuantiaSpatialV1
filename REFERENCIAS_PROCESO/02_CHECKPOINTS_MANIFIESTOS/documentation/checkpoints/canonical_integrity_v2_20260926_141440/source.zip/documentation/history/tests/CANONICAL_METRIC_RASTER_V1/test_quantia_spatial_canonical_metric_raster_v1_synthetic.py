from __future__ import annotations

import pymupdf

from app.quantia_spatialV1.engine import QuantiaSpatialEngine


def _pdf_declared_scale_1_50() -> bytes:
    document = pymupdf.open()
    page = document.new_page(width=612, height=792)
    page.insert_text((40, 40), "PLANTA BAJA   ESCALA 1:50", fontsize=12)
    shape = page.new_shape()
    shape.draw_rect(pymupdf.Rect(100, 150, 500, 550))
    shape.draw_line((300, 150), (300, 550))
    shape.draw_line((100, 350), (500, 350))
    shape.finish(width=2)
    shape.commit()
    data = document.tobytes()
    document.close()
    return data


def test_engine_publica_levelview_normalizado_y_recalcula_f015_f02() -> None:
    result = QuantiaSpatialEngine().run(
        document_bytes=_pdf_declared_scale_1_50(),
        media_mime_type="application/pdf",
        source_document_id="SYNTH_CANONICAL_RASTER_1_50",
        render_scale=0.7935,
        known_level_names_by_page={1: ["Planta Baja"]},
        isolated_pages={1},
        enable_gemini_discovery=False,
        enable_gemini_extraction=False,
    )

    assert result.raster_normalization is not None
    assert result.raster_normalization.state == "NORMALIZED"
    assert result.raster_normalization.page_render_scales[1] == 1.5875
    assert len(result.levels) == 1

    diagnostic = result.raster_normalization.levels[0]
    assert diagnostic.bootstrap_px_per_m is not None
    assert diagnostic.final_px_per_m is not None
    assert 44.0 < diagnostic.bootstrap_px_per_m < 46.0
    assert 89.0 < diagnostic.final_px_per_m < 91.0

    level_result = result.levels[0]
    assert level_result.level_view.id == diagnostic.level_view_id
    assert level_result.level_view.source_page_width_px == result.phase_01.page_results[0].source_page_width_px
    assert level_result.evidence.level_view_id == level_result.level_view.id
    assert level_result.perimeter.level_view_id == level_result.level_view.id


def test_engine_puede_desactivar_normalizacion_sin_alterar_bootstrap() -> None:
    result = QuantiaSpatialEngine().run(
        document_bytes=_pdf_declared_scale_1_50(),
        media_mime_type="application/pdf",
        source_document_id="SYNTH_CANONICAL_RASTER_DISABLED",
        render_scale=0.7935,
        known_level_names_by_page={1: ["Planta Baja"]},
        isolated_pages={1},
        enable_gemini_discovery=False,
        enable_gemini_extraction=False,
        enable_metric_raster_normalization=False,
    )

    assert result.raster_normalization is not None
    assert result.raster_normalization.state == "DISABLED"
    assert result.phase_01.level_views[0].source_page_width_px < 600
