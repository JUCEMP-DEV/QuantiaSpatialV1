from __future__ import annotations

import hashlib
import json
import math
import shutil
from dataclasses import dataclass
from pathlib import Path
from statistics import median
from typing import Iterable, Sequence

import cv2
import numpy as np
import pytest

from app.quantia_spatialV1.reconstruction_core import (
    DrawingModelBuilder,
    ProposalCReconstructionPipeline,
    ReferenceConstraintBuilder,
    WallCandidate,
    WallCandidateGenerator,
    WallEvidenceVector,
)
from app.quantia_spatialV1.reconstruction_core.drawing_model import DrawingLine, DrawingPoint
from app.quantia_spatialV1.reconstruction_core.wall_track_consolidator import WallTrackConsolidator
from app.quantia_spatialV1.tests.quantia_case_loader import CASE_LOADERS, LoadedCase


PROBE_VERSION = "PERIMETER_WALL_TRACKS_ALL_3_V2"
BASELINE = (
    "PERIMETER_WALL_TRACKS_V1 + "
    "WALL_CANONICALIZATION_ISOLATED_V1 + "
    "CANONICAL_METRIC_RASTER_V2_3_VALIDATED"
)
CASE_IDS = ("casa_viri", "miguel_h", "miguel_v")
TARGET_PX_PER_M = 90.0
TARGET_RELATIVE_TOLERANCE = 0.05

TESTS_DIR = Path(__file__).resolve().parent
OUTPUT_ROOT = TESTS_DIR / "output" / "perimeter_wall_tracks_v2"


@dataclass(frozen=True)
class _PhysicalWall:
    wall_id: str
    start: tuple[float, float]
    end: tuple[float, float]
    length_px: float
    thickness_px: float
    confidence: float | None
    source_candidate_ids: tuple[str, ...]
    evidence_ids: tuple[str, ...]
    source_names: tuple[str, ...]
    generator_names: tuple[str, ...]
    region_support: float
    thickness_support: float
    vector_support: float
    raster_line_support: float
    source_consensus: float
    axis_support: float
    dashed_penalty: float


@dataclass(frozen=True)
class _PerimeterTrack:
    wall_id: str
    start: tuple[float, float]
    end: tuple[float, float]
    length_px: float
    thickness_px: float
    confidence: float | None
    source_candidate_ids: tuple[str, ...]
    evidence_ids: tuple[str, ...]
    source_names: tuple[str, ...]
    generator_names: tuple[str, ...]
    dominant_side: str
    side_votes: dict[str, int]


@dataclass(frozen=True)
class _MaskBundle:
    wall_mask: np.ndarray
    closed_mask: np.ndarray
    footprint_mask: np.ndarray


# V2 elimina la circularidad de V1: ya no usa level.walls / PERIMETER F02 como
# semilla. Descubre WallTracks físicos desde DrawingModel/F01.5 y solo utiliza
# F02 para la escala compartida del proyecto.


def _safe(value: str) -> str:
    text = "".join(ch.lower() if ch.isalnum() else "_" for ch in value.strip())
    while "__" in text:
        text = text.replace("__", "_")
    return text.strip("_") or "level"



def _decode(data: bytes) -> np.ndarray:
    image = cv2.imdecode(np.frombuffer(data, dtype=np.uint8), cv2.IMREAD_COLOR)
    if image is None:
        raise RuntimeError("No se pudo decodificar LevelView raster.")
    return image



def _vector(segment: _PhysicalWall | _PerimeterTrack) -> tuple[float, float, float]:
    dx = float(segment.end[0] - segment.start[0])
    dy = float(segment.end[1] - segment.start[1])
    length = max(math.hypot(dx, dy), 1e-9)
    ux, uy = dx / length, dy / length
    if ux < -1e-9 or (abs(ux) <= 1e-9 and uy < 0.0):
        ux, uy = -ux, -uy
    return ux, uy, length



def _draw_segment(image, start, end, color, thickness):
    cv2.line(
        image,
        (int(round(start[0])), int(round(start[1]))),
        (int(round(end[0])), int(round(end[1]))),
        color,
        thickness,
        cv2.LINE_AA,
    )



def _candidate_line(candidate: WallCandidate) -> DrawingLine:
    return DrawingLine(
        id=candidate.id,
        start=DrawingPoint(x=float(candidate.start.x), y=float(candidate.start.y)),
        end=DrawingPoint(x=float(candidate.end.x), y=float(candidate.end.y)),
        length_px=float(candidate.length_px),
        angle_deg=float(candidate.angle_deg),
        stroke_width_px=float(candidate.thickness_px),
        dashed=bool(candidate.evidence.dashed_penalty >= 0.95),
        evidence_ids=list(candidate.evidence_ids),
        sources=list(candidate.source_names),
        confidence=float(candidate.prior_score),
        metadata=dict(candidate.metadata),
    )



def _build_raw_candidates(*, level_result, scale_profile) -> list[WallCandidate]:
    generator = WallCandidateGenerator()
    drawing_builder = DrawingModelBuilder()
    constraint_builder = ReferenceConstraintBuilder()

    drawing = drawing_builder.build(
        level_view=level_result.level_view,
        evidence=list(level_result.evidence.evidence),
    )
    constraints = constraint_builder.build(
        level_view=level_result.level_view,
        evidence=list(level_result.evidence.evidence),
    )

    mask = generator._mask(drawing)
    face_lines = [item for item in drawing.lines if item.kind == "LINE"]
    region_lines = [item for item in drawing.lines if item.kind == "REGION_CENTERLINE"]
    representatives = generator._representative_lines(face_lines, drawing=drawing)
    profiles = generator._thickness_profiles(representatives, drawing=drawing)

    min_dim = min(drawing.width_px, drawing.height_px)
    minimum_length = max(12.0, min_dim * 0.022)
    max_thickness = max(12.0, min_dim * 0.040)
    minimum_thickness = max(1.5, min_dim * 0.0012)

    candidates: list[WallCandidate] = []
    for i, first in enumerate(representatives):
        for second in representatives[i + 1 :]:
            if generator._angle_diff(first.angle_deg, second.angle_deg) > generator.ANGLE_TOLERANCE_DEG:
                continue
            overlap = generator._overlap_ratio(first, second)
            if overlap < 0.48:
                continue
            thickness = generator._line_distance(first, second)
            if thickness < minimum_thickness or thickness > max_thickness:
                continue
            center = generator._center_overlap_segment(first, second)
            if center is None:
                continue
            start, end, length, angle = center
            if length < minimum_length:
                continue

            region_support = generator._region_support(
                start=start,
                end=end,
                thickness=thickness,
                mask=mask,
            )
            if region_support < 0.34:
                continue

            thickness_support = generator._thickness_support(thickness, profiles)
            sources = sorted({*first.sources, *second.sources})
            vector_support = float(any(source == "PYMUPDF" for source in sources))
            raster_support = float(any(source in {"OPENCV", "LSD_LOCAL"} for source in sources))
            source_consensus = generator._source_consensus(sources)
            dashed_penalty = 1.0 if first.dashed and second.dashed else (0.5 if first.dashed or second.dashed else 0.0)
            axis_support = generator._axis_support(
                start=start,
                end=end,
                thickness=thickness,
                constraints=constraints,
            )

            # Filtro duro V2: sin región, sin familia de espesor o todo dashed,
            # no se promueve a muro físico. Esto elimina ejes/cotas y bordos.
            if thickness_support < 0.33:
                continue
            if dashed_penalty >= 0.95:
                continue
            if vector_support <= 0.0 and raster_support <= 0.0:
                continue

            candidate_evidence = WallEvidenceVector(
                pair_overlap=overlap,
                thickness_support=thickness_support,
                vector_support=vector_support,
                raster_line_support=raster_support,
                region_support=region_support,
                source_consensus=source_consensus,
                perimeter_containment=1.0,
                semantic_support=0.0,
                axis_support=axis_support,
                dashed_penalty=dashed_penalty,
            )
            independent_sources = len(generator._independent_source_groups(sources))
            length_target = max(4.0 * thickness, min_dim * 0.055)
            length_support = max(0.0, min(1.0, length / max(length_target, 1.0)))
            prior = generator.fusion.prior(
                candidate_evidence,
                generator="DOUBLE_FACE",
                independent_source_count=independent_sources,
                length_support=length_support,
            )
            # Penaliza fuerte líneas con soporte de eje dominante.
            prior *= max(0.25, 1.0 - 0.55 * axis_support)

            ident = hashlib.sha1(
                f"{drawing.level_view_id}|PAIRNP|{first.id}|{second.id}|{start.x:.2f}|{start.y:.2f}|{end.x:.2f}|{end.y:.2f}".encode()
            ).hexdigest()[:16]
            candidates.append(
                WallCandidate(
                    id=f"{drawing.level_view_id}__WC_PERIM2_PAIR__{ident}",
                    generator="DOUBLE_FACE",
                    start=start,
                    end=end,
                    angle_deg=angle,
                    length_px=length,
                    thickness_px=thickness,
                    face_ids=[first.id, second.id],
                    evidence_ids=sorted({*first.evidence_ids, *second.evidence_ids}),
                    source_names=sources,
                    evidence=candidate_evidence,
                    prior_score=max(0.0, min(1.0, prior)),
                    metadata={
                        "face_a": first.id,
                        "face_b": second.id,
                        "lineage_line_ids": sorted(
                            generator._line_lineage_ids(first) | generator._line_lineage_ids(second)
                        ),
                    },
                )
            )

    region_min_length = max(14.0, min_dim * 0.018)
    for region in region_lines:
        if region.length_px < region_min_length:
            continue
        estimated = float(region.metadata.get("estimated_thickness_px") or 0.0)
        if estimated <= 0.0:
            estimated = profiles[0][0]
        aligned_faces = [
            line for line in representatives
            if generator._angle_diff(line.angle_deg, region.angle_deg) <= generator.ANGLE_TOLERANCE_DEG
            and generator._line_distance(line, region) <= max(estimated * 1.5, 5.0)
            and generator._overlap_ratio(line, region) >= 0.35
        ]
        region_support = generator._region_support(
            start=region.start,
            end=region.end,
            thickness=max(estimated, 2.0),
            mask=mask,
        )
        thickness_support = generator._thickness_support(estimated, profiles)
        if region_support < 0.45 or thickness_support < 0.30:
            continue
        sources = sorted({source for item in aligned_faces for source in item.sources} | {"REGION_LOCAL"})
        vector_support = float(any("PYMUPDF" in item.sources for item in aligned_faces))
        raster_support = float(any(any(src in {"OPENCV", "LSD_LOCAL"} for src in item.sources) for item in aligned_faces))
        source_consensus = generator._source_consensus(sources)
        axis_support = generator._axis_support(
            start=region.start,
            end=region.end,
            thickness=max(estimated, 2.0),
            constraints=constraints,
        )
        candidate_evidence = WallEvidenceVector(
            pair_overlap=0.0,
            thickness_support=thickness_support,
            vector_support=vector_support,
            raster_line_support=raster_support,
            region_support=region_support,
            source_consensus=source_consensus,
            perimeter_containment=1.0,
            semantic_support=0.0,
            axis_support=axis_support,
            dashed_penalty=0.0,
        )
        independent_sources = len(generator._independent_source_groups(sources))
        length_target = max(5.0 * estimated, min_dim * 0.060)
        length_support = max(0.0, min(1.0, region.length_px / max(length_target, 1.0)))
        prior = generator.fusion.prior(
            candidate_evidence,
            generator="REGION_CENTERLINE",
            independent_source_count=independent_sources,
            length_support=length_support,
        )
        prior *= max(0.25, 1.0 - 0.60 * axis_support)
        ident = hashlib.sha1(
            f"{drawing.level_view_id}|REGIONNP|{region.id}|{region.start.x:.2f}|{region.start.y:.2f}|{region.end.x:.2f}|{region.end.y:.2f}".encode()
        ).hexdigest()[:16]
        candidates.append(
            WallCandidate(
                id=f"{drawing.level_view_id}__WC_PERIM2_REGION__{ident}",
                generator="REGION_CENTERLINE",
                start=region.start,
                end=region.end,
                angle_deg=region.angle_deg,
                length_px=region.length_px,
                thickness_px=max(estimated, 1.0),
                face_ids=[item.id for item in aligned_faces[:8]],
                evidence_ids=sorted({eid for item in aligned_faces for eid in item.evidence_ids}),
                source_names=sources,
                evidence=candidate_evidence,
                prior_score=max(0.0, min(1.0, prior)),
                metadata={
                    "region_line_id": region.id,
                    "lineage_line_ids": sorted({
                        lineage_id
                        for item in aligned_faces[:8]
                        for lineage_id in generator._line_lineage_ids(item)
                    }),
                },
            )
        )

    candidates = generator._dedupe_candidates(candidates)
    # Filtro final conservador.
    filtered = [
        item
        for item in candidates
        if item.prior_score >= 0.34
        and item.evidence.region_support >= 0.34
        and item.evidence.dashed_penalty < 0.95
        and (item.evidence.vector_support > 0.0 or item.evidence.raster_line_support > 0.0)
    ]
    consolidated = WallTrackConsolidator().consolidate(
        candidates=filtered,
        width_px=drawing.width_px,
        height_px=drawing.height_px,
    )
    return consolidated



def _physical_walls(candidates: Sequence[WallCandidate]) -> list[_PhysicalWall]:
    output: list[_PhysicalWall] = []
    for index, item in enumerate(sorted(candidates, key=lambda c: (round(c.start.y, 3), round(c.start.x, 3), c.id)), 1):
        merged_from = item.metadata.get("consolidated_from")
        source_ids = tuple(sorted(str(v) for v in merged_from)) if isinstance(merged_from, list) else (item.id,)
        generator_names = {item.generator}
        if isinstance(item.metadata.get("consolidated_from"), list):
            generator_names.add(item.generator)
        output.append(
            _PhysicalWall(
                wall_id=f"PW_{index:03d}",
                start=(float(item.start.x), float(item.start.y)),
                end=(float(item.end.x), float(item.end.y)),
                length_px=float(item.length_px),
                thickness_px=float(item.thickness_px),
                confidence=float(item.prior_score),
                source_candidate_ids=source_ids,
                evidence_ids=tuple(sorted(str(v) for v in item.evidence_ids)),
                source_names=tuple(sorted(str(v) for v in item.source_names)),
                generator_names=tuple(sorted(generator_names)),
                region_support=float(item.evidence.region_support),
                thickness_support=float(item.evidence.thickness_support),
                vector_support=float(item.evidence.vector_support),
                raster_line_support=float(item.evidence.raster_line_support),
                source_consensus=float(item.evidence.source_consensus),
                axis_support=float(item.evidence.axis_support),
                dashed_penalty=float(item.evidence.dashed_penalty),
            )
        )
    return output



def _wall_draw_thickness(item: _PhysicalWall | _PerimeterTrack, px_per_m: float) -> int:
    thickness = item.thickness_px if item.thickness_px and item.thickness_px > 0 else 0.12 * px_per_m
    return max(2, int(round(thickness)))



def _build_masks(*, walls: list[_PhysicalWall], shape: tuple[int, int], px_per_m: float) -> _MaskBundle:
    height, width = shape
    wall_mask = np.zeros((height, width), dtype=np.uint8)
    for item in walls:
        _draw_segment(
            wall_mask,
            item.start,
            item.end,
            255,
            _wall_draw_thickness(item, px_per_m),
        )

    close_kernel = max(3, int(round(0.10 * px_per_m)))
    if close_kernel % 2 == 0:
        close_kernel += 1
    kernel = np.ones((close_kernel, close_kernel), dtype=np.uint8)
    closed = cv2.morphologyEx(wall_mask, cv2.MORPH_CLOSE, kernel, iterations=1)
    closed = cv2.dilate(closed, np.ones((3, 3), dtype=np.uint8), iterations=1)

    flood = closed.copy()
    flood_mask = np.zeros((height + 2, width + 2), dtype=np.uint8)
    cv2.floodFill(flood, flood_mask, (0, 0), 128)
    footprint = np.where(flood == 128, 0, 255).astype(np.uint8)

    num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(footprint, connectivity=8)
    if num_labels > 1:
        best_label = max(range(1, num_labels), key=lambda idx: int(stats[idx, cv2.CC_STAT_AREA]))
        footprint = np.where(labels == best_label, 255, 0).astype(np.uint8)

    return _MaskBundle(wall_mask=wall_mask, closed_mask=closed, footprint_mask=footprint)



def _inside(mask: np.ndarray, point: tuple[float, float]) -> bool:
    x = int(round(point[0]))
    y = int(round(point[1]))
    if x < 0 or y < 0 or y >= mask.shape[0] or x >= mask.shape[1]:
        return False
    return bool(mask[y, x] > 0)



def _sample_votes(*, wall: _PhysicalWall, footprint_mask: np.ndarray, px_per_m: float) -> tuple[str | None, dict[str, int]]:
    ux, uy, length = _vector(wall)
    nx, ny = -uy, ux
    half_thickness = max(wall.thickness_px * 0.5, 1.0)
    sample_offset = half_thickness + max(2.0, 0.05 * px_per_m)
    sample_ts = (0.15, 0.30, 0.50, 0.70, 0.85) if length >= 12.0 else (0.50,)

    votes = {"LEFT_INSIDE": 0, "RIGHT_INSIDE": 0, "BOTH_INSIDE": 0, "BOTH_OUTSIDE": 0}
    for t in sample_ts:
        cx = wall.start[0] + (wall.end[0] - wall.start[0]) * t
        cy = wall.start[1] + (wall.end[1] - wall.start[1]) * t
        left = (cx + nx * sample_offset, cy + ny * sample_offset)
        right = (cx - nx * sample_offset, cy - ny * sample_offset)
        left_inside = _inside(footprint_mask, left)
        right_inside = _inside(footprint_mask, right)
        if left_inside and not right_inside:
            votes["LEFT_INSIDE"] += 1
        elif right_inside and not left_inside:
            votes["RIGHT_INSIDE"] += 1
        elif left_inside and right_inside:
            votes["BOTH_INSIDE"] += 1
        else:
            votes["BOTH_OUTSIDE"] += 1

    dominant = max(("LEFT_INSIDE", "RIGHT_INSIDE"), key=lambda key: votes[key])
    dominant_votes = votes[dominant]
    total = len(sample_ts)
    if dominant_votes >= max(1, math.ceil(total * 0.60)) and votes["BOTH_OUTSIDE"] <= 1:
        return dominant, votes
    return None, votes



def _infer_perimeter_tracks(*, physical: list[_PhysicalWall], footprint_mask: np.ndarray, px_per_m: float) -> list[_PerimeterTrack]:
    output: list[_PerimeterTrack] = []
    for wall in physical:
        dominant_side, votes = _sample_votes(wall=wall, footprint_mask=footprint_mask, px_per_m=px_per_m)
        if dominant_side is None:
            continue
        # Filtro adicional V2: evita tracks dominados por soporte de eje.
        if wall.axis_support >= 0.75 and wall.region_support < 0.60 and wall.vector_support <= 0.0:
            continue
        output.append(
            _PerimeterTrack(
                wall_id=f"PT_{len(output)+1:03d}",
                start=wall.start,
                end=wall.end,
                length_px=wall.length_px,
                thickness_px=wall.thickness_px,
                confidence=wall.confidence,
                source_candidate_ids=wall.source_candidate_ids,
                evidence_ids=wall.evidence_ids,
                source_names=wall.source_names,
                generator_names=wall.generator_names,
                dominant_side=dominant_side,
                side_votes=votes,
            )
        )
    return output



def _draw_physical(image, walls: list[_PhysicalWall], px_per_m: float) -> None:
    for wall in walls:
        _draw_segment(image, wall.start, wall.end, (0, 0, 0), _wall_draw_thickness(wall, px_per_m))



def _draw_perimeter(image, walls: list[_PerimeterTrack], px_per_m: float) -> None:
    for wall in walls:
        _draw_segment(image, wall.start, wall.end, (0, 0, 0), max(3, _wall_draw_thickness(wall, px_per_m)))



def _draw_perimeter_overlay(image, walls: list[_PerimeterTrack], px_per_m: float) -> None:
    for wall in walls:
        _draw_segment(image, wall.start, wall.end, (0, 0, 255), max(3, _wall_draw_thickness(wall, px_per_m)))



def _serialize_physical(item: _PhysicalWall) -> dict:
    return {
        "id": item.wall_id,
        "start": [item.start[0], item.start[1]],
        "end": [item.end[0], item.end[1]],
        "length_px": item.length_px,
        "thickness_px": item.thickness_px,
        "confidence": item.confidence,
        "source_candidate_ids": list(item.source_candidate_ids),
        "evidence_ids": list(item.evidence_ids),
        "source_names": list(item.source_names),
        "generator_names": list(item.generator_names),
        "region_support": item.region_support,
        "thickness_support": item.thickness_support,
        "vector_support": item.vector_support,
        "raster_line_support": item.raster_line_support,
        "source_consensus": item.source_consensus,
        "axis_support": item.axis_support,
        "dashed_penalty": item.dashed_penalty,
    }



def _serialize_perimeter(item: _PerimeterTrack) -> dict:
    return {
        "id": item.wall_id,
        "start": [item.start[0], item.start[1]],
        "end": [item.end[0], item.end[1]],
        "length_px": item.length_px,
        "thickness_px": item.thickness_px,
        "confidence": item.confidence,
        "source_candidate_ids": list(item.source_candidate_ids),
        "evidence_ids": list(item.evidence_ids),
        "source_names": list(item.source_names),
        "generator_names": list(item.generator_names),
        "dominant_side": item.dominant_side,
        "side_votes": item.side_votes,
    }



def _run_level(*, loaded, output_dir: Path, case_id: str, scale_profile) -> dict:
    level_result = loaded.level_result
    px_per_m = 1.0 / float(scale_profile.local_m_per_px)
    candidate_tracks = _build_raw_candidates(level_result=level_result, scale_profile=scale_profile)
    physical = _physical_walls(candidate_tracks)
    assert physical, "No se generaron WallTracks físicos V2."

    raster = _decode(level_result.level_view.raster_bytes)
    masks = _build_masks(walls=physical, shape=raster.shape[:2], px_per_m=px_per_m)
    inferred = _infer_perimeter_tracks(physical=physical, footprint_mask=masks.footprint_mask, px_per_m=px_per_m)
    assert inferred, "No se infirieron tracks perimetrales V2."

    white = np.full_like(raster, 255)
    faded = cv2.addWeighted(raster, 0.15, np.full_like(raster, 255), 0.85, 0.0)

    all_tracks = white.copy()
    perimeter_clean = white.copy()
    overlay = faded.copy()
    footprint_visual = cv2.cvtColor(masks.footprint_mask, cv2.COLOR_GRAY2BGR)

    _draw_physical(all_tracks, physical, px_per_m)
    _draw_perimeter(perimeter_clean, inferred, px_per_m)
    _draw_perimeter_overlay(overlay, inferred, px_per_m)

    safe = _safe(loaded.level_name)
    tracks_path = output_dir / f"{case_id}__{safe}__all_physical_wall_tracks_v2.png"
    footprint_path = output_dir / f"{case_id}__{safe}__building_footprint_mask_v2.png"
    clean_path = output_dir / f"{case_id}__{safe}__perimeter_clean_v2.png"
    overlay_path = output_dir / f"{case_id}__{safe}__perimeter_overlay_v2.png"
    wall_mask_path = output_dir / f"{case_id}__{safe}__wall_mask_v2.png"
    closed_mask_path = output_dir / f"{case_id}__{safe}__closed_wall_mask_v2.png"

    cv2.imwrite(str(tracks_path), all_tracks)
    cv2.imwrite(str(footprint_path), footprint_visual)
    cv2.imwrite(str(clean_path), perimeter_clean)
    cv2.imwrite(str(overlay_path), overlay)
    cv2.imwrite(str(wall_mask_path), masks.wall_mask)
    cv2.imwrite(str(closed_mask_path), masks.closed_mask)

    return {
        "level": loaded.level_name,
        "level_view_id": level_result.level_view.id,
        "scale_profile": scale_profile.model_dump(mode="json"),
        "px_per_m": px_per_m,
        "candidate_track_count": len(candidate_tracks),
        "physical_wall_count": len(physical),
        "inferred_perimeter_count": len(inferred),
        "physical_walls": [_serialize_physical(item) for item in physical],
        "inferred_perimeter": [_serialize_perimeter(item) for item in inferred],
        "all_tracks_visual": str(tracks_path),
        "footprint_visual": str(footprint_path),
        "perimeter_clean_visual": str(clean_path),
        "perimeter_overlay_visual": str(overlay_path),
        "wall_mask_visual": str(wall_mask_path),
        "closed_mask_visual": str(closed_mask_path),
    }



def _run_case(case: LoadedCase) -> None:
    output_dir = OUTPUT_ROOT / case.case_id
    if output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    pipeline = ProposalCReconstructionPipeline()
    scale_inputs = []
    for loaded in case.levels:
        perimeter = loaded.level_result.perimeter.editable_perimeter
        assert perimeter is not None
        scale_inputs.append((loaded.level_result.level_view, perimeter))

    project_scale = pipeline.build_project_scale_context(levels=scale_inputs)
    assert project_scale.state == "RESOLVED"

    report = {
        "probe_version": PROBE_VERSION,
        "baseline": BASELINE,
        "case_id": case.case_id,
        "case": case.case_name,
        "gemini_calls_added": 0,
        "engine_files_modified": 0,
        "perimeter_strategy": "DRAWING_MODEL_DISCOVERY_NO_F02_PERIMETER_SEED",
        "visual_contract": {
            "main_validation_image": "perimeter_clean_v2.png",
            "style": "WHITE_BACKGROUND_BLACK_LINES",
        },
        "project_scale": project_scale.model_dump(mode="json"),
        "levels": [],
        "failures": [],
    }

    for loaded in case.levels:
        profile = project_scale.for_level(loaded.level_result.level_view.id)
        assert profile.local_m_per_px is not None
        px_per_m = 1.0 / profile.local_m_per_px
        relative_error = abs(px_per_m - TARGET_PX_PER_M) / TARGET_PX_PER_M
        if profile.state != "RESOLVED" or relative_error > TARGET_RELATIVE_TOLERANCE:
            report["failures"].append(
                f"{loaded.level_name}:SCALE_GUARD:{profile.state}:{px_per_m:.6f}"
            )
            continue

        level_report = _run_level(
            loaded=loaded,
            output_dir=output_dir,
            case_id=case.case_id,
            scale_profile=profile,
        )
        report["levels"].append(level_report)
        print("\n" + "=" * 100)
        print(f"PERIMETER WALL TRACKS V2 — {case.case_name} — {loaded.level_name}")
        print({
            "candidate_tracks": level_report["candidate_track_count"],
            "physical_walls": level_report["physical_wall_count"],
            "inferred_perimeter": level_report["inferred_perimeter_count"],
        })

    report["passed"] = not report["failures"]
    json_path = output_dir / f"{case.case_id}__perimeter_wall_tracks_v2.json"
    json_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\nJSON: {json_path}")
    assert not report["failures"], json.dumps(report["failures"], ensure_ascii=False)


@pytest.mark.parametrize("case_id", CASE_IDS)
def test_quantia_spatial_perimeter_wall_tracks_all_3_v2(case_id: str) -> None:
    _run_case(CASE_LOADERS[case_id]())


if __name__ == "__main__":
    for _case_id in CASE_IDS:
        _run_case(CASE_LOADERS[_case_id]())
