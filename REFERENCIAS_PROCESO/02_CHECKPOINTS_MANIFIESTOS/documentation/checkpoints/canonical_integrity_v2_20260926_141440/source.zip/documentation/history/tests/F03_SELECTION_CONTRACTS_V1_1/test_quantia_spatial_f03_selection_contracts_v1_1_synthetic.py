from __future__ import annotations

from app.quantia_spatialV1.reconstruction_core.candidate_context_gate import CandidateContextGate
from app.quantia_spatialV1.reconstruction_core.candidate_graph import WallCandidateGraphBuilder
from app.quantia_spatialV1.reconstruction_core.candidate_models import WallCandidate, WallEvidenceVector
from app.quantia_spatialV1.reconstruction_core.context_models import CandidateContextDecision, ContextRegion, RepetitiveAxisProfile
from app.quantia_spatialV1.reconstruction_core.drawing_model import DrawingBBox, DrawingPoint
from app.quantia_spatialV1.reconstruction_core.global_topology_solver import GlobalTopologySolver
from app.quantia_spatialV1.reconstruction_core.level_scale_normalizer import LevelScaleProfile
from app.quantia_spatialV1.reconstruction_core.reconstruction_pipeline import QuantiaReconstructionPipeline
from app.quantia_spatialV1.reconstruction_core.structural_lineage import StructuralLineageAnalyzer
from app.quantia_spatialV1.reconstruction_core.wall_candidate_generator import WallCandidateGenerator
from app.quantia_spatialV1.reconstruction_core.wall_track_consolidator import WallTrackConsolidator


def _candidate(
    candidate_id: str,
    *,
    x1: float = 10.0,
    y1: float = 10.0,
    x2: float = 210.0,
    y2: float = 10.0,
    thickness: float = 8.0,
    axis: float = 0.0,
    dashed: float = 0.0,
    metadata: dict | None = None,
    prior: float = 0.80,
) -> WallCandidate:
    dx = x2 - x1
    dy = y2 - y1
    angle = 0.0 if abs(dy) < 1e-9 else 90.0 if abs(dx) < 1e-9 else 45.0
    return WallCandidate(
        id=candidate_id,
        generator="DOUBLE_FACE",
        start=DrawingPoint(x=x1, y=y1),
        end=DrawingPoint(x=x2, y=y2),
        angle_deg=angle,
        length_px=(dx * dx + dy * dy) ** 0.5,
        thickness_px=thickness,
        face_ids=[f"{candidate_id}_A", f"{candidate_id}_B"],
        evidence_ids=[],
        source_names=["LSD_LOCAL", "OPENCV"],
        evidence=WallEvidenceVector(
            pair_overlap=0.96,
            thickness_support=0.88,
            vector_support=0.0,
            raster_line_support=1.0,
            region_support=0.92,
            source_consensus=0.50,
            perimeter_containment=1.0,
            semantic_support=0.0,
            axis_support=axis,
            dashed_penalty=dashed,
        ),
        prior_score=prior,
        metadata=metadata or {},
    )


def test_raster_algorithms_are_one_independent_modality() -> None:
    generator = WallCandidateGenerator()
    assert generator._independent_source_groups(["OPENCV", "LSD_LOCAL", "REGION_LOCAL"]) == {"RASTER"}
    assert generator._source_consensus(["OPENCV", "LSD_LOCAL", "REGION_LOCAL"]) == 0.50
    assert generator._independent_source_groups(["OPENCV", "LSD_LOCAL", "PYMUPDF"]) == {"RASTER", "VECTOR"}
    assert generator._source_consensus(["OPENCV", "LSD_LOCAL", "PYMUPDF"]) == 0.75


def test_axis_alone_cannot_create_strong_structural_lineage() -> None:
    candidate = _candidate("AXIS_ONLY", axis=0.99)
    lineage = StructuralLineageAnalyzer().analyze([candidate])[candidate.id]
    assert lineage.axis_support == 0.99
    assert lineage.collinear_anchor_support == 0.0
    assert lineage.junction_anchor_support == 0.0
    assert lineage.strong is False


def test_stair_orientation_mismatch_interior_is_quarantined() -> None:
    profile = RepetitiveAxisProfile(
        angle_deg=0.0,
        spacing_px=12.0,
        spacing_cv=0.04,
        member_count=8,
        median_length_px=100.0,
        common_span_ratio=0.95,
        length_similarity=0.95,
        track_coordinates=[100, 112, 124, 136, 148, 160, 172, 184],
        member_line_ids=[f"S{i}" for i in range(8)],
    )
    region = ContextRegion(
        id="STAIR_CTX",
        region_type="STAIR_FLIGHT_REGION",
        bbox=DrawingBBox(x_min=80, y_min=90, x_max=220, y_max=200),
        confidence=0.86,
        quarantine_enabled=True,
        profiles=[profile],
        member_line_ids=[f"S{i}" for i in range(8)],
    )
    candidate = _candidate(
        "VERTICAL_INSIDE_STAIR",
        x1=150.0,
        y1=100.0,
        x2=150.0,
        y2=190.0,
        axis=0.0,
    )
    result = CandidateContextGate().apply(candidates=[candidate], regions=[region])
    decision = result.decisions[0]
    assert decision.state == "QUARANTINE"
    assert decision.region_type == "STAIR_FLIGHT_REGION"
    assert decision.context_risk > 0.0


def test_same_noise_region_cannot_self_reward_with_junction() -> None:
    metadata = {
        "context_state": "REVIEW",
        "context_region_id": "STAIR_1",
        "context_region_type": "STAIR_FLIGHT_REGION",
        "context_risk": 0.80,
    }
    horizontal = _candidate(
        "H",
        x1=100.0,
        y1=100.0,
        x2=220.0,
        y2=100.0,
        metadata=metadata,
    )
    vertical = _candidate(
        "V",
        x1=100.0,
        y1=100.0,
        x2=100.0,
        y2=220.0,
        metadata=metadata,
    )
    graph = WallCandidateGraphBuilder().build(level_view_id="LV", candidates=[horizontal, vertical])
    assert all(relation.relation_type != "JUNCTION" for relation in graph.relations)


def test_dashed_reference_has_materially_lower_unary_score() -> None:
    solver = GlobalTopologySolver()
    solid = _candidate("SOLID", axis=0.80, dashed=0.0)
    dashed = _candidate("DASHED", axis=0.80, dashed=0.5)
    assert solver._unary(dashed, topology_degree=2) < solver._unary(solid, topology_degree=2) - 0.20


def test_metric_thickness_is_soft_evidence_not_hard_exclusion() -> None:
    profile = LevelScaleProfile(
        level_view_id="LV",
        state="RESOLVED",
        local_m_per_px=1.0 / 90.0,
        canonical_m_per_px=1.0 / 90.0,
        scale_factor_to_canonical=1.0,
        local_min_dim_px=1000.0,
        normalized_min_dim_px=1000.0,
        project_reference_min_dim_normalized_px=1000.0,
        project_reference_area_normalized_px2=1_000_000.0,
        source="CANONICAL_METRIC_RASTER_V2",
        confidence=1.0,
    )
    thin = _candidate("THIN", thickness=2.0)
    plausible = _candidate("PLAUSIBLE", thickness=12.0)
    annotated = QuantiaReconstructionPipeline._annotate_metric_thickness(
        candidates=[thin, plausible],
        scale_profile=profile,
    )
    by_id = {item.id: item for item in annotated}
    assert 0.0 < by_id["THIN"].metadata["metric_thickness_support"] < 0.5
    assert by_id["PLAUSIBLE"].metadata["metric_thickness_support"] == 1.0
    solver = GlobalTopologySolver()
    assert solver._metric_thickness_penalty(by_id["THIN"]) > solver._metric_thickness_penalty(by_id["PLAUSIBLE"])


def test_track_consolidation_does_not_reward_fragment_count() -> None:
    first = _candidate(
        "F1", x1=10.0, y1=50.0, x2=60.0, y2=50.0, axis=1.0, prior=0.90
    )
    second = _candidate(
        "F2", x1=65.0, y1=50.0, x2=215.0, y2=50.0, axis=0.0, prior=0.50
    )
    merged = WallTrackConsolidator().consolidate(
        candidates=[first, second],
        width_px=500,
        height_px=300,
    )
    assert len(merged) == 1
    track = merged[0]
    assert abs(track.prior_score - 0.60) < 1e-6
    assert abs(track.evidence.axis_support - 0.25) < 1e-6
    assert track.metadata["fragment_count"] == 2


def test_review_candidate_cannot_be_anchor_for_same_pattern() -> None:
    fragment = _candidate("FRAGMENT", x1=10.0, y1=80.0, x2=60.0, y2=80.0, axis=0.60)
    long_noise = _candidate("LONG_NOISE", x1=65.0, y1=80.0, x2=365.0, y2=80.0, axis=0.95)
    decisions = {
        "FRAGMENT": CandidateContextDecision(
            candidate_id="FRAGMENT",
            state="REVIEW",
            reason="AMBIGUOUS_FLOOR_FINISH_GRID_REGION",
            region_id="GRID_1",
            region_type="FLOOR_FINISH_GRID_REGION",
            region_confidence=0.90,
            spatial_containment=1.0,
            face_pattern_support=1.0,
        ),
        "LONG_NOISE": CandidateContextDecision(
            candidate_id="LONG_NOISE",
            state="REVIEW",
            reason="AMBIGUOUS_FLOOR_FINISH_GRID_REGION",
            region_id="GRID_1",
            region_type="FLOOR_FINISH_GRID_REGION",
            region_confidence=0.90,
            spatial_containment=1.0,
            face_pattern_support=1.0,
        ),
    }
    lineage = StructuralLineageAnalyzer().analyze(
        [fragment, long_noise],
        decisions=decisions,
    )["FRAGMENT"]
    assert lineage.collinear_anchor_support == 0.0
    assert lineage.strong is False


def test_axis_region_without_reference_evidence_has_zero_context_risk() -> None:
    decision = CandidateContextDecision(
        candidate_id="W",
        state="ACTIVE",
        reason="ACTIVE_AXIS_REFERENCE_REGION",
        region_id="AXIS_CTX",
        region_type="AXIS_GRID_REGION",
        region_confidence=0.96,
        spatial_containment=1.0,
        face_pattern_support=0.0,
        metadata={"reference_support": 0.0},
    )
    assert CandidateContextGate._context_risk(decision) == 0.0


def test_stair_boundary_candidate_with_metric_band_stays_reviewable() -> None:
    profile = RepetitiveAxisProfile(
        angle_deg=0.0,
        spacing_px=12.0,
        spacing_cv=0.04,
        member_count=8,
        median_length_px=100.0,
        common_span_ratio=0.95,
        length_similarity=0.95,
        track_coordinates=[100, 112, 124, 136, 148, 160, 172, 184],
        member_line_ids=[f"S{i}" for i in range(8)],
    )
    region = ContextRegion(
        id="STAIR_CTX_BOUNDARY",
        region_type="STAIR_FLIGHT_REGION",
        bbox=DrawingBBox(x_min=80, y_min=90, x_max=220, y_max=200),
        confidence=0.90,
        quarantine_enabled=True,
        profiles=[profile],
        member_line_ids=[f"S{i}" for i in range(8)],
    )
    candidate = _candidate(
        "BOUNDARY_WALL",
        x1=82.0, y1=95.0, x2=82.0, y2=195.0,
        thickness=12.0,
        metadata={"metric_thickness_support": 1.0},
    )
    decision = CandidateContextGate().apply(candidates=[candidate], regions=[region]).decisions[0]
    assert decision.state == "REVIEW"
    assert decision.metadata["region_boundary_support"] >= 0.55


def test_high_confidence_floor_interior_is_quarantined_without_face_membership() -> None:
    region = ContextRegion(
        id="FLOOR_GRID",
        region_type="FLOOR_FINISH_GRID_REGION",
        bbox=DrawingBBox(x_min=50, y_min=50, x_max=250, y_max=250),
        confidence=0.98,
        quarantine_enabled=True,
        profiles=[],
        member_line_ids=[],
    )
    candidate = _candidate(
        "TILE_INTERIOR",
        x1=90.0, y1=140.0, x2=210.0, y2=140.0,
        thickness=12.0,
        metadata={"metric_thickness_support": 1.0},
    )
    decision = CandidateContextGate().apply(candidates=[candidate], regions=[region]).decisions[0]
    assert decision.state == "QUARANTINE"
    assert decision.reason == "QUARANTINE_HIGH_CONFIDENCE_FLOOR_INTERIOR"


def test_floor_boundary_candidate_remains_reviewable() -> None:
    region = ContextRegion(
        id="FLOOR_GRID_BOUNDARY",
        region_type="FLOOR_FINISH_GRID_REGION",
        bbox=DrawingBBox(x_min=50, y_min=50, x_max=250, y_max=250),
        confidence=0.98,
        quarantine_enabled=True,
        profiles=[],
        member_line_ids=[],
    )
    candidate = _candidate(
        "ROOM_BOUNDARY",
        x1=52.0, y1=70.0, x2=52.0, y2=230.0,
        thickness=12.0,
        metadata={"metric_thickness_support": 1.0},
    )
    decision = CandidateContextGate().apply(candidates=[candidate], regions=[region]).decisions[0]
    assert decision.state == "REVIEW"
    assert decision.reason == "REVIEW_FLOOR_REGION_BOUNDARY_WALL_CANDIDATE"


def test_axis_region_uses_metric_thinness_as_reference_evidence() -> None:
    region = ContextRegion(
        id="AXIS_GRID",
        region_type="AXIS_GRID_REGION",
        bbox=DrawingBBox(x_min=0, y_min=0, x_max=300, y_max=300),
        confidence=0.96,
        quarantine_enabled=True,
        profiles=[],
        member_line_ids=[],
    )
    candidate = _candidate(
        "THIN_AXIS_LINE",
        x1=20.0, y1=120.0, x2=280.0, y2=120.0,
        thickness=2.0, axis=0.95,
        metadata={"metric_thickness_support": 0.10},
    )
    decision = CandidateContextGate().apply(candidates=[candidate], regions=[region]).decisions[0]
    assert decision.state == "QUARANTINE"
    assert decision.metadata["thin_axis_reference_support"] > 0.80


def test_metric_thickness_materially_controls_unary_identity() -> None:
    solver = GlobalTopologySolver()
    thin = _candidate(
        "METRIC_THIN", axis=0.80,
        metadata={"metric_thickness_support": 0.10},
    )
    plausible = _candidate(
        "METRIC_PLAUSIBLE", axis=0.80,
        metadata={"metric_thickness_support": 1.0},
    )
    assert solver._unary(thin, topology_degree=0) < 0.0
    assert solver._unary(plausible, topology_degree=0) > solver._unary(thin, topology_degree=0) + 0.70
