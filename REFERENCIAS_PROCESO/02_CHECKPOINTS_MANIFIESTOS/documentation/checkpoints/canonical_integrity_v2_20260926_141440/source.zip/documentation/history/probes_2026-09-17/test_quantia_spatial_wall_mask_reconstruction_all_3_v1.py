from __future__ import annotations

import json
import math
import shutil
from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np
import pytest
from shapely.geometry import LineString, Point

from app.quantia_spatialV1.reconstruction_core import ProposalCReconstructionPipeline
from app.quantia_spatialV1.tests.quantia_case_loader import CASE_LOADERS, LoadedCase
from app.quantia_spatialV1.tests.test_quantia_spatial_perimeter_wall_tracks_all_3_v2 import (
    _build_raw_candidates,
    _decode,
    _draw_segment,
    _physical_walls,
    _safe,
    _wall_draw_thickness,
)


PROBE_VERSION = "WALL_MASK_RECONSTRUCTION_ALL_3_V1"
BASELINE = (
    "PERIMETER_WALL_TRACKS_V2_HOTFIX1 + "
    "WALL_CANONICALIZATION_ISOLATED_V1 + "
    "CANONICAL_METRIC_RASTER_V2_3_VALIDATED"
)
CASE_IDS = ("casa_viri", "miguel_h", "miguel_v")
TARGET_PX_PER_M = 90.0
TARGET_RELATIVE_TOLERANCE = 0.05

TESTS_DIR = Path(__file__).resolve().parent
OUTPUT_ROOT = TESTS_DIR / "output" / "wall_mask_reconstruction_v1"


@dataclass(frozen=True)
class _VirtualBridge:
    bridge_id: str
    kind: str
    start: tuple[float, float]
    end: tuple[float, float]
    gap_px: float
    wall_ids: tuple[str, ...]


@dataclass(frozen=True)
class _SpaceTopology:
    labels: np.ndarray
    exterior_labels: frozenset[int]
    interior_labels: frozenset[int]
    areas_px2: dict[int, int]


@dataclass(frozen=True)
class _WallRole:
    wall_id: str
    role: str
    confidence: float
    perimeter_votes: int
    divider_votes: int
    review_votes: int
    left_labels: tuple[int, ...]
    right_labels: tuple[int, ...]


# Objetivo del probe:
#   F01.5/DrawingModel -> WallTracks físicos -> continuidad lógica -> espacios
#   -> adyacencia de cada muro -> PERIMETER/DIVIDER/REVIEW.
#
# El footprint NO genera muros y NO decide el perímetro. Solo se publica una
# máscara de espacios derivada de la red de muros. Los puentes lógicos sirven
# para topología y jamás se dibujan en el plano limpio como muro sólido.


def _line(wall) -> LineString:
    return LineString([wall.start, wall.end])


def _vector(wall) -> tuple[float, float, float]:
    dx = float(wall.end[0] - wall.start[0])
    dy = float(wall.end[1] - wall.start[1])
    length = max(math.hypot(dx, dy), 1e-9)
    ux, uy = dx / length, dy / length
    if ux < -1e-9 or (abs(ux) <= 1e-9 and uy < 0.0):
        ux, uy = -ux, -uy
    return ux, uy, length


def _angle_deg(wall) -> float:
    ux, uy, _ = _vector(wall)
    return math.degrees(math.atan2(uy, ux)) % 180.0


def _angle_diff(a: float, b: float) -> float:
    diff = abs((a - b) % 180.0)
    return min(diff, 180.0 - diff)


def _normal_offset(wall, ux: float, uy: float) -> float:
    nx, ny = -uy, ux
    mx = (wall.start[0] + wall.end[0]) * 0.5
    my = (wall.start[1] + wall.end[1]) * 0.5
    return mx * nx + my * ny


def _interval(wall, ux: float, uy: float) -> tuple[float, float]:
    values = (
        wall.start[0] * ux + wall.start[1] * uy,
        wall.end[0] * ux + wall.end[1] * uy,
    )
    return min(values), max(values)


def _collinear_bridge(first, second, *, px_per_m: float) -> _VirtualBridge | None:
    if _angle_diff(_angle_deg(first), _angle_deg(second)) > 4.0:
        return None

    ux, uy, _ = _vector(first)
    first_offset = _normal_offset(first, ux, uy)
    second_offset = _normal_offset(second, ux, uy)
    thickness = float(np.median([first.thickness_px, second.thickness_px]))
    lateral_limit = max(0.10 * px_per_m, 1.10 * thickness)
    if abs(first_offset - second_offset) > lateral_limit:
        return None

    a0, a1 = _interval(first, ux, uy)
    b0, b1 = _interval(second, ux, uy)
    if a1 < b0:
        t0, t1 = a1, b0
    elif b1 < a0:
        t0, t1 = b1, a0
    else:
        return None

    gap = t1 - t0
    min_gap = max(3.0, 0.06 * px_per_m)
    max_gap = 1.35 * px_per_m
    if gap < min_gap or gap > max_gap:
        return None

    nx, ny = -uy, ux
    offset = (first_offset + second_offset) * 0.5
    p0 = (ux * t0 + nx * offset, uy * t0 + ny * offset)
    p1 = (ux * t1 + nx * offset, uy * t1 + ny * offset)
    return _VirtualBridge(
        bridge_id=f"VB_COL_{first.wall_id}_{second.wall_id}",
        kind="COLLINEAR_LOGICAL_CONTINUITY",
        start=p0,
        end=p1,
        gap_px=float(gap),
        wall_ids=(first.wall_id, second.wall_id),
    )


def _junction_bridge(endpoint: tuple[float, float], host, *, source_id: str, px_per_m: float) -> _VirtualBridge | None:
    host_line = _line(host)
    point = Point(endpoint)
    projected = host_line.interpolate(host_line.project(point))
    distance = float(point.distance(projected))
    if distance <= 1e-6 or distance > 0.22 * px_per_m:
        return None
    return _VirtualBridge(
        bridge_id=f"VB_JNC_{source_id}_{host.wall_id}_{round(endpoint[0], 2)}_{round(endpoint[1], 2)}",
        kind="JUNCTION_LOGICAL_CONTINUITY",
        start=endpoint,
        end=(float(projected.x), float(projected.y)),
        gap_px=distance,
        wall_ids=(source_id, host.wall_id),
    )


def _virtual_bridges(walls, *, px_per_m: float) -> list[_VirtualBridge]:
    bridges: list[_VirtualBridge] = []
    seen: set[tuple] = set()

    for i, first in enumerate(walls):
        for second in walls[i + 1 :]:
            bridge = _collinear_bridge(first, second, px_per_m=px_per_m)
            if bridge is not None:
                key = (bridge.kind, tuple(sorted(bridge.wall_ids)), round(bridge.gap_px, 2))
                if key not in seen:
                    seen.add(key)
                    bridges.append(bridge)

    for source in walls:
        source_angle = _angle_deg(source)
        for endpoint in (source.start, source.end):
            best: _VirtualBridge | None = None
            for host in walls:
                if host.wall_id == source.wall_id:
                    continue
                diff = _angle_diff(source_angle, _angle_deg(host))
                if not (70.0 <= diff <= 110.0):
                    continue
                bridge = _junction_bridge(
                    endpoint,
                    host,
                    source_id=source.wall_id,
                    px_per_m=px_per_m,
                )
                if bridge is None:
                    continue
                if best is None or bridge.gap_px < best.gap_px:
                    best = bridge
            if best is not None:
                key = (best.kind, best.wall_ids, round(best.start[0], 1), round(best.start[1], 1))
                if key not in seen:
                    seen.add(key)
                    bridges.append(best)

    return bridges


def _component_membership(walls, bridges: list[_VirtualBridge], *, px_per_m: float) -> tuple[list[list[int]], list[set[int]]]:
    lines = [_line(item) for item in walls]
    adjacency: list[set[int]] = [set() for _ in walls]
    junction_tolerance = 0.18 * px_per_m

    for i in range(len(walls)):
        for j in range(i + 1, len(walls)):
            if lines[i].distance(lines[j]) <= junction_tolerance:
                adjacency[i].add(j)
                adjacency[j].add(i)

    index = {wall.wall_id: idx for idx, wall in enumerate(walls)}
    for bridge in bridges:
        if len(bridge.wall_ids) != 2:
            continue
        a = index.get(bridge.wall_ids[0])
        b = index.get(bridge.wall_ids[1])
        if a is None or b is None:
            continue
        adjacency[a].add(b)
        adjacency[b].add(a)

    remaining = set(range(len(walls)))
    components: list[list[int]] = []
    while remaining:
        seed = next(iter(remaining))
        stack = [seed]
        component: list[int] = []
        while stack:
            current = stack.pop()
            if current not in remaining:
                continue
            remaining.remove(current)
            component.append(current)
            stack.extend(adjacency[current])
        components.append(component)

    components.sort(
        key=lambda group: sum(walls[index].length_px for index in group),
        reverse=True,
    )
    return components, adjacency


def _select_architectural_network(walls, components: list[list[int]], *, px_per_m: float) -> tuple[list, dict[str, int]]:
    selected_indices: set[int] = set()
    component_sizes: dict[str, int] = {}
    for component_index, component in enumerate(components, 1):
        total_length_m = sum(walls[index].length_px for index in component) / px_per_m
        # Una red arquitectónica puede quedar dividida por openings. Conservamos
        # componentes suficientemente extensos, pero eliminamos trazos aislados.
        keep = len(component) >= 3 or total_length_m >= 3.0
        if keep:
            selected_indices.update(component)
        for index in component:
            component_sizes[walls[index].wall_id] = component_index

    selected = [wall for index, wall in enumerate(walls) if index in selected_indices]
    return selected, component_sizes


def _render_wall_mask(walls, *, shape: tuple[int, int], px_per_m: float) -> np.ndarray:
    mask = np.zeros(shape, dtype=np.uint8)
    for wall in walls:
        _draw_segment(
            mask,
            wall.start,
            wall.end,
            255,
            _wall_draw_thickness(wall, px_per_m),
        )
    return mask


def _logical_seal_mask(
    walls,
    bridges: list[_VirtualBridge],
    *,
    shape: tuple[int, int],
    px_per_m: float,
) -> np.ndarray:
    mask = _render_wall_mask(walls, shape=shape, px_per_m=px_per_m)
    thickness_by_id = {wall.wall_id: wall.thickness_px for wall in walls}
    for bridge in bridges:
        widths = [thickness_by_id.get(wall_id) for wall_id in bridge.wall_ids]
        widths = [float(value) for value in widths if value is not None and value > 0]
        thickness = float(np.median(widths)) if widths else 0.12 * px_per_m
        _draw_segment(mask, bridge.start, bridge.end, 255, max(2, int(round(thickness))))

    kernel_size = max(3, int(round(0.08 * px_per_m)))
    if kernel_size % 2 == 0:
        kernel_size += 1
    kernel = np.ones((kernel_size, kernel_size), dtype=np.uint8)
    return cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=1)


def _space_topology(logical_mask: np.ndarray, *, px_per_m: float) -> _SpaceTopology:
    background = (logical_mask == 0).astype(np.uint8)
    count, labels, stats, _ = cv2.connectedComponentsWithStats(background, connectivity=8)
    height, width = logical_mask.shape
    exterior: set[int] = set()
    interior: set[int] = set()
    areas: dict[int, int] = {}
    min_room_area_px2 = 0.40 * px_per_m * px_per_m

    for label in range(1, count):
        x, y, w, h, area = [int(value) for value in stats[label]]
        areas[label] = area
        touches_border = x == 0 or y == 0 or (x + w) >= width or (y + h) >= height
        if touches_border:
            exterior.add(label)
        elif area >= min_room_area_px2:
            interior.add(label)

    return _SpaceTopology(
        labels=labels,
        exterior_labels=frozenset(exterior),
        interior_labels=frozenset(interior),
        areas_px2=areas,
    )


def _sample_label(topology: _SpaceTopology, point: tuple[float, float]) -> int:
    x = int(round(point[0]))
    y = int(round(point[1]))
    if x < 0 or y < 0 or y >= topology.labels.shape[0] or x >= topology.labels.shape[1]:
        return -1
    return int(topology.labels[y, x])


def _classify_wall(wall, topology: _SpaceTopology, *, px_per_m: float) -> _WallRole:
    ux, uy, length = _vector(wall)
    nx, ny = -uy, ux
    sample_offset = max(wall.thickness_px * 0.5 + 0.08 * px_per_m, 3.0)
    sample_ts = (0.15, 0.30, 0.50, 0.70, 0.85) if length >= 12.0 else (0.50,)

    perimeter_votes = 0
    divider_votes = 0
    review_votes = 0
    left_labels: list[int] = []
    right_labels: list[int] = []

    for t in sample_ts:
        cx = wall.start[0] + (wall.end[0] - wall.start[0]) * t
        cy = wall.start[1] + (wall.end[1] - wall.start[1]) * t
        left = _sample_label(topology, (cx + nx * sample_offset, cy + ny * sample_offset))
        right = _sample_label(topology, (cx - nx * sample_offset, cy - ny * sample_offset))
        left_labels.append(left)
        right_labels.append(right)

        left_ext = left in topology.exterior_labels
        right_ext = right in topology.exterior_labels
        left_int = left in topology.interior_labels
        right_int = right in topology.interior_labels

        if (left_ext and right_int) or (right_ext and left_int):
            perimeter_votes += 1
        elif left_int and right_int and left != right:
            divider_votes += 1
        else:
            review_votes += 1

    total = len(sample_ts)
    minimum_votes = max(1, math.ceil(total * 0.60))
    if perimeter_votes >= minimum_votes and perimeter_votes > divider_votes:
        role = "PERIMETER"
        confidence = perimeter_votes / total
    elif divider_votes >= minimum_votes and divider_votes > perimeter_votes:
        role = "DIVIDER"
        confidence = divider_votes / total
    else:
        role = "REVIEW"
        confidence = max(perimeter_votes, divider_votes) / total

    return _WallRole(
        wall_id=wall.wall_id,
        role=role,
        confidence=float(confidence),
        perimeter_votes=perimeter_votes,
        divider_votes=divider_votes,
        review_votes=review_votes,
        left_labels=tuple(left_labels),
        right_labels=tuple(right_labels),
    )


def _wall_junctions(walls, *, px_per_m: float) -> list[tuple[float, float]]:
    tolerance = 0.16 * px_per_m
    points: list[tuple[float, float]] = []
    lines = [_line(wall) for wall in walls]
    for i, first in enumerate(lines):
        for second in lines[i + 1 :]:
            if first.distance(second) > tolerance:
                continue
            intersection = first.intersection(second)
            if intersection.is_empty:
                continue
            if intersection.geom_type == "Point":
                points.append((float(intersection.x), float(intersection.y)))
    deduped: list[tuple[float, float]] = []
    for point in points:
        if not any(math.hypot(point[0] - other[0], point[1] - other[1]) <= 3.0 for other in deduped):
            deduped.append(point)
    return deduped


def _draw_centerlines(image: np.ndarray, walls, *, thickness: int = 2) -> None:
    for wall in walls:
        _draw_segment(image, wall.start, wall.end, (0, 0, 0), thickness)


def _draw_room_contours(image: np.ndarray, topology: _SpaceTopology) -> None:
    for label in sorted(topology.interior_labels):
        component = np.where(topology.labels == label, 255, 0).astype(np.uint8)
        contours, _ = cv2.findContours(component, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(image, contours, -1, (0, 0, 0), 2, cv2.LINE_AA)


def _serialize_bridge(item: _VirtualBridge, *, px_per_m: float) -> dict:
    return {
        "id": item.bridge_id,
        "kind": item.kind,
        "start": list(item.start),
        "end": list(item.end),
        "gap_px": item.gap_px,
        "gap_m": item.gap_px / px_per_m,
        "wall_ids": list(item.wall_ids),
        "physical_wall_present": False,
        "logical_continuity_only": True,
    }


def _serialize_role(item: _WallRole) -> dict:
    return {
        "wall_id": item.wall_id,
        "role": item.role,
        "confidence": item.confidence,
        "perimeter_votes": item.perimeter_votes,
        "divider_votes": item.divider_votes,
        "review_votes": item.review_votes,
        "left_labels": list(item.left_labels),
        "right_labels": list(item.right_labels),
    }


def _run_level(*, loaded, output_dir: Path, case_id: str, scale_profile) -> dict:
    level_result = loaded.level_result
    px_per_m = 1.0 / float(scale_profile.local_m_per_px)

    candidate_tracks = _build_raw_candidates(
        level_result=level_result,
        scale_profile=scale_profile,
    )
    physical = _physical_walls(candidate_tracks)
    assert physical, "No se generaron WallTracks físicos desde DrawingModel/F01.5."

    bridges_all = _virtual_bridges(physical, px_per_m=px_per_m)
    components, adjacency = _component_membership(physical, bridges_all, px_per_m=px_per_m)
    selected, component_membership = _select_architectural_network(
        physical,
        components,
        px_per_m=px_per_m,
    )
    selected_ids = {wall.wall_id for wall in selected}
    bridges = [
        bridge
        for bridge in bridges_all
        if all(wall_id in selected_ids for wall_id in bridge.wall_ids)
    ]
    assert selected, "La selección de red arquitectónica quedó vacía."

    raster = _decode(level_result.level_view.raster_bytes)
    wall_mask = _render_wall_mask(
        selected,
        shape=raster.shape[:2],
        px_per_m=px_per_m,
    )
    logical_mask = _logical_seal_mask(
        selected,
        bridges,
        shape=raster.shape[:2],
        px_per_m=px_per_m,
    )
    topology = _space_topology(logical_mask, px_per_m=px_per_m)
    roles = [_classify_wall(wall, topology, px_per_m=px_per_m) for wall in selected]
    role_by_id = {item.wall_id: item for item in roles}
    junctions = _wall_junctions(selected, px_per_m=px_per_m)

    white = np.full_like(raster, 255)
    wall_centerlines = white.copy()
    wallgraph_clean = white.copy()
    rooms_clean = white.copy()
    topology_audit = cv2.addWeighted(raster, 0.12, np.full_like(raster, 255), 0.88, 0.0)

    _draw_centerlines(wall_centerlines, selected, thickness=2)
    _draw_centerlines(wallgraph_clean, selected, thickness=3)
    _draw_room_contours(rooms_clean, topology)

    # Audit únicamente: bridges y junctions. El plano limpio no los muestra.
    _draw_centerlines(topology_audit, selected, thickness=2)
    for bridge in bridges:
        _draw_segment(topology_audit, bridge.start, bridge.end, (0, 165, 255), 2)
    for x, y in junctions:
        cv2.circle(topology_audit, (int(round(x)), int(round(y))), 4, (255, 0, 255), -1, cv2.LINE_AA)

    safe = _safe(loaded.level_name)
    wall_mask_path = output_dir / f"{case_id}__{safe}__01_wall_mask.png"
    logical_path = output_dir / f"{case_id}__{safe}__02_logical_seal_mask.png"
    centerline_path = output_dir / f"{case_id}__{safe}__03_wall_centerlines.png"
    wallgraph_path = output_dir / f"{case_id}__{safe}__04_wallgraph_clean.png"
    rooms_path = output_dir / f"{case_id}__{safe}__05_rooms_clean.png"
    audit_path = output_dir / f"{case_id}__{safe}__06_topology_audit.png"

    cv2.imwrite(str(wall_mask_path), wall_mask)
    cv2.imwrite(str(logical_path), logical_mask)
    cv2.imwrite(str(centerline_path), wall_centerlines)
    cv2.imwrite(str(wallgraph_path), wallgraph_clean)
    cv2.imwrite(str(rooms_path), rooms_clean)
    cv2.imwrite(str(audit_path), topology_audit)

    component_report = []
    for index, component in enumerate(components, 1):
        total_length_px = sum(physical[item].length_px for item in component)
        component_report.append({
            "component_id": index,
            "wall_count": len(component),
            "total_length_px": total_length_px,
            "total_length_m": total_length_px / px_per_m,
            "selected": any(physical[item].wall_id in selected_ids for item in component),
            "wall_ids": [physical[item].wall_id for item in component],
        })

    role_counts = {
        role: sum(1 for item in roles if item.role == role)
        for role in ("PERIMETER", "DIVIDER", "REVIEW")
    }

    return {
        "level": loaded.level_name,
        "level_view_id": level_result.level_view.id,
        "px_per_m": px_per_m,
        "candidate_track_count": len(candidate_tracks),
        "physical_wall_count": len(physical),
        "selected_network_wall_count": len(selected),
        "network_component_count": len(components),
        "virtual_bridge_count": len(bridges),
        "junction_count": len(junctions),
        "interior_space_count": len(topology.interior_labels),
        "exterior_component_count": len(topology.exterior_labels),
        "role_counts": role_counts,
        "roles": [_serialize_role(item) for item in roles],
        "virtual_bridges": [_serialize_bridge(item, px_per_m=px_per_m) for item in bridges],
        "components": component_report,
        "component_membership": component_membership,
        "wall_mask_visual": str(wall_mask_path),
        "logical_seal_visual": str(logical_path),
        "wall_centerlines_visual": str(centerline_path),
        "wallgraph_clean_visual": str(wallgraph_path),
        "rooms_clean_visual": str(rooms_path),
        "topology_audit_visual": str(audit_path),
    }


def _run_case(case: LoadedCase) -> None:
    output_dir = OUTPUT_ROOT / case.case_id
    if output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    pipeline = ProposalCReconstructionPipeline()
    scale_inputs = []
    for loaded in case.levels:
        perimeter = loaded.level_result.perimeter.editable_perimeter
        assert perimeter is not None
        scale_inputs.append((loaded.level_result.level_view, perimeter))

    project_scale = pipeline.build_project_scale_context(levels=scale_inputs)
    assert project_scale.state == "RESOLVED"

    report = {
        "probe_version": PROBE_VERSION,
        "baseline": BASELINE,
        "case_id": case.case_id,
        "case": case.case_name,
        "gemini_calls_added": 0,
        "engine_files_modified": 0,
        "source_of_wall_truth": "DRAWING_MODEL_F01_5_TO_WALL_MASK",
        "footprint_policy": "NEVER_GENERATES_OR_PROMOTES_WALLS",
        "logical_bridge_policy": "TOPOLOGY_ONLY_NOT_SOLID_WALL",
        "role_policy": {
            "PERIMETER": "EXTERIOR_TO_INTERIOR_ADJACENCY",
            "DIVIDER": "INTERIOR_TO_DIFFERENT_INTERIOR_ADJACENCY",
            "REVIEW": "INSUFFICIENT_TOPOLOGY_DO_NOT_FORCE",
        },
        "visual_contract": {
            "wallgraph_clean": "WHITE_BACKGROUND_BLACK_PHYSICAL_WALL_CENTERLINES",
            "rooms_clean": "WHITE_BACKGROUND_BLACK_ROOM_CONTOURS",
        },
        "project_scale": project_scale.model_dump(mode="json"),
        "levels": [],
        "failures": [],
    }

    for loaded in case.levels:
        profile = project_scale.for_level(loaded.level_result.level_view.id)
        assert profile.local_m_per_px is not None
        px_per_m = 1.0 / profile.local_m_per_px
        relative_error = abs(px_per_m - TARGET_PX_PER_M) / TARGET_PX_PER_M
        if profile.state != "RESOLVED" or relative_error > TARGET_RELATIVE_TOLERANCE:
            report["failures"].append(
                f"{loaded.level_name}:SCALE_GUARD:{profile.state}:{px_per_m:.6f}"
            )
            continue

        level_report = _run_level(
            loaded=loaded,
            output_dir=output_dir,
            case_id=case.case_id,
            scale_profile=profile,
        )
        report["levels"].append(level_report)
        print("\n" + "=" * 100)
        print(f"WALL MASK RECONSTRUCTION V1 — {case.case_name} — {loaded.level_name}")
        print({
            "physical_walls": level_report["physical_wall_count"],
            "selected_network_walls": level_report["selected_network_wall_count"],
            "components": level_report["network_component_count"],
            "virtual_bridges": level_report["virtual_bridge_count"],
            "junctions": level_report["junction_count"],
            "interior_spaces": level_report["interior_space_count"],
            "roles": level_report["role_counts"],
        })

    report["passed"] = not report["failures"]
    json_path = output_dir / f"{case.case_id}__wall_mask_reconstruction_v1.json"
    json_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\nJSON: {json_path}")
    assert not report["failures"], json.dumps(report["failures"], ensure_ascii=False)


@pytest.mark.parametrize("case_id", CASE_IDS)
def test_quantia_spatial_wall_mask_reconstruction_all_3_v1(case_id: str) -> None:
    _run_case(CASE_LOADERS[case_id]())


if __name__ == "__main__":
    for _case_id in CASE_IDS:
        _run_case(CASE_LOADERS[_case_id]())
