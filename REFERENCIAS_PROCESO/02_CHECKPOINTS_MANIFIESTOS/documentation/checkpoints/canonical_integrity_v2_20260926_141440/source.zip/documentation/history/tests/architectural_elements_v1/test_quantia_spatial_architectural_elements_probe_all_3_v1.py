from __future__ import annotations

import json
import shutil
from pathlib import Path

import cv2
import numpy as np
import pytest

from app.quantia_spatialV1.architectural_elements import ArchitecturalElementsMiniEngine
from app.quantia_spatialV1.reconstruction_core import ProposalCReconstructionPipeline
from app.quantia_spatialV1.tests.quantia_case_loader import CASE_LOADERS, LoadedCase


PROBE_VERSION = "ARCHITECTURAL_ELEMENTS_MINI_ENGINE_PROBE_ALL_3_V1"
BASELINE = (
    "ARCHITECTURAL_ELEMENTS_MINI_ENGINE_V1 + "
    "F03_ELEMENT_CONTEXT_ISOLATION_V5 + "
    "F03_SELECTION_CONTRACTS_V1_6 + "
    "CANONICAL_METRIC_RASTER_V2_3_VALIDATED"
)
CASE_IDS = ("casa_viri", "miguel_h", "miguel_v")
TARGET_PX_PER_M = 90.0
TARGET_RELATIVE_TOLERANCE = 0.05

TESTS_DIR = Path(__file__).resolve().parent
OUTPUT_ROOT = TESTS_DIR / "output" / "architectural_elements_mini_engine_v1"

WALL = (0, 0, 0)
DOOR = (255, 0, 255)     # magenta BGR
WINDOW = (255, 255, 0)   # cyan BGR
REVIEW = (0, 165, 255)   # orange BGR


def _safe(value: str) -> str:
    text = "".join(ch.lower() if ch.isalnum() else "_" for ch in value.strip())
    while "__" in text:
        text = text.replace("__", "_")
    return text.strip("_") or "level"


def _decode(data: bytes) -> np.ndarray:
    image = cv2.imdecode(np.frombuffer(data, dtype=np.uint8), cv2.IMREAD_COLOR)
    if image is None:
        raise RuntimeError("No se pudo decodificar LevelView raster.")
    return image


def _wall_segment(wall):
    a = wall.reference_path[0]
    b = wall.reference_path[-1]
    return (float(a.x_px), float(a.y_px)), (float(b.x_px), float(b.y_px))


def _draw_wall(image, wall, thickness=4):
    a, b = _wall_segment(wall)
    cv2.line(
        image,
        (int(round(a[0])), int(round(a[1]))),
        (int(round(b[0])), int(round(b[1]))),
        WALL,
        thickness,
        cv2.LINE_AA,
    )


def _opening_points(wall, opening):
    (ax, ay), (bx, by) = _wall_segment(wall)
    dx, dy = bx - ax, by - ay
    length = max((dx * dx + dy * dy) ** 0.5, 1e-6)
    ux, uy = dx / length, dy / length
    center = min(max(float(opening.offset_px), 0.0), length)
    half = min(float(opening.width_px) * 0.5, length * 0.46)
    p1 = (ax + ux * (center - half), ay + uy * (center - half))
    p2 = (ax + ux * (center + half), ay + uy * (center + half))
    return p1, p2


def _draw_published_openings(image, level):
    walls = {wall.id: wall for wall in level.walls}
    for opening in level.openings:
        wall = walls.get(opening.host_wall_id)
        if wall is None:
            continue
        p1, p2 = _opening_points(wall, opening)
        color = DOOR if opening.opening_type == "DOOR" else WINDOW
        cv2.line(
            image,
            (int(round(p1[0])), int(round(p1[1]))),
            (int(round(p2[0])), int(round(p2[1]))),
            color,
            7,
            cv2.LINE_AA,
        )


def _draw_review_boxes(image, proposals):
    for proposal in proposals:
        if proposal.decision != "REVIEW":
            continue
        bbox = proposal.source_bbox
        cv2.rectangle(
            image,
            (int(round(bbox.x_min)), int(round(bbox.y_min))),
            (int(round(bbox.x_max)), int(round(bbox.y_max))),
            REVIEW,
            2,
            cv2.LINE_AA,
        )


def _run_level(*, pipeline, mini_engine, loaded, output_dir, case_id, scale_profile):
    level_result = loaded.level_result
    perimeter = level_result.perimeter.editable_perimeter
    assert perimeter is not None

    spatial = pipeline.run(
        level_view=level_result.level_view,
        perimeter=perimeter,
        evidence=list(level_result.evidence.evidence),
        scale_profile=scale_profile,
    )
    walls_before = [wall.model_dump(mode="json") for wall in spatial.parametric_model.levels[0].walls]

    elements, merged = mini_engine.run(
        level_view=level_result.level_view,
        drawing=spatial.drawing_model,
        spatial_model=spatial.parametric_model,
        perimeter=perimeter,
        scale_profile=scale_profile,
        publish=True,
    )

    walls_after = [wall.model_dump(mode="json") for wall in merged.levels[0].walls]
    assert walls_after == walls_before, "Architectural Elements Mini-Engine modificó muros Spatial."

    raster = _decode(level_result.level_view.raster_bytes)
    faded = cv2.addWeighted(raster, 0.14, np.full_like(raster, 255), 0.86, 0.0)
    clean = np.full_like(raster, 255)
    level = merged.levels[0]

    for target in (faded, clean):
        for wall in level.walls:
            _draw_wall(target, wall)
        _draw_published_openings(target, level)

    audit = faded.copy()
    _draw_review_boxes(audit, elements.proposals)

    safe = _safe(loaded.level_name)
    clean_path = output_dir / f"{case_id}__{safe}__elements_merged_clean.png"
    overlay_path = output_dir / f"{case_id}__{safe}__elements_merged_overlay.png"
    audit_path = output_dir / f"{case_id}__{safe}__elements_review_audit.png"
    cv2.imwrite(str(clean_path), clean)
    cv2.imwrite(str(overlay_path), faded)
    cv2.imwrite(str(audit_path), audit)

    return {
        "level": loaded.level_name,
        "level_view_id": level_result.level_view.id,
        "scale_profile": scale_profile.model_dump(mode="json"),
        "spatial_wall_count": len(level.walls),
        "opening_region_count": elements.diagnostics.opening_region_count,
        "proposal_count": elements.diagnostics.proposal_count,
        "accepted_count": elements.diagnostics.accepted_count,
        "review_count": elements.diagnostics.review_count,
        "rejected_count": elements.diagnostics.rejected_count,
        "published_opening_count": elements.diagnostics.published_opening_count,
        "door_count": elements.diagnostics.door_count,
        "window_count": elements.diagnostics.window_count,
        "proposals": [item.model_dump(mode="json") for item in elements.proposals],
        "clean_visual": str(clean_path),
        "overlay_visual": str(overlay_path),
        "audit_visual": str(audit_path),
    }


def _run_case(case: LoadedCase) -> None:
    output_dir = OUTPUT_ROOT / case.case_id
    if output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    pipeline = ProposalCReconstructionPipeline()
    mini_engine = ArchitecturalElementsMiniEngine()
    scale_inputs = []
    for loaded in case.levels:
        perimeter = loaded.level_result.perimeter.editable_perimeter
        assert perimeter is not None
        scale_inputs.append((loaded.level_result.level_view, perimeter))

    project_scale = pipeline.build_project_scale_context(levels=scale_inputs)
    assert project_scale.state == "RESOLVED"

    report = {
        "probe_version": PROBE_VERSION,
        "baseline": BASELINE,
        "case_id": case.case_id,
        "case": case.case_name,
        "gemini_calls_added": 0,
        "legend": {
            "wall": "BLACK",
            "accepted_door": "MAGENTA",
            "accepted_window": "CYAN",
            "review_bbox": "ORANGE",
        },
        "project_scale": project_scale.model_dump(mode="json"),
        "levels": [],
        "failures": [],
    }

    for loaded in case.levels:
        profile = project_scale.for_level(loaded.level_result.level_view.id)
        assert profile.local_m_per_px is not None
        px_per_m = 1.0 / profile.local_m_per_px
        relative_error = abs(px_per_m - TARGET_PX_PER_M) / TARGET_PX_PER_M
        if profile.state != "RESOLVED" or relative_error > TARGET_RELATIVE_TOLERANCE:
            report["failures"].append(
                f"{loaded.level_name}:SCALE_GUARD:{profile.state}:{px_per_m:.6f}"
            )
            continue
        level_report = _run_level(
            pipeline=pipeline,
            mini_engine=mini_engine,
            loaded=loaded,
            output_dir=output_dir,
            case_id=case.case_id,
            scale_profile=profile,
        )
        report["levels"].append(level_report)
        print("\n" + "=" * 100)
        print(f"ARCHITECTURAL ELEMENTS MINI-ENGINE V1 — {case.case_name} — {loaded.level_name}")
        print({
            "walls": level_report["spatial_wall_count"],
            "proposals": level_report["proposal_count"],
            "accepted": level_report["accepted_count"],
            "review": level_report["review_count"],
            "rejected": level_report["rejected_count"],
            "doors": level_report["door_count"],
            "windows": level_report["window_count"],
            "published_openings": level_report["published_opening_count"],
        })

    report["passed"] = not report["failures"]
    json_path = output_dir / f"{case.case_id}__architectural_elements_mini_engine_v1.json"
    json_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\nJSON: {json_path}")
    assert not report["failures"], json.dumps(report["failures"], ensure_ascii=False)


@pytest.mark.parametrize("case_id", CASE_IDS)
def test_quantia_spatial_architectural_elements_probe_all_3_v1(case_id: str) -> None:
    _run_case(CASE_LOADERS[case_id]())


if __name__ == "__main__":
    for _case_id in CASE_IDS:
        _run_case(CASE_LOADERS[_case_id]())
