from __future__ import annotations

from io import BytesIO

from PIL import Image

from app.quantia_spatialV1.models.evidence import EvidenceGeometry, RawEvidence
from app.quantia_spatialV1.models.level_view import LevelView, LevelViewEvidence, LevelViewTransform, PixelBBox, PixelPoint
from app.quantia_spatialV1.phase_01_level.level_identification_service import LevelIdentificationService
from app.quantia_spatialV1.reconstruction_core.project_scale_reconciler import ProjectScaleReconciler
from app.quantia_spatialV1.reconstruction_core.raster_density_policy import RasterDensityPolicy
from app.quantia_spatialV1.reconstruction_core.scale_evidence_resolver import (
    LevelScaleEvidenceResult,
    ScaleEvidenceResolver,
)
from app.quantia_spatialV1.transport.gemini_level_localization import GeminiLevelLocalizationResponse


def _png(width: int = 1000, height: int = 500) -> bytes:
    image = Image.new("L", (width, height), 255)
    buffer = BytesIO()
    image.save(buffer, format="PNG")
    return buffer.getvalue()


def _level(*, evidence: list[LevelViewEvidence] | None = None) -> LevelView:
    width, height = 1000, 500
    bbox = PixelBBox(x_min=0, y_min=0, x_max=width, y_max=height)
    return LevelView(
        id="LV_TEST",
        level_name="Planta Test",
        source_document_id="DOC",
        source_page_number=1,
        source_bbox_px=bbox,
        source_page_width_px=width,
        source_page_height_px=height,
        raster_width_px=width,
        raster_height_px=height,
        raster_mime_type="image/png",
        raster_bytes=_png(width, height),
        transform=LevelViewTransform(
            offset_x_px=0,
            offset_y_px=0,
            source_page_width_px=width,
            source_page_height_px=height,
            local_width_px=width,
            local_height_px=height,
        ),
        state="DETECTADO",
        confidence=0.95,
        evidence=list(evidence or []),
    )


def _vector_line(eid: str, x: int, *, render_scale: float = 1.0) -> RawEvidence:
    return RawEvidence(
        id=eid,
        level_view_id="LV_TEST",
        source="PYMUPDF",
        kind="VECTOR_LINE",
        geometry=EvidenceGeometry(
            geometry_type="SEGMENT",
            points=[PixelPoint(x=x, y=0), PixelPoint(x=x, y=500)],
        ),
        confidence=1.0,
        metadata={
            "page_to_raster_scale_x": render_scale,
            "page_to_raster_scale_y": render_scale,
        },
    )


def _dimension(eid: str, start: str, end: str, value_m: float) -> RawEvidence:
    return RawEvidence(
        id=eid,
        level_view_id="LV_TEST",
        source="GEMINI",
        kind="GEMINI_OBSERVATION",
        geometry=EvidenceGeometry(geometry_type="NONE"),
        text=str(value_m),
        confidence=0.95,
        metadata={
            "semantic_category": "DIMENSION",
            "orientation": "HORIZONTAL",
            "span_type": "TRAMO",
            "reference_start": start,
            "reference_end": end,
            "measurements": [{"name": "dimension", "value": value_m, "unit": "M"}],
        },
    )



def _horizontal_line(eid: str, y: int, *, render_scale: float = 1.0) -> RawEvidence:
    return RawEvidence(
        id=eid,
        level_view_id="LV_TEST",
        source="PYMUPDF",
        kind="VECTOR_LINE",
        geometry=EvidenceGeometry(
            geometry_type="SEGMENT",
            points=[PixelPoint(x=0, y=y), PixelPoint(x=1000, y=y)],
        ),
        confidence=1.0,
        metadata={
            "page_to_raster_scale_x": render_scale,
            "page_to_raster_scale_y": render_scale,
        },
    )


def _axis_label(eid: str, text: str, x: int, y: int) -> RawEvidence:
    return RawEvidence(
        id=eid,
        level_view_id="LV_TEST",
        source="PYMUPDF",
        kind="VECTOR_TEXT",
        geometry=EvidenceGeometry(
            geometry_type="BBOX",
            bbox_px=PixelBBox(x_min=x - 3, y_min=y - 3, x_max=x + 3, y_max=y + 3),
        ),
        text=text,
        confidence=1.0,
        metadata={
            "page_to_raster_scale_x": 1.0,
            "page_to_raster_scale_y": 1.0,
        },
    )


def _general_dimension(eid: str, start: str, end: str, value_m: float, *, orientation: str) -> RawEvidence:
    return RawEvidence(
        id=eid,
        level_view_id="LV_TEST",
        source="GEMINI",
        kind="GEMINI_OBSERVATION",
        geometry=EvidenceGeometry(geometry_type="NONE"),
        text=str(value_m),
        confidence=0.98,
        metadata={
            "semantic_category": "DIMENSION",
            "orientation": orientation,
            "span_type": "GENERAL",
            "reference_start": start,
            "reference_end": end,
            "measurements": [{"name": "dimension", "value": value_m, "unit": "M"}],
        },
    )

def test_raster_policy_matches_reference_factors() -> None:
    policy = RasterDensityPolicy(target_geometry_px_per_m=90.0)
    assert abs(policy.recommend_from_declared_scale(denominator=25).recommended_render_scale - 0.79375) < 1e-8
    assert abs(policy.recommend_from_declared_scale(denominator=30).recommended_render_scale - 0.9525) < 1e-8
    assert abs(policy.recommend_from_declared_scale(denominator=50).recommended_render_scale - 1.5875) < 1e-8


def test_declared_scale_pdf_becomes_metric_candidate() -> None:
    level = _level()
    text = RawEvidence(
        id="SCALE_TEXT",
        level_view_id=level.id,
        source="PYMUPDF",
        kind="VECTOR_TEXT",
        geometry=EvidenceGeometry(geometry_type="NONE"),
        text="ESCALA 1:50",
        confidence=1.0,
        metadata={"page_to_raster_scale_x": 1.5875, "page_to_raster_scale_y": 1.5875},
    )
    result = ScaleEvidenceResolver().resolve(level_view=level, evidence=[text])
    assert result.state == "RESOLVED"
    assert result.selected_m_per_px is not None
    assert abs(result.selected_m_per_px - (1.0 / 90.0)) < 1e-8
    assert result.declared_scale_denominators == [50.0]


def test_f01_gemini_scale_hint_is_preserved_in_level_view_evidence() -> None:
    payload = {
        "pagina": 1,
        "niveles": [
            {
                "nombre": "Planta Test",
                "localizado": True,
                "bbox_normalizado": {"x_min": 0.0, "y_min": 0.0, "x_max": 1.0, "y_max": 1.0},
                "confianza": 0.95,
                "escala_declarada": "1:30",
                "confianza_escala": 0.93,
            }
        ],
    }
    validated = GeminiLevelLocalizationResponse.model_validate(payload)
    result = LevelIdentificationService().identify_page(
        source_raster_bytes=_png(),
        source_page_number=1,
        source_document_id="DOC",
        known_level_names=["Planta Test"],
        gemini_payload=validated.to_detector_payload(),
        single_level_isolated=False,
    )
    assert len(result.level_views) == 1
    hints = [item for item in result.level_views[0].evidence if item.reference == "declared_scale_hint"]
    assert len(hints) == 1
    assert hints[0].text == "1:30"
    assert hints[0].confidence == 0.93


def test_old_localization_payload_without_scale_remains_compatible() -> None:
    payload = {
        "pagina": 1,
        "niveles": [
            {
                "nombre": "Planta Test",
                "localizado": True,
                "bbox_normalizado": {"x_min": 0.0, "y_min": 0.0, "x_max": 1.0, "y_max": 1.0},
                "confianza": 0.95,
            }
        ],
    }
    response = GeminiLevelLocalizationResponse.model_validate(payload)
    assert response.niveles[0].escala_declarada is None
    assert response.niveles[0].confianza_escala is None


def test_axis_dimension_fit_can_resolve_scale_without_printed_scale() -> None:
    level = _level()
    evidence = [
        _vector_line("L1", 100),
        _vector_line("L2", 300),
        _vector_line("L3", 500),
        _dimension("D1", "1", "2", 2.0),
        _dimension("D2", "2", "3", 2.0),
    ]
    result = ScaleEvidenceResolver().resolve(level_view=level, evidence=evidence)
    axis_candidates = [item for item in result.candidates if item.method == "DIMENSION_AXIS_FIT"]
    assert axis_candidates
    assert result.selected_m_per_px is not None
    assert abs(result.selected_m_per_px - 0.01) < 0.001


def test_conflicting_strong_scale_sources_are_not_silently_merged() -> None:
    level = _level()
    evidence = [
        RawEvidence(
            id="SCALE50",
            level_view_id=level.id,
            source="PYMUPDF",
            kind="VECTOR_TEXT",
            geometry=EvidenceGeometry(geometry_type="NONE"),
            text="Escala 1:50",
            confidence=1.0,
            metadata={"page_to_raster_scale_x": 1.0, "page_to_raster_scale_y": 1.0},
        ),
        _vector_line("L1", 100),
        _vector_line("L2", 300),
        _vector_line("L3", 500),
        _dimension("D1", "1", "2", 2.0),
        _dimension("D2", "2", "3", 2.0),
    ]
    result = ScaleEvidenceResolver().resolve(level_view=level, evidence=evidence)
    assert result.state == "CONFLICT"
    assert result.warnings


def test_project_reconciler_normalizes_different_local_scales() -> None:
    a = LevelScaleEvidenceResult(
        level_view_id="A",
        state="RESOLVED",
        selected_m_per_px=1.0 / 90.0,
        selected_confidence=0.95,
        selected_method="DIMENSION_AXIS_FIT",
        current_render_scale=0.79375,
    )
    b = LevelScaleEvidenceResult(
        level_view_id="B",
        state="RESOLVED",
        selected_m_per_px=1.0 / 60.0,
        selected_confidence=0.90,
        selected_method="DECLARED_SCALE_PDF",
        current_render_scale=1.0,
    )
    project = ProjectScaleReconciler().reconcile(levels=[a, b], target_px_per_m=90.0)
    assert project.state == "RESOLVED"
    assert abs(project.for_level("A").scale_factor_to_canonical - 1.0) < 1e-9
    assert abs(project.for_level("B").scale_factor_to_canonical - 1.5) < 1e-9
    assert len(project.relations) == 1


def test_project_reconciler_does_not_invent_missing_scale() -> None:
    unresolved = LevelScaleEvidenceResult(level_view_id="A", state="UNRESOLVED")
    project = ProjectScaleReconciler().reconcile(levels=[unresolved])
    assert project.state == "UNRESOLVED"
    assert project.for_level("A").local_m_per_px is None
    assert project.for_level("A").scale_factor_to_canonical == 1.0


def test_grounded_policy_preserves_target_density() -> None:
    policy = RasterDensityPolicy(target_geometry_px_per_m=90.0)
    result = policy.recommend_from_grounded_scale(current_render_scale=0.7935, current_m_per_px=1.0 / 45.0)
    assert abs(result.expected_px_per_m - 90.0) < 1e-9
    assert result.recommended_render_scale > 0.7935


def test_resolved_axis_span_fallback_resolves_without_declared_scale_or_affine_chain() -> None:
    level = _level()
    evidence = [
        _vector_line("VX1", 100),
        _vector_line("VX3", 500),
        _horizontal_line("HYA", 100),
        _horizontal_line("HYC", 300),
        _axis_label("TXT1", "1", 100, 12),
        _axis_label("TXT3", "3", 500, 12),
        _axis_label("TXTA", "A", 12, 100),
        _axis_label("TXTC", "C", 12, 300),
        _general_dimension("DG_H", "1", "3", 4.0, orientation="HORIZONTAL"),
        _general_dimension("DG_V", "A", "C", 2.0, orientation="VERTICAL"),
    ]

    result = ScaleEvidenceResolver().resolve(level_view=level, evidence=evidence)

    assert result.declared_scale_denominators == []
    assert not any(item.method == "DIMENSION_AXIS_FIT" for item in result.candidates)
    fallback = [
        item for item in result.candidates
        if item.method == "DIMENSION_RESOLVED_AXIS_SPAN"
    ]
    assert len(fallback) == 2
    assert result.state == "RESOLVED"
    assert result.selected_method == "DIMENSION_RESOLVED_AXIS_SPAN"
    assert result.selected_m_per_px is not None
    assert abs(result.selected_m_per_px - 0.01) < 1e-6


def test_single_tramo_axis_span_does_not_resolve_global_scale_alone() -> None:
    level = _level()
    evidence = [
        _vector_line("VX1", 100),
        _vector_line("VX2", 300),
        _axis_label("TXT1", "1", 100, 12),
        _axis_label("TXT2", "2", 300, 12),
        _dimension("D1", "1", "2", 2.0),
    ]

    result = ScaleEvidenceResolver().resolve(level_view=level, evidence=evidence)
    fallback = [
        item for item in result.candidates
        if item.method == "DIMENSION_RESOLVED_AXIS_SPAN"
    ]
    # La cadena puede resolverse por el método afín original. Si no lo hace,
    # el fallback aislado nunca debe tener confianza suficiente para cerrar
    # por sí solo la escala global.
    if fallback and not any(item.method == "DIMENSION_AXIS_FIT" for item in result.candidates):
        assert max(item.confidence for item in fallback) <= 0.72
        assert result.state != "RESOLVED"
