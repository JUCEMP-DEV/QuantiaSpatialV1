from __future__ import annotations

from types import SimpleNamespace

from app.quantia_spatialV1.phase_02_boundaries.perimeter_models import (
    PerimeterCandidate,
    PerimeterCandidateEvidenceReconciliation,
    PerimeterEvidenceReconciliationResult,
    PerimeterMotorSegmentSupport,
    PerimeterPointPx,
    PerimeterPolygonPx,
)
from app.quantia_spatialV1.phase_02_boundaries.perimeter_wall_graph import (
    PerimeterGraphEdge,
    PerimeterWallGraphResult,
)
from app.quantia_spatialV1.phase_02_boundaries_experimental.candidate_pool import (
    PerimeterCandidatePoolBuilder,
)
from app.quantia_spatialV1.phase_02_boundaries_experimental.context_analyzer import (
    CandidateContextMeasure,
)
from app.quantia_spatialV1.phase_02_boundaries_experimental.global_resolver import (
    GlobalPerimeterHypothesisResolver,
)


def _candidate(ident: str, x0: float, y0: float, x1: float, y1: float) -> PerimeterCandidate:
    return PerimeterCandidate(
        id=ident,
        level_view_id="LV",
        geometry=PerimeterPolygonPx(points=[
            PerimeterPointPx(x=x0, y=y0),
            PerimeterPointPx(x=x1, y=y0),
            PerimeterPointPx(x=x1, y=y1),
            PerimeterPointPx(x=x0, y=y1),
        ]),
        geometry_source="RASTER",
        evidence=[],
        confirmed=False,
    )


class _GraphStub:
    def __init__(self, candidate):
        self.candidate = candidate

    def build(self, **kwargs):
        return PerimeterWallGraphResult(
            level_view_id="LV",
            state="RESOLVED",
            candidate=self.candidate,
            edges=[],
        )


class _DetectorStub:
    def __init__(self, candidates):
        self.candidates = candidates
        self.called = False

    def detect(self, **kwargs):
        self.called = True
        return list(self.candidates)


def test_candidate_pool_does_not_short_circuit_when_graph_is_resolved() -> None:
    graph_candidate = _candidate("GRAPH", 0, 0, 100, 100)
    geometry_candidate = _candidate("GEOM", 10, 10, 90, 90)
    detector = _DetectorStub([geometry_candidate])
    pool = PerimeterCandidatePoolBuilder(
        geometry_detector=detector,
        wall_graph_builder=_GraphStub(graph_candidate),
    )

    candidates, wall_graph, geometry_count = pool.build(
        level_view=SimpleNamespace(id="LV"),
        evidence=[],
    )

    assert detector.called is True
    assert wall_graph.state == "RESOLVED"
    assert geometry_count == 1
    assert {item.id for item in candidates} == {"GRAPH", "GEOM"}


def _reconciliation(candidate_id: str, state: str, sources: list[str], supported: bool):
    evidence_ids = ["E1"] if supported else []
    segments = [
        PerimeterMotorSegmentSupport(
            sequence_index=index,
            start_px=PerimeterPointPx(x=a[0], y=a[1]),
            end_px=PerimeterPointPx(x=b[0], y=b[1]),
            orientation=orientation,
            length_px=100.0,
            evidence_ids=evidence_ids,
            sources=sources if supported else [],
        )
        for index, (a, b, orientation) in enumerate([
            ((0.0, 0.0), (100.0, 0.0), "HORIZONTAL"),
            ((100.0, 0.0), (100.0, 100.0), "VERTICAL"),
            ((100.0, 100.0), (0.0, 100.0), "HORIZONTAL"),
            ((0.0, 100.0), (0.0, 0.0), "VERTICAL"),
        ])
    ]
    return PerimeterCandidateEvidenceReconciliation(
        candidate_id=candidate_id,
        state=state,
        independent_geometry_sources=sources,
        segment_support=segments,
    )


def test_global_resolver_prefers_supported_clean_multisource_candidate() -> None:
    good = _candidate("GOOD", 0, 0, 100, 100)
    noisy = _candidate("NOISY", 5, 5, 95, 95)

    reconciliation = PerimeterEvidenceReconciliationResult(
        level_view_id="LV",
        non_gemini_evidence_count=2,
        gemini_evidence_count=0,
        candidates=[
            _reconciliation("GOOD", "SUPPORTED", ["PYMUPDF", "OPENCV"], True),
            _reconciliation("NOISY", "PARTIAL", ["OPENCV"], False),
        ],
    )
    wall_graph = PerimeterWallGraphResult(
        level_view_id="LV",
        state="RESOLVED",
        candidate=good,
        edges=[
            PerimeterGraphEdge(
                id="EDGE",
                start_node_id="A",
                end_node_id="B",
                orientation="HORIZONTAL",
                length_px=100.0,
                evidence_ids=["E1"],
                sources=["OPENCV"],
            )
        ],
    )

    ranked, scores = GlobalPerimeterHypothesisResolver().rank(
        level_view=SimpleNamespace(id="LV"),
        candidates=[noisy, good],
        reconciliation=reconciliation,
        wall_graph=wall_graph,
        context_by_candidate={
            "GOOD": CandidateContextMeasure(0.0, 0.0),
            "NOISY": CandidateContextMeasure(0.60, 0.0),
        },
    )

    assert ranked[0].id == "GOOD"
    by_id = {item.candidate_id: item for item in scores}
    assert by_id["GOOD"].total_score > by_id["NOISY"].total_score
    assert by_id["GOOD"].context_cleanliness_score == 1.0
    assert by_id["NOISY"].context_cleanliness_score == 0.4
