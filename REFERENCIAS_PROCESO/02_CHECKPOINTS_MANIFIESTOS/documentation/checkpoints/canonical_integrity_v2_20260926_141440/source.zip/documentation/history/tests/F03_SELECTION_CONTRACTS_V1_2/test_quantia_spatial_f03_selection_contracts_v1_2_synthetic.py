from __future__ import annotations

from app.quantia_spatialV1.reconstruction_core.candidate_context_gate import CandidateContextGate
from app.quantia_spatialV1.reconstruction_core.candidate_graph import WallCandidateGraphBuilder
from app.quantia_spatialV1.reconstruction_core.candidate_models import WallCandidate, WallEvidenceVector
from app.quantia_spatialV1.reconstruction_core.context_models import ContextRegion
from app.quantia_spatialV1.reconstruction_core.drawing_model import DrawingBBox, DrawingPoint
from app.quantia_spatialV1.reconstruction_core.global_topology_solver import GlobalTopologySolver
from app.quantia_spatialV1.reconstruction_core.level_scale_normalizer import LevelScaleProfile
from app.quantia_spatialV1.reconstruction_core.reconstruction_pipeline import QuantiaReconstructionPipeline


def _candidate(
    candidate_id: str,
    *,
    x1: float,
    y1: float,
    x2: float,
    y2: float,
    thickness: float,
    metadata: dict | None = None,
) -> WallCandidate:
    dx = x2 - x1
    dy = y2 - y1
    angle = 0.0 if abs(dy) < 1e-9 else 90.0 if abs(dx) < 1e-9 else 45.0
    return WallCandidate(
        id=candidate_id,
        generator="DOUBLE_FACE",
        start=DrawingPoint(x=x1, y=y1),
        end=DrawingPoint(x=x2, y=y2),
        angle_deg=angle,
        length_px=(dx * dx + dy * dy) ** 0.5,
        thickness_px=thickness,
        face_ids=[f"{candidate_id}_A", f"{candidate_id}_B"],
        evidence_ids=[],
        source_names=["LSD_LOCAL", "OPENCV"],
        evidence=WallEvidenceVector(
            pair_overlap=0.96,
            thickness_support=0.88,
            vector_support=0.0,
            raster_line_support=1.0,
            region_support=0.94,
            source_consensus=0.50,
            perimeter_containment=1.0,
            semantic_support=0.0,
            axis_support=0.25,
            dashed_penalty=0.0,
        ),
        prior_score=0.78,
        metadata=metadata or {},
    )


def _scale() -> LevelScaleProfile:
    return LevelScaleProfile(
        level_view_id="LV",
        state="RESOLVED",
        local_m_per_px=1.0 / 90.0,
        canonical_m_per_px=1.0 / 90.0,
        scale_factor_to_canonical=1.0,
        local_min_dim_px=1000.0,
        normalized_min_dim_px=1000.0,
        project_reference_min_dim_normalized_px=1000.0,
        project_reference_area_normalized_px2=1_000_000.0,
        source="CANONICAL_METRIC_RASTER_V2",
        confidence=1.0,
    )


def test_metric_parameter_model_separates_wall_band_from_cell_spacing() -> None:
    plausible = _candidate("WALL", x1=0, y1=0, x2=300, y2=0, thickness=13.5)
    tile_pair = _candidate("TILE_PAIR", x1=0, y1=0, x2=72, y2=0, thickness=27.0)
    thin_reference = _candidate("THIN", x1=0, y1=0, x2=600, y2=0, thickness=3.0)
    annotated = QuantiaReconstructionPipeline._annotate_metric_thickness(
        candidates=[plausible, tile_pair, thin_reference],
        scale_profile=_scale(),
    )
    by_id = {item.id: item for item in annotated}
    assert by_id["WALL"].metadata["metric_thickness_support"] == 1.0
    assert by_id["WALL"].metadata["metric_wall_band_support"] > 0.95
    assert by_id["TILE_PAIR"].metadata["metric_wall_band_support"] < 0.60
    assert by_id["THIN"].metadata["metric_thickness_support"] < 0.25


def test_floor_pattern_pair_is_quarantined_even_with_clean_double_face() -> None:
    candidate = _candidate(
        "GRID_PAIR",
        x1=60,
        y1=100,
        x2=240,
        y2=100,
        thickness=20.0,
        metadata={
            "metric_thickness_support": 1.0,
            "metric_slenderness_support": 1.0,
            "metric_wall_band_support": 1.0,
        },
    )
    region = ContextRegion(
        id="FLOOR",
        region_type="FLOOR_FINISH_GRID_REGION",
        bbox=DrawingBBox(x_min=40, y_min=80, x_max=260, y_max=120),
        confidence=0.96,
        quarantine_enabled=True,
        profiles=[],
        member_line_ids=[],
        metadata={
            "pattern_segments": [
                [50.0, 90.0, 250.0, 90.0],
                [50.0, 110.0, 250.0, 110.0],
            ]
        },
    )
    decision = CandidateContextGate().apply(candidates=[candidate], regions=[region]).decisions[0]
    assert decision.metadata["pattern_pair_support"] >= 0.90
    assert decision.state == "QUARANTINE"


def test_one_sided_floor_pattern_boundary_remains_review_not_active() -> None:
    candidate = _candidate(
        "BOUNDARY",
        x1=50,
        y1=50,
        x2=250,
        y2=50,
        thickness=12.0,
        metadata={
            "metric_thickness_support": 1.0,
            "metric_slenderness_support": 1.0,
            "metric_wall_band_support": 1.0,
        },
    )
    region = ContextRegion(
        id="FLOOR_EDGE",
        region_type="FLOOR_FINISH_GRID_REGION",
        bbox=DrawingBBox(x_min=45, y_min=45, x_max=255, y_max=130),
        confidence=0.96,
        quarantine_enabled=True,
        profiles=[],
        member_line_ids=[],
        metadata={
            "pattern_segments": [
                [50.0, 62.0, 250.0, 62.0],
                [50.0, 74.0, 250.0, 74.0],
                [50.0, 86.0, 250.0, 86.0],
            ]
        },
    )
    decision = CandidateContextGate().apply(candidates=[candidate], regions=[region]).decisions[0]
    assert decision.metadata["pattern_pair_support"] < 0.45
    assert decision.metadata["region_boundary_support"] >= 0.58
    assert decision.state == "REVIEW"


def test_metric_penalty_uses_thickness_and_slenderness_separately() -> None:
    solver = GlobalTopologySolver()
    wall = _candidate(
        "W",
        x1=0,
        y1=0,
        x2=300,
        y2=0,
        thickness=13.5,
        metadata={"metric_thickness_support": 1.0, "metric_slenderness_support": 1.0},
    )
    short_cell_pair = wall.model_copy(update={
        "id": "CELL",
        "metadata": {"metric_thickness_support": 0.72, "metric_slenderness_support": 0.10},
    })
    thin_long = wall.model_copy(update={
        "id": "THIN",
        "metadata": {"metric_thickness_support": 0.20, "metric_slenderness_support": 1.0},
    })
    assert solver._metric_thickness_penalty(wall) == 0.0
    assert solver._metric_thickness_penalty(short_cell_pair) > 0.60
    assert solver._metric_thickness_penalty(thin_long) > 1.00


def test_continuation_requires_compatible_band_thickness() -> None:
    first = _candidate("A", x1=0, y1=100, x2=100, y2=100, thickness=10.0)
    second = _candidate("B", x1=104, y1=100, x2=204, y2=100, thickness=30.0)
    graph = WallCandidateGraphBuilder().build(level_view_id="LV", candidates=[first, second])
    assert all(relation.relation_type != "CONTINUATION" for relation in graph.relations)
