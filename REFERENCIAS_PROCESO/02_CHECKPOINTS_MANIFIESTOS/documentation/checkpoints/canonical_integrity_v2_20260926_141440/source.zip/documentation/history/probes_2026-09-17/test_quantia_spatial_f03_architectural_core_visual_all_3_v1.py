from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import pytest

from app.quantia_spatialV1.reconstruction_core import ProposalCReconstructionPipeline
from app.quantia_spatialV1.tests.quantia_case_loader import CASE_LOADERS, LoadedCase


PROBE_VERSION = "F03_ARCHITECTURAL_CORE_VISUAL_ALL_3_V1"
BASELINE = (
    "F03_ELEMENT_CONTEXT_ISOLATION_V5 + "
    "F03_SELECTION_CONTRACTS_V1_6 + "
    "CANONICAL_METRIC_RASTER_V2_3_VALIDATED"
)
CASE_IDS = ("casa_viri", "miguel_h", "miguel_v")
TARGET_PX_PER_M = 90.0
TARGET_RELATIVE_TOLERANCE = 0.05

TESTS_DIR = Path(__file__).resolve().parent
OUTPUT_ROOT = TESTS_DIR / "output" / "f03_architectural_core_visual_v1"

# OpenCV usa BGR.
WALL_COLOR = (0, 0, 0)
DOOR_COLOR = (255, 0, 255)   # magenta
WINDOW_COLOR = (255, 255, 0) # cian


def _safe_name(value: str) -> str:
    cleaned = "".join(ch.lower() if ch.isalnum() else "_" for ch in value.strip())
    while "__" in cleaned:
        cleaned = cleaned.replace("__", "_")
    return cleaned.strip("_") or "level"


def _decode(data: bytes) -> np.ndarray:
    image = cv2.imdecode(np.frombuffer(data, dtype=np.uint8), cv2.IMREAD_COLOR)
    if image is None:
        raise RuntimeError("No se pudo decodificar raster LevelView.")
    return image


def _save(path: Path, image: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not cv2.imwrite(str(path), image):
        raise RuntimeError(f"No se pudo guardar {path}")


def _faded_base(raster: np.ndarray) -> np.ndarray:
    white = np.full_like(raster, 255)
    return cv2.addWeighted(raster, 0.14, white, 0.86, 0.0)


def _white_base(raster: np.ndarray) -> np.ndarray:
    return np.full_like(raster, 255)


def _draw_f02_perimeter(image: np.ndarray, perimeter) -> None:
    vertices = {vertex.id: vertex.point_px for vertex in perimeter.vertices}
    for wall in perimeter.walls:
        a = vertices[wall.start_vertex_id]
        b = vertices[wall.end_vertex_id]
        cv2.line(
            image,
            (int(round(a.x)), int(round(a.y))),
            (int(round(b.x)), int(round(b.y))),
            WALL_COLOR,
            4,
            cv2.LINE_AA,
        )


def _draw_selected_walls(image: np.ndarray, selected_candidates) -> None:
    for candidate in selected_candidates:
        cv2.line(
            image,
            (int(round(candidate.start.x)), int(round(candidate.start.y))),
            (int(round(candidate.end.x)), int(round(candidate.end.y))),
            WALL_COLOR,
            4,
            cv2.LINE_AA,
        )


def _line_lineage_ids(line) -> set[str]:
    ids = {str(line.id)}
    ids.update(str(item) for item in getattr(line, "evidence_ids", ()) if item)
    metadata = getattr(line, "metadata", {}) or {}
    for key in (
        "merged_line_ids",
        "physical_stroke_member_line_ids",
        "context_equivalent_line_ids",
    ):
        raw = metadata.get(key)
        if isinstance(raw, (list, tuple, set)):
            ids.update(str(item) for item in raw if item)
    return ids


def _resolved_member_lines(*, drawing, region) -> list[Any]:
    member_ids = {str(item) for item in region.member_line_ids}
    if not member_ids:
        return []
    resolved = []
    seen = set()
    for line in drawing.lines:
        if not (member_ids & _line_lineage_ids(line)):
            continue
        if line.id in seen:
            continue
        seen.add(line.id)
        resolved.append(line)
    return resolved


def _bezier_point(points, t: float) -> tuple[int, int]:
    p0, p1, p2, p3 = points
    u = 1.0 - t
    x = (
        u * u * u * p0.x
        + 3.0 * u * u * t * p1.x
        + 3.0 * u * t * t * p2.x
        + t * t * t * p3.x
    )
    y = (
        u * u * u * p0.y
        + 3.0 * u * u * t * p1.y
        + 3.0 * u * t * t * p2.y
        + t * t * t * p3.y
    )
    return int(round(x)), int(round(y))


def _draw_line(image: np.ndarray, line, color, thickness: int = 4) -> None:
    cv2.line(
        image,
        (int(round(line.start.x)), int(round(line.start.y))),
        (int(round(line.end.x)), int(round(line.end.y))),
        color,
        thickness,
        cv2.LINE_AA,
    )


def _draw_doors(image: np.ndarray, *, drawing, regions) -> dict[str, int]:
    curve_count = 0
    member_line_count = 0
    curve_by_id = {curve.id: curve for curve in drawing.curves}

    for region in regions:
        for line in _resolved_member_lines(drawing=drawing, region=region):
            _draw_line(image, line, DOOR_COLOR, 4)
            member_line_count += 1

        curve_id = str(region.metadata.get("curve_id") or "")
        curve = curve_by_id.get(curve_id)
        if curve is not None:
            pts = [_bezier_point(curve.control_points, i / 32.0) for i in range(33)]
            cv2.polylines(
                image,
                [np.asarray(pts, dtype=np.int32)],
                False,
                DOOR_COLOR,
                4,
                cv2.LINE_AA,
            )
            curve_count += 1

    return {
        "region_count": len(regions),
        "curve_count": curve_count,
        "member_line_count": member_line_count,
    }


def _draw_windows(image: np.ndarray, *, drawing, regions) -> dict[str, int]:
    member_line_count = 0
    drawn_ids = set()
    for region in regions:
        for line in _resolved_member_lines(drawing=drawing, region=region):
            if line.id in drawn_ids:
                continue
            drawn_ids.add(line.id)
            _draw_line(image, line, WINDOW_COLOR, 4)
            member_line_count += 1

    return {
        "region_count": len(regions),
        "member_line_count": member_line_count,
    }


def _run_level(*, pipeline, loaded, output_dir: Path, case_id: str, scale_profile) -> dict[str, Any]:
    level_result = loaded.level_result
    perimeter = level_result.perimeter.editable_perimeter
    assert perimeter is not None

    full = pipeline.run(
        level_view=level_result.level_view,
        perimeter=perimeter,
        evidence=list(level_result.evidence.evidence),
        scale_profile=scale_profile,
    )
    assert full.diagnostics.graph_candidate_limit_drop_count == 0

    graph_by_id = {candidate.id: candidate for candidate in full.candidate_graph.candidates}
    selected_candidates = [
        graph_by_id[candidate_id]
        for candidate_id in full.solution.selected_candidate_ids
        if candidate_id in graph_by_id
    ]

    door_regions = [
        region for region in full.context_gate.regions
        if region.region_type == "DOOR_REGION"
    ]
    window_regions = [
        region for region in full.context_gate.regions
        if region.region_type == "WINDOW_REGION"
    ]

    raster = _decode(level_result.level_view.raster_bytes)
    safe = _safe_name(loaded.level_name)

    # Dos salidas del mismo resultado:
    # 1) overlay: raster muy tenue para comprobar ubicación.
    # 2) clean: únicamente muro/puerta/ventana sobre blanco.
    overlay = _faded_base(raster)
    clean = _white_base(raster)

    for image in (overlay, clean):
        _draw_f02_perimeter(image, perimeter)
        _draw_selected_walls(image, selected_candidates)

    door_stats_overlay = _draw_doors(overlay, drawing=full.drawing_model, regions=door_regions)
    _draw_doors(clean, drawing=full.drawing_model, regions=door_regions)

    window_stats_overlay = _draw_windows(overlay, drawing=full.drawing_model, regions=window_regions)
    _draw_windows(clean, drawing=full.drawing_model, regions=window_regions)

    overlay_path = output_dir / f"{case_id}__{safe}__architectural_core_overlay.png"
    clean_path = output_dir / f"{case_id}__{safe}__architectural_core_clean.png"
    _save(overlay_path, overlay)
    _save(clean_path, clean)

    return {
        "level": loaded.level_name,
        "level_view_id": level_result.level_view.id,
        "scale_profile": scale_profile.model_dump(mode="json"),
        "selected_wall_count": len(selected_candidates),
        "door": door_stats_overlay,
        "window": window_stats_overlay,
        "overlay_visual": str(overlay_path),
        "clean_visual": str(clean_path),
    }


def _run_case(case: LoadedCase) -> None:
    output_dir = OUTPUT_ROOT / case.case_id
    if output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    pipeline = ProposalCReconstructionPipeline()
    scale_inputs = []
    for loaded in case.levels:
        perimeter = loaded.level_result.perimeter.editable_perimeter
        assert perimeter is not None
        scale_inputs.append((loaded.level_result.level_view, perimeter))

    project_scale = pipeline.build_project_scale_context(levels=scale_inputs)
    assert project_scale.state == "RESOLVED"

    report = {
        "probe_version": PROBE_VERSION,
        "baseline": BASELINE,
        "case_id": case.case_id,
        "case": case.case_name,
        "gemini_calls_added": 0,
        "legend": {
            "wall": "BLACK",
            "door": "MAGENTA",
            "window": "CYAN",
        },
        "project_scale": project_scale.model_dump(mode="json"),
        "levels": [],
        "failures": [],
    }

    for loaded in case.levels:
        profile = project_scale.for_level(loaded.level_result.level_view.id)
        assert profile.local_m_per_px is not None
        px_per_m = 1.0 / profile.local_m_per_px
        relative_error = abs(px_per_m - TARGET_PX_PER_M) / TARGET_PX_PER_M
        if profile.state != "RESOLVED" or relative_error > TARGET_RELATIVE_TOLERANCE:
            report["failures"].append(
                f"{loaded.level_name}:SCALE_GUARD:{profile.state}:{px_per_m:.6f}"
            )
            continue

        level_report = _run_level(
            pipeline=pipeline,
            loaded=loaded,
            output_dir=output_dir,
            case_id=case.case_id,
            scale_profile=profile,
        )
        report["levels"].append(level_report)

        print("\n" + "=" * 104)
        print(f"F03 ARCHITECTURAL CORE VISUAL V1 — {case.case_name} — {loaded.level_name}")
        print({
            "px_m": round(px_per_m, 3),
            "walls": level_report["selected_wall_count"],
            "doors": level_report["door"]["region_count"],
            "door_curves": level_report["door"]["curve_count"],
            "windows": level_report["window"]["region_count"],
            "clean": level_report["clean_visual"],
            "overlay": level_report["overlay_visual"],
        })

    report["passed"] = not report["failures"]
    json_path = output_dir / f"{case.case_id}__f03_architectural_core_visual_v1.json"
    json_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\nJSON: {json_path}")

    assert not report["failures"], json.dumps(report["failures"], ensure_ascii=False)


@pytest.mark.parametrize("case_id", CASE_IDS)
def test_f03_architectural_core_visual_all_3_v1(case_id: str) -> None:
    _run_case(CASE_LOADERS[case_id]())


if __name__ == "__main__":
    for _case_id in CASE_IDS:
        _run_case(CASE_LOADERS[_case_id]())
