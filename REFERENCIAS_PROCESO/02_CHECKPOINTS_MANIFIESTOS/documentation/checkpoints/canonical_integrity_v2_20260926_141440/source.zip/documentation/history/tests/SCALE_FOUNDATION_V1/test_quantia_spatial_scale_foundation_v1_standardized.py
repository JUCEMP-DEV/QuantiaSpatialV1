from __future__ import annotations

import json
from pathlib import Path

import pytest

from app.quantia_spatialV1.reconstruction_core.project_scale_reconciler import ProjectScaleReconciler
from app.quantia_spatialV1.reconstruction_core.raster_density_policy import RasterDensityPolicy
from app.quantia_spatialV1.reconstruction_core.scale_evidence_resolver import ScaleEvidenceResolver
from app.quantia_spatialV1.tests.quantia_case_loader import CASE_LOADERS


TESTS_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = TESTS_DIR / "output"
CASE_IDS = ("casa_viri", "miguel_h", "miguel_v")


@pytest.mark.parametrize("case_id", CASE_IDS)
def test_scale_foundation_v1_standardized(case_id: str) -> None:
    loaded = CASE_LOADERS[case_id]()
    resolver = ScaleEvidenceResolver()
    reconciler = ProjectScaleReconciler()
    policy = RasterDensityPolicy(target_geometry_px_per_m=90.0)

    level_results = []
    for loaded_level in loaded.levels:
        level_result = loaded_level.level_result
        perimeter = level_result.perimeter.editable_perimeter
        scale = resolver.resolve(
            level_view=level_result.level_view,
            evidence=level_result.evidence.evidence,
            perimeter=perimeter,
        )
        recommendation = None
        if scale.selected_m_per_px is not None and scale.current_render_scale is not None:
            recommendation = policy.recommend_from_grounded_scale(
                current_render_scale=scale.current_render_scale,
                current_m_per_px=scale.selected_m_per_px,
            ).model_dump(mode="json")
        level_results.append((loaded_level, scale, recommendation))

    project = reconciler.reconcile(
        levels=[scale for _, scale, _ in level_results],
        target_px_per_m=policy.target_geometry_px_per_m,
    )

    report = {
        "probe_version": "SCALE_FOUNDATION_V1_STANDARDIZED",
        "case_id": loaded.case_id,
        "case": loaded.case_name,
        "gemini_calls_added": 0,
        "target_geometry_px_per_m": policy.target_geometry_px_per_m,
        "project": project.model_dump(mode="json"),
        "levels": [],
    }

    for loaded_level, scale, recommendation in level_results:
        profile = project.for_level(scale.level_view_id)
        report["levels"].append(
            {
                "level": loaded_level.level_name,
                "level_view_id": scale.level_view_id,
                "scale_evidence": scale.model_dump(mode="json"),
                "project_profile": profile.model_dump(mode="json"),
                "raster_recommendation": recommendation,
            }
        )

    out_dir = OUTPUT_DIR / case_id
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"{case_id}__scale_foundation_v1.json"
    out_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    # La prueba no impone una escala por caso. Solo exige trazabilidad y que
    # ninguna planta se marque RESOLVED sin un valor métrico verificable.
    for _, scale, _ in level_results:
        if scale.state == "RESOLVED":
            assert scale.selected_m_per_px is not None
            assert scale.selected_confidence >= 0.75
        if scale.state == "UNRESOLVED":
            assert scale.selected_m_per_px is None
