from __future__ import annotations

import json
import shutil
from pathlib import Path

import cv2
import numpy as np
import pytest

from app.quantia_spatialV1.phase_02_boundaries_experimental import ExperimentalPerimeterPipeline
from app.quantia_spatialV1.phase_02_boundaries.perimeter_models import PerimeterCandidate
from app.quantia_spatialV1.tests.quantia_case_loader import CASE_LOADERS, LoadedCase


TESTS_DIR = Path(__file__).resolve().parent
OUTPUT_ROOT = TESTS_DIR / "output" / "f02_global_context_standardized"
VERSION = "F02_GLOBAL_CONTEXT_EXPERIMENT_V1"


def _safe(value: str) -> str:
    return (
        value.strip().lower().replace(" ", "_")
        .replace("á", "a").replace("é", "e").replace("í", "i")
        .replace("ó", "o").replace("ú", "u")
    )


def _decode(data: bytes) -> np.ndarray:
    image = cv2.imdecode(np.frombuffer(data, dtype=np.uint8), cv2.IMREAD_COLOR)
    if image is None:
        raise RuntimeError("No se pudo decodificar LevelView.raster_bytes.")
    return image


def _draw_candidate(image: np.ndarray, candidate: PerimeterCandidate, color, thickness: int) -> None:
    pts = np.asarray(
        [[int(round(p.x)), int(round(p.y))] for p in candidate.geometry.points],
        dtype=np.int32,
    ).reshape((-1, 1, 2))
    cv2.polylines(image, [pts], True, color, thickness, cv2.LINE_AA)


def _draw_baseline(image: np.ndarray, level_result) -> str | None:
    candidate = level_result.perimeter.resolution.selected
    if candidate is None:
        return None
    # Baseline rojo ancho; si experimental coincide, el verde fino se verá en el centro.
    _draw_candidate(image, candidate, (0, 0, 255), 6)
    return candidate.id


def _run_case(case: LoadedCase) -> None:
    output_dir = OUTPUT_ROOT / case.case_id
    if output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    pipeline = ExperimentalPerimeterPipeline()
    report = {
        "version": VERSION,
        "case_id": case.case_id,
        "case": case.case_name,
        "gemini_calls": 0,
        "visual_policy": "ONE_COMPARISON_PNG_PER_LEVEL_VIEW",
        "legend": {
            "RED": "F02_CANONICAL_BASELINE",
            "GREEN": "F02_EXPERIMENTAL_BEST_HYPOTHESIS",
        },
        "levels": [],
    }

    for loaded in case.levels:
        level_result = loaded.level_result
        raw = list(level_result.evidence.evidence)
        experiment = pipeline.run(
            level_view=level_result.level_view,
            evidence=raw,
        )

        image = _decode(level_result.level_view.raster_bytes)
        baseline_id = _draw_baseline(image, level_result)
        if experiment.best_candidate is not None:
            _draw_candidate(image, experiment.best_candidate, (0, 200, 0), 3)

        cv2.putText(
            image,
            "ROJO=F02 actual | VERDE=experimental",
            (20, 35),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (20, 20, 20),
            2,
            cv2.LINE_AA,
        )
        safe = _safe(loaded.level_name)
        visual_path = output_dir / f"{case.case_id}__{safe}__f02_compare.png"
        assert cv2.imwrite(str(visual_path), image)

        best_score = experiment.scores[0].model_dump(mode="json") if experiment.scores else None
        level_report = {
            "level": loaded.level_name,
            "baseline_state": level_result.perimeter.resolution.state,
            "baseline_candidate_id": baseline_id,
            "experimental_state": experiment.state,
            "experimental_candidate_id": (
                experiment.best_candidate.id if experiment.best_candidate is not None else None
            ),
            "same_candidate_id": (
                baseline_id is not None
                and experiment.best_candidate is not None
                and baseline_id == experiment.best_candidate.id
            ),
            "wall_graph_state": experiment.wall_graph_state,
            "wall_graph_candidate_id": experiment.wall_graph_candidate_id,
            "geometry_candidate_count": experiment.geometry_candidate_count,
            "pooled_candidate_count": experiment.pooled_candidate_count,
            "context_region_count": len(experiment.context_regions),
            "quarantine_region_count": sum(
                1 for region in experiment.context_regions if region.quarantine_enabled
            ),
            "best_score": best_score,
            "top_scores": [score.model_dump(mode="json") for score in experiment.scores[:10]],
            "visual_file": str(visual_path),
            "replay": loaded.replay_source,
        }
        report["levels"].append(level_report)

        print("\n" + "=" * 92)
        print(f"F02 GLOBAL CONTEXT — {case.case_name} — {loaded.level_name}")
        print({
            "baseline": baseline_id,
            "experimental": level_report["experimental_candidate_id"],
            "pooled": experiment.pooled_candidate_count,
            "regions": len(experiment.context_regions),
            "quarantine_regions": level_report["quarantine_region_count"],
            "best_score": None if best_score is None else round(best_score["total_score"], 4),
            "visual": str(visual_path),
        })

    json_path = output_dir / f"{case.case_id}__f02_global_context.json"
    json_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    pngs = sorted(output_dir.glob("*.png"))
    assert len(pngs) == len(case.levels), (
        f"Debe existir exactamente 1 PNG por LevelView; levels={len(case.levels)}, pngs={len(pngs)}"
    )
    print(f"\nJSON: {json_path}")
    print(f"Visuales: {len(pngs)} = 1 por LevelView")


@pytest.mark.parametrize("case_id", ["casa_viri", "miguel_h", "miguel_v"])
def test_f02_global_context_standardized(case_id: str) -> None:
    _run_case(CASE_LOADERS[case_id]())


if __name__ == "__main__":
    for _case_id in ("casa_viri", "miguel_h", "miguel_v"):
        _run_case(CASE_LOADERS[_case_id]())
