from __future__ import annotations

import json
import math
import shutil
from dataclasses import dataclass
from pathlib import Path
from statistics import median
from typing import Iterable

import cv2
import numpy as np
import pytest

from app.quantia_spatialV1.reconstruction_core import ProposalCReconstructionPipeline
from app.quantia_spatialV1.tests.quantia_case_loader import CASE_LOADERS, LoadedCase


PROBE_VERSION = "WALL_CANONICALIZATION_ISOLATED_ALL_3_V1"
BASELINE = (
    "F03_ELEMENT_CONTEXT_ISOLATION_V5 + "
    "F03_SELECTION_CONTRACTS_V1_6 + "
    "CANONICAL_METRIC_RASTER_V2_3_VALIDATED"
)
CASE_IDS = ("casa_viri", "miguel_h", "miguel_v")
TARGET_PX_PER_M = 90.0
TARGET_RELATIVE_TOLERANCE = 0.05

TESTS_DIR = Path(__file__).resolve().parent
OUTPUT_ROOT = TESTS_DIR / "output" / "wall_canonicalization_isolated_v1"

# Este archivo es deliberadamente autosuficiente. No añade servicios ni modifica
# clases del motor. Solo consume la salida publicada por Spatial y produce una
# representación diagnóstica de una línea canónica por muro.


@dataclass(frozen=True)
class _SourceWall:
    wall_id: str
    role: str
    start: tuple[float, float]
    end: tuple[float, float]
    length_px: float
    thickness_px: float | None
    confidence: float | None
    evidence_ids: tuple[str, ...]
    source_candidate_id: str | None


@dataclass(frozen=True)
class _CanonicalWall:
    wall_id: str
    role: str
    start: tuple[float, float]
    end: tuple[float, float]
    length_px: float
    thickness_px: float | None
    confidence: float | None
    source_wall_ids: tuple[str, ...]
    evidence_ids: tuple[str, ...]
    lateral_spread_px: float


@dataclass(frozen=True)
class _GapCandidate:
    first_wall_id: str
    second_wall_id: str
    start: tuple[float, float]
    end: tuple[float, float]
    gap_px: float
    gap_m: float | None


def _safe(value: str) -> str:
    text = "".join(ch.lower() if ch.isalnum() else "_" for ch in value.strip())
    while "__" in text:
        text = text.replace("__", "_")
    return text.strip("_") or "level"


def _decode(data: bytes) -> np.ndarray:
    image = cv2.imdecode(np.frombuffer(data, dtype=np.uint8), cv2.IMREAD_COLOR)
    if image is None:
        raise RuntimeError("No se pudo decodificar LevelView raster.")
    return image


def _source_wall(wall) -> _SourceWall:
    a = wall.reference_path[0]
    b = wall.reference_path[-1]
    return _SourceWall(
        wall_id=str(wall.id),
        role=str(wall.role),
        start=(float(a.x_px), float(a.y_px)),
        end=(float(b.x_px), float(b.y_px)),
        length_px=float(wall.length_px),
        thickness_px=float(wall.thickness_px) if wall.thickness_px is not None else None,
        confidence=float(wall.confidence) if wall.confidence is not None else None,
        evidence_ids=tuple(sorted(str(item) for item in wall.evidence_ids)),
        source_candidate_id=(
            str(wall.source_candidate_id) if wall.source_candidate_id is not None else None
        ),
    )


def _vector(segment: _SourceWall | _CanonicalWall) -> tuple[float, float, float]:
    dx = float(segment.end[0] - segment.start[0])
    dy = float(segment.end[1] - segment.start[1])
    length = max(math.hypot(dx, dy), 1e-9)
    ux, uy = dx / length, dy / length
    # Dirección axial estable: u y -u representan el mismo muro.
    if ux < -1e-9 or (abs(ux) <= 1e-9 and uy < 0.0):
        ux, uy = -ux, -uy
    return ux, uy, length


def _midpoint(segment: _SourceWall | _CanonicalWall) -> tuple[float, float]:
    return (
        (segment.start[0] + segment.end[0]) * 0.5,
        (segment.start[1] + segment.end[1]) * 0.5,
    )


def _angle_diff_deg(first: _SourceWall | _CanonicalWall, second: _SourceWall | _CanonicalWall) -> float:
    ux1, uy1, _ = _vector(first)
    ux2, uy2, _ = _vector(second)
    dot = max(-1.0, min(1.0, abs(ux1 * ux2 + uy1 * uy2)))
    return math.degrees(math.acos(dot))


def _interval_on_axis(
    segment: _SourceWall | _CanonicalWall,
    ux: float,
    uy: float,
) -> tuple[float, float]:
    values = (
        segment.start[0] * ux + segment.start[1] * uy,
        segment.end[0] * ux + segment.end[1] * uy,
    )
    return min(values), max(values)


def _normal_offset(segment: _SourceWall | _CanonicalWall, ux: float, uy: float) -> float:
    nx, ny = -uy, ux
    mx, my = _midpoint(segment)
    return mx * nx + my * ny


def _pair_geometry(first: _SourceWall, second: _SourceWall) -> dict[str, float]:
    ux, uy, _ = _vector(first)
    a0, a1 = _interval_on_axis(first, ux, uy)
    b0, b1 = _interval_on_axis(second, ux, uy)
    overlap = max(0.0, min(a1, b1) - max(a0, b0))
    min_len = max(1e-9, min(a1 - a0, b1 - b0))
    if a1 < b0:
        gap = b0 - a1
    elif b1 < a0:
        gap = a0 - b1
    else:
        gap = 0.0
    lateral = abs(_normal_offset(first, ux, uy) - _normal_offset(second, ux, uy))
    return {
        "angle_deg": _angle_diff_deg(first, second),
        "overlap_px": overlap,
        "overlap_ratio": overlap / min_len,
        "gap_px": gap,
        "lateral_px": lateral,
    }


def _median_thickness_px(walls: Iterable[_SourceWall], fallback_px: float) -> float:
    values = [float(item.thickness_px) for item in walls if item.thickness_px and item.thickness_px > 0]
    return float(median(values)) if values else float(fallback_px)


def _can_share_physical_wall(
    first: _SourceWall,
    second: _SourceWall,
    *,
    px_per_m: float,
) -> bool:
    # Solo consolidamos DIVIDER. F02/perímetro queda idéntico.
    if first.role != "DIVIDER" or second.role != "DIVIDER":
        return False

    geometry = _pair_geometry(first, second)
    if geometry["angle_deg"] > 4.0:
        return False

    pair_thickness = _median_thickness_px((first, second), fallback_px=0.12 * px_per_m)
    lateral_limit = max(
        3.0,
        min(0.22 * px_per_m, 1.10 * pair_thickness),
    )
    if geometry["lateral_px"] > lateral_limit:
        return False

    # No cerramos vanos reales. Solo unimos solapes o micro-fragmentos casi
    # contiguos producidos por la reconstrucción actual.
    micro_gap_limit = max(3.0, 0.12 * px_per_m)
    return geometry["overlap_ratio"] >= 0.18 or geometry["gap_px"] <= micro_gap_limit


def _weighted_axial_direction(items: list[_SourceWall]) -> tuple[float, float]:
    reference = max(items, key=lambda item: item.length_px)
    rux, ruy, _ = _vector(reference)
    sx = 0.0
    sy = 0.0
    for item in items:
        ux, uy, _ = _vector(item)
        if ux * rux + uy * ruy < 0.0:
            ux, uy = -ux, -uy
        weight = max(item.length_px, 1.0)
        sx += ux * weight
        sy += uy * weight
    norm = max(math.hypot(sx, sy), 1e-9)
    return sx / norm, sy / norm


def _weighted_median(values: list[tuple[float, float]]) -> float:
    ordered = sorted(values, key=lambda item: item[0])
    total = sum(max(weight, 0.0) for _, weight in ordered)
    if total <= 1e-9:
        return float(median(value for value, _ in ordered))
    threshold = total * 0.5
    acc = 0.0
    for value, weight in ordered:
        acc += max(weight, 0.0)
        if acc >= threshold:
            return float(value)
    return float(ordered[-1][0])


def _build_canonical_wall(index: int, items: list[_SourceWall]) -> _CanonicalWall:
    assert items
    if len(items) == 1:
        item = items[0]
        return _CanonicalWall(
            wall_id=f"CW_DIV_{index:03d}",
            role=item.role,
            start=item.start,
            end=item.end,
            length_px=item.length_px,
            thickness_px=item.thickness_px,
            confidence=item.confidence,
            source_wall_ids=(item.wall_id,),
            evidence_ids=item.evidence_ids,
            lateral_spread_px=0.0,
        )

    ux, uy = _weighted_axial_direction(items)
    nx, ny = -uy, ux

    offsets: list[tuple[float, float]] = []
    t_values: list[float] = []
    for item in items:
        weight = max(item.length_px, 1.0)
        mx, my = _midpoint(item)
        offsets.append((mx * nx + my * ny, weight))
        for point in (item.start, item.end):
            t_values.append(point[0] * ux + point[1] * uy)

    offset = _weighted_median(offsets)
    t0 = min(t_values)
    t1 = max(t_values)
    start = (ux * t0 + nx * offset, uy * t0 + ny * offset)
    end = (ux * t1 + nx * offset, uy * t1 + ny * offset)
    length = math.hypot(end[0] - start[0], end[1] - start[1])

    thickness_values = [item.thickness_px for item in items if item.thickness_px is not None]
    thickness = float(median(thickness_values)) if thickness_values else None
    confidence_values = [item.confidence for item in items if item.confidence is not None]
    confidence = (
        sum(float(item.confidence) * item.length_px for item in items if item.confidence is not None)
        / max(sum(item.length_px for item in items if item.confidence is not None), 1e-9)
        if confidence_values
        else None
    )
    spread = max(abs(value - offset) for value, _ in offsets)

    return _CanonicalWall(
        wall_id=f"CW_DIV_{index:03d}",
        role="DIVIDER",
        start=start,
        end=end,
        length_px=length,
        thickness_px=thickness,
        confidence=confidence,
        source_wall_ids=tuple(sorted(item.wall_id for item in items)),
        evidence_ids=tuple(sorted({eid for item in items for eid in item.evidence_ids})),
        lateral_spread_px=float(spread),
    )


def _canonicalize_dividers(
    dividers: list[_SourceWall],
    *,
    px_per_m: float,
) -> list[_CanonicalWall]:
    # Union-Find conservador sobre hipótesis cercanas. No utiliza información del
    # Mini-Engine ni intenta rellenar openings.
    parent = list(range(len(dividers)))

    def find(i: int) -> int:
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    def union(a: int, b: int) -> None:
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra

    for i in range(len(dividers)):
        for j in range(i + 1, len(dividers)):
            if _can_share_physical_wall(dividers[i], dividers[j], px_per_m=px_per_m):
                union(i, j)

    grouped: dict[int, list[_SourceWall]] = {}
    for i, wall in enumerate(dividers):
        grouped.setdefault(find(i), []).append(wall)

    # Evita puentes transitivos extremos: si un componente quedó muy ancho,
    # se subdivide por offset normal usando el espesor mediano como escala.
    refined: list[list[_SourceWall]] = []
    for group in grouped.values():
        if len(group) <= 1:
            refined.append(group)
            continue
        ux, uy = _weighted_axial_direction(group)
        values = sorted(
            ((_normal_offset(item, ux, uy), item) for item in group),
            key=lambda pair: pair[0],
        )
        thickness = _median_thickness_px(group, fallback_px=0.12 * px_per_m)
        split_gap = max(0.08 * px_per_m, 1.35 * thickness)
        current: list[_SourceWall] = [values[0][1]]
        prev = values[0][0]
        for offset, item in values[1:]:
            if abs(offset - prev) > split_gap:
                refined.append(current)
                current = [item]
            else:
                current.append(item)
            prev = offset
        refined.append(current)

    canonical = [_build_canonical_wall(index, group) for index, group in enumerate(refined, 1)]
    canonical.sort(key=lambda item: (round(item.start[1], 3), round(item.start[0], 3), item.wall_id))
    return canonical


def _perimeter_as_canonical(walls: list[_SourceWall]) -> list[_CanonicalWall]:
    output: list[_CanonicalWall] = []
    for index, item in enumerate(walls, 1):
        output.append(
            _CanonicalWall(
                wall_id=f"CW_PER_{index:03d}",
                role="PERIMETER",
                start=item.start,
                end=item.end,
                length_px=item.length_px,
                thickness_px=item.thickness_px,
                confidence=item.confidence,
                source_wall_ids=(item.wall_id,),
                evidence_ids=item.evidence_ids,
                lateral_spread_px=0.0,
            )
        )
    return output


def _canonicalize(walls, *, px_per_m: float) -> list[_CanonicalWall]:
    source = [_source_wall(item) for item in walls]
    perimeter = [item for item in source if item.role == "PERIMETER"]
    dividers = [item for item in source if item.role == "DIVIDER"]
    return _perimeter_as_canonical(perimeter) + _canonicalize_dividers(dividers, px_per_m=px_per_m)


def _canonical_pair_geometry(first: _CanonicalWall, second: _CanonicalWall) -> dict[str, float]:
    ux, uy, _ = _vector(first)
    a0, a1 = _interval_on_axis(first, ux, uy)
    b0, b1 = _interval_on_axis(second, ux, uy)
    overlap = max(0.0, min(a1, b1) - max(a0, b0))
    if a1 < b0:
        gap = b0 - a1
        p1_t, p2_t = a1, b0
    elif b1 < a0:
        gap = a0 - b1
        p1_t, p2_t = b1, a0
    else:
        gap = 0.0
        p1_t = p2_t = max(a0, b0)
    lateral = abs(_normal_offset(first, ux, uy) - _normal_offset(second, ux, uy))
    nx, ny = -uy, ux
    offset = (_normal_offset(first, ux, uy) + _normal_offset(second, ux, uy)) * 0.5
    p1 = (ux * p1_t + nx * offset, uy * p1_t + ny * offset)
    p2 = (ux * p2_t + nx * offset, uy * p2_t + ny * offset)
    return {
        "angle_deg": _angle_diff_deg(first, second),
        "overlap_px": overlap,
        "gap_px": gap,
        "lateral_px": lateral,
        "p1_x": p1[0],
        "p1_y": p1[1],
        "p2_x": p2[0],
        "p2_y": p2[1],
    }


def _find_gap_candidates(
    walls: list[_CanonicalWall],
    *,
    px_per_m: float,
) -> list[_GapCandidate]:
    # Solo señala huecos; NO los rellena ni decide DOOR/WINDOW/MISSING_WALL.
    output: list[_GapCandidate] = []
    dividers = [item for item in walls if item.role == "DIVIDER"]
    min_gap = 0.15 * px_per_m
    max_gap = 2.40 * px_per_m
    lateral_limit = 0.10 * px_per_m

    for i in range(len(dividers)):
        for j in range(i + 1, len(dividers)):
            first, second = dividers[i], dividers[j]
            geometry = _canonical_pair_geometry(first, second)
            if geometry["angle_deg"] > 3.0:
                continue
            if geometry["lateral_px"] > lateral_limit:
                continue
            gap = geometry["gap_px"]
            if gap < min_gap or gap > max_gap:
                continue
            output.append(
                _GapCandidate(
                    first_wall_id=first.wall_id,
                    second_wall_id=second.wall_id,
                    start=(geometry["p1_x"], geometry["p1_y"]),
                    end=(geometry["p2_x"], geometry["p2_y"]),
                    gap_px=float(gap),
                    gap_m=float(gap / px_per_m) if px_per_m > 0 else None,
                )
            )
    return output


def _draw_segment(image, start, end, color, thickness):
    cv2.line(
        image,
        (int(round(start[0])), int(round(start[1]))),
        (int(round(end[0])), int(round(end[1]))),
        color,
        thickness,
        cv2.LINE_AA,
    )


def _draw_source(image, walls: list[_SourceWall]) -> None:
    for wall in walls:
        color = (105, 105, 105) if wall.role == "PERIMETER" else (180, 180, 180)
        _draw_segment(image, wall.start, wall.end, color, 2)


def _draw_canonical(image, walls: list[_CanonicalWall]) -> None:
    for wall in walls:
        thickness = 4 if wall.role == "PERIMETER" else 3
        _draw_segment(image, wall.start, wall.end, (0, 0, 0), thickness)


def _draw_gaps(image, gaps: list[_GapCandidate]) -> None:
    for gap in gaps:
        _draw_segment(image, gap.start, gap.end, (0, 165, 255), 3)
        cx = int(round((gap.start[0] + gap.end[0]) * 0.5))
        cy = int(round((gap.start[1] + gap.end[1]) * 0.5))
        cv2.circle(image, (cx, cy), 5, (0, 165, 255), 2, cv2.LINE_AA)


def _serialize_wall(item: _CanonicalWall) -> dict:
    return {
        "id": item.wall_id,
        "role": item.role,
        "start": [item.start[0], item.start[1]],
        "end": [item.end[0], item.end[1]],
        "length_px": item.length_px,
        "thickness_px": item.thickness_px,
        "confidence": item.confidence,
        "source_wall_ids": list(item.source_wall_ids),
        "evidence_ids": list(item.evidence_ids),
        "source_wall_count": len(item.source_wall_ids),
        "lateral_spread_px": item.lateral_spread_px,
    }


def _serialize_gap(item: _GapCandidate) -> dict:
    return {
        "first_wall_id": item.first_wall_id,
        "second_wall_id": item.second_wall_id,
        "start": [item.start[0], item.start[1]],
        "end": [item.end[0], item.end[1]],
        "gap_px": item.gap_px,
        "gap_m": item.gap_m,
    }


def _run_level(*, pipeline, loaded, output_dir: Path, case_id: str, scale_profile) -> dict:
    level_result = loaded.level_result
    perimeter = level_result.perimeter.editable_perimeter
    assert perimeter is not None

    spatial = pipeline.run(
        level_view=level_result.level_view,
        perimeter=perimeter,
        evidence=list(level_result.evidence.evidence),
        scale_profile=scale_profile,
    )
    level = spatial.parametric_model.levels[0]
    before_snapshot = [wall.model_dump(mode="json") for wall in level.walls]

    px_per_m = 1.0 / float(scale_profile.local_m_per_px)
    canonical = _canonicalize(level.walls, px_per_m=px_per_m)
    gaps = _find_gap_candidates(canonical, px_per_m=px_per_m)

    # Prueba aislada: ninguna mutación del modelo Spatial.
    after_snapshot = [wall.model_dump(mode="json") for wall in level.walls]
    assert after_snapshot == before_snapshot, "El probe aislado modificó muros Spatial."

    source = [_source_wall(item) for item in level.walls]
    source_perimeter = [item for item in source if item.role == "PERIMETER"]
    source_dividers = [item for item in source if item.role == "DIVIDER"]
    canonical_perimeter = [item for item in canonical if item.role == "PERIMETER"]
    canonical_dividers = [item for item in canonical if item.role == "DIVIDER"]

    assert len(canonical_perimeter) == len(source_perimeter), "F02/perímetro fue alterado."
    assert len(canonical_dividers) <= len(source_dividers), "Canonicalization aumentó muros divider."
    mapped = sorted(source_id for wall in canonical_dividers for source_id in wall.source_wall_ids)
    assert mapped == sorted(item.wall_id for item in source_dividers), "Se perdió linaje de muros source."

    raster = _decode(level_result.level_view.raster_bytes)
    white = np.full_like(raster, 255)
    before = white.copy()
    after = white.copy()
    faded = cv2.addWeighted(raster, 0.14, np.full_like(raster, 255), 0.86, 0.0)
    overlay = faded.copy()
    audit = faded.copy()

    _draw_source(before, source)
    _draw_canonical(after, canonical)
    _draw_canonical(overlay, canonical)
    _draw_source(audit, source)
    _draw_canonical(audit, canonical)
    _draw_gaps(audit, gaps)

    safe = _safe(loaded.level_name)
    before_path = output_dir / f"{case_id}__{safe}__wall_canonicalization_before.png"
    after_path = output_dir / f"{case_id}__{safe}__wall_canonicalization_after.png"
    overlay_path = output_dir / f"{case_id}__{safe}__wall_canonicalization_overlay.png"
    audit_path = output_dir / f"{case_id}__{safe}__wall_canonicalization_gap_audit.png"
    cv2.imwrite(str(before_path), before)
    cv2.imwrite(str(after_path), after)
    cv2.imwrite(str(overlay_path), overlay)
    cv2.imwrite(str(audit_path), audit)

    collapsed_groups = [item for item in canonical_dividers if len(item.source_wall_ids) > 1]
    collapsed_source_count = sum(len(item.source_wall_ids) - 1 for item in collapsed_groups)

    return {
        "level": loaded.level_name,
        "level_view_id": level_result.level_view.id,
        "scale_profile": scale_profile.model_dump(mode="json"),
        "px_per_m": px_per_m,
        "source_wall_count": len(source),
        "source_perimeter_count": len(source_perimeter),
        "source_divider_count": len(source_dividers),
        "canonical_wall_count": len(canonical),
        "canonical_perimeter_count": len(canonical_perimeter),
        "canonical_divider_count": len(canonical_dividers),
        "collapsed_group_count": len(collapsed_groups),
        "collapsed_source_count": collapsed_source_count,
        "gap_candidate_count": len(gaps),
        "canonical_walls": [_serialize_wall(item) for item in canonical],
        "gap_candidates": [_serialize_gap(item) for item in gaps],
        "before_visual": str(before_path),
        "after_visual": str(after_path),
        "overlay_visual": str(overlay_path),
        "gap_audit_visual": str(audit_path),
    }


def _run_case(case: LoadedCase) -> None:
    output_dir = OUTPUT_ROOT / case.case_id
    if output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    pipeline = ProposalCReconstructionPipeline()
    scale_inputs = []
    for loaded in case.levels:
        perimeter = loaded.level_result.perimeter.editable_perimeter
        assert perimeter is not None
        scale_inputs.append((loaded.level_result.level_view, perimeter))

    project_scale = pipeline.build_project_scale_context(levels=scale_inputs)
    assert project_scale.state == "RESOLVED"

    report = {
        "probe_version": PROBE_VERSION,
        "baseline": BASELINE,
        "case_id": case.case_id,
        "case": case.case_name,
        "gemini_calls_added": 0,
        "engine_files_modified": 0,
        "canonical_representation": "CENTERLINE_ONLY_DIAGNOSTIC",
        "gap_policy": "DETECT_ONLY_DO_NOT_FILL",
        "legend": {
            "source_walls_before": "GRAY",
            "canonical_walls_after": "BLACK",
            "gap_candidates_audit": "ORANGE",
        },
        "project_scale": project_scale.model_dump(mode="json"),
        "levels": [],
        "failures": [],
    }

    for loaded in case.levels:
        profile = project_scale.for_level(loaded.level_result.level_view.id)
        assert profile.local_m_per_px is not None
        px_per_m = 1.0 / profile.local_m_per_px
        relative_error = abs(px_per_m - TARGET_PX_PER_M) / TARGET_PX_PER_M
        if profile.state != "RESOLVED" or relative_error > TARGET_RELATIVE_TOLERANCE:
            report["failures"].append(
                f"{loaded.level_name}:SCALE_GUARD:{profile.state}:{px_per_m:.6f}"
            )
            continue

        level_report = _run_level(
            pipeline=pipeline,
            loaded=loaded,
            output_dir=output_dir,
            case_id=case.case_id,
            scale_profile=profile,
        )
        report["levels"].append(level_report)
        print("\n" + "=" * 100)
        print(f"WALL CANONICALIZATION ISOLATED V1 — {case.case_name} — {loaded.level_name}")
        print({
            "source_walls": level_report["source_wall_count"],
            "source_dividers": level_report["source_divider_count"],
            "canonical_dividers": level_report["canonical_divider_count"],
            "collapsed_groups": level_report["collapsed_group_count"],
            "collapsed_source_lines": level_report["collapsed_source_count"],
            "gap_candidates": level_report["gap_candidate_count"],
        })

    report["passed"] = not report["failures"]
    json_path = output_dir / f"{case.case_id}__wall_canonicalization_isolated_v1.json"
    json_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\nJSON: {json_path}")
    assert not report["failures"], json.dumps(report["failures"], ensure_ascii=False)


@pytest.mark.parametrize("case_id", CASE_IDS)
def test_quantia_spatial_wall_canonicalization_isolated_all_3_v1(case_id: str) -> None:
    _run_case(CASE_LOADERS[case_id]())


if __name__ == "__main__":
    for _case_id in CASE_IDS:
        _run_case(CASE_LOADERS[_case_id]())
