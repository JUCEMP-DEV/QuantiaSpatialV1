import math

from shapely.geometry import box

from app.quantia_spatialV1.reconstruction_core.candidate_context_gate import CandidateContextGate
from app.quantia_spatialV1.reconstruction_core.candidate_models import WallCandidate, WallEvidenceVector
from app.quantia_spatialV1.reconstruction_core.context_models import ContextRegion
from app.quantia_spatialV1.reconstruction_core.drawing_model import (
    DrawingBBox,
    DrawingCurve,
    DrawingLine,
    DrawingModel,
    DrawingModelDiagnostics,
    DrawingPoint,
)
from app.quantia_spatialV1.reconstruction_core.element_context_detector import ElementContextDetector
from app.quantia_spatialV1.reconstruction_core.level_scale_normalizer import LevelScaleProfile


def _profile():
    return LevelScaleProfile(
        level_view_id="LV",
        state="RESOLVED",
        local_m_per_px=1.0 / 90.0,
        canonical_m_per_px=1.0 / 90.0,
        scale_factor_to_canonical=1.0,
        local_min_dim_px=800.0,
        normalized_min_dim_px=800.0,
        project_reference_min_dim_normalized_px=800.0,
        project_reference_area_normalized_px2=800000.0,
        source="TEST",
        confidence=1.0,
    )


def _line(ident, a, b, *, dashed=False, evidence_ids=None, metadata=None):
    dx = b[0] - a[0]
    dy = b[1] - a[1]
    return DrawingLine(
        id=ident,
        start=DrawingPoint(x=a[0], y=a[1]),
        end=DrawingPoint(x=b[0], y=b[1]),
        length_px=math.hypot(dx, dy),
        angle_deg=math.degrees(math.atan2(dy, dx)) % 180.0,
        dashed=dashed,
        evidence_ids=list(evidence_ids or [ident]),
        sources=["PYMUPDF"],
        metadata=dict(metadata or {}),
    )


def _drawing(*, lines=None, curves=None):
    return DrawingModel(
        level_view_id="LV",
        width_px=1200,
        height_px=900,
        lines=list(lines or []),
        curves=list(curves or []),
        diagnostics=DrawingModelDiagnostics(
            raw_evidence_count=0,
            normalized_line_count=len(lines or []),
            normalized_region_count=0,
            normalized_curve_count=len(curves or []),
            text_count=0,
            semantic_observation_count=0,
            lsd_line_count=0,
            region_centerline_count=0,
            source_counts={},
        ),
    )


def _candidate(ident, a, b, *, face_ids, metric=0.9, metadata=None):
    dx = b[0] - a[0]
    dy = b[1] - a[1]
    payload = {"metric_wall_band_support": metric}
    payload.update(metadata or {})
    return WallCandidate(
        id=ident,
        generator="DOUBLE_FACE",
        start=DrawingPoint(x=a[0], y=a[1]),
        end=DrawingPoint(x=b[0], y=b[1]),
        angle_deg=math.degrees(math.atan2(dy, dx)) % 180.0,
        length_px=math.hypot(dx, dy),
        thickness_px=12.0,
        face_ids=list(face_ids),
        evidence_ids=list(face_ids),
        source_names=["PYMUPDF"],
        evidence=WallEvidenceVector(
            pair_overlap=1.0,
            thickness_support=0.9,
            vector_support=1.0,
            raster_line_support=1.0,
            region_support=0.9,
            source_consensus=0.75,
            perimeter_containment=1.0,
        ),
        prior_score=0.8,
        metadata=payload,
    )


def _door_curve(x=100, y=100, r=90):
    return DrawingCurve(
        id=f"CURVE_{x}_{y}",
        control_points=[
            DrawingPoint(x=x, y=y + r),
            DrawingPoint(x=x, y=y + r * 0.55),
            DrawingPoint(x=x + r * 0.55, y=y),
            DrawingPoint(x=x + r, y=y),
        ],
        bbox=DrawingBBox(x_min=x, y_min=y, x_max=x + r, y_max=y + r),
        evidence_ids=[f"CURVE_{x}_{y}"],
        sources=["PYMUPDF"],
    )


def test_v3_axis_bubble_outside_architecture_is_not_door():
    curve = _door_curve(x=30, y=30, r=70)
    lines = [
        _line("FALSE_RADIAL", (30, 100), (30, 35)),
        _line("FALSE_GRID", (0, 30), (250, 30)),
    ]
    regions = ElementContextDetector().detect(
        drawing=_drawing(lines=lines, curves=[curve]),
        scale_profile=_profile(),
        architectural_polygon=box(250, 200, 1100, 850),
    )
    assert not any(region.region_type == "DOOR_REGION" for region in regions)


def test_v3_partial_door_leaf_with_strong_host_is_accepted():
    curve = _door_curve(x=100, y=100, r=90)
    lines = [
        # Hoja fragmentada: no alcanza el radio completo, caso que V2 rechazaba.
        _line("LEAF_FRAGMENT", (100, 100), (100, 152)),
        _line("HOST", (35, 100), (350, 100)),
    ]
    regions = ElementContextDetector().detect(
        drawing=_drawing(lines=lines, curves=[curve]),
        scale_profile=_profile(),
        architectural_polygon=box(20, 20, 1000, 800),
    )
    doors = [region for region in regions if region.region_type == "DOOR_REGION"]
    assert doors
    door = doors[0]
    assert door.metadata["validation_contract"] == "ARC_PARTIAL_LEAF_HOST_ARCHITECTURE_V3"
    assert "LEAF_FRAGMENT" in door.member_line_ids
    assert "HOST" in set(door.metadata["host_line_ids"])


def test_v3_curve_with_leaf_but_no_host_is_not_door():
    curve = _door_curve(x=100, y=100, r=90)
    lines = [_line("LEAF", (100, 190), (100, 110))]
    regions = ElementContextDetector().detect(
        drawing=_drawing(lines=lines, curves=[curve]),
        scale_profile=_profile(),
        architectural_polygon=box(20, 20, 1000, 800),
    )
    assert not any(region.region_type == "DOOR_REGION" for region in regions)


def test_v3_flanked_parallel_frame_creates_window_region():
    frames = [
        _line("W1", (300, 300), (390, 300)),
        _line("W2", (300, 306), (390, 306)),
        _line("W3", (300, 312), (390, 312)),
    ]
    host_left = _line("HOST_LEFT", (170, 300), (295, 300))
    host_right = _line("HOST_RIGHT", (395, 300), (570, 300))
    regions = ElementContextDetector().detect(
        drawing=_drawing(lines=[*frames, host_left, host_right]),
        scale_profile=_profile(),
        architectural_polygon=box(50, 50, 1100, 850),
    )
    windows = [region for region in regions if region.region_type == "WINDOW_REGION"]
    assert windows
    window = windows[0]
    assert window.metadata["validation_contract"] == "FRAME_FLANKED_HOST_GAP_V3"
    assert window.metadata["host_embedding_support"] >= 0.52
    assert {"HOST_LEFT", "HOST_RIGHT"}.issubset(set(window.metadata["host_line_ids"]))


def test_v3_continuous_wall_band_is_not_window():
    frames = [
        _line("W1", (300, 300), (390, 300)),
        _line("W2", (300, 306), (390, 306)),
        _line("W3", (300, 312), (390, 312)),
    ]
    # Firma que V2 confundía con host de ventana: una línea continua atraviesa
    # toda la supuesta abertura.
    through = _line("WALL_CONTINUOUS", (170, 300), (570, 300))
    regions = ElementContextDetector().detect(
        drawing=_drawing(lines=[*frames, through]),
        scale_profile=_profile(),
        architectural_polygon=box(50, 50, 1100, 850),
    )
    assert not any(region.region_type == "WINDOW_REGION" for region in regions)


def test_v3_explicit_opening_host_lineage_is_active():
    region = ContextRegion(
        id="WINDOW",
        region_type="WINDOW_REGION",
        bbox=DrawingBBox(x_min=290, y_min=285, x_max=400, y_max=325),
        confidence=0.92,
        quarantine_enabled=True,
        member_line_ids=["W1", "W2"],
        metadata={
            "element_role": "OPENING",
            "negative_mask": False,
            "host_embedding_support": 0.9,
            "through_wall_support": 0.0,
            "host_line_ids": ["HOST_RAW_A", "HOST_RAW_B"],
        },
    )
    host = _candidate(
        "HOST",
        (220, 305),
        (500, 305),
        face_ids=["H1", "H2"],
        metric=1.0,
        metadata={"face_lineage_groups": [["H1", "HOST_RAW_A"], ["H2", "HOST_RAW_B"]]},
    )
    result = CandidateContextGate().apply(candidates=[host], regions=[region])
    decision = result.decisions[0]
    assert decision.state == "ACTIVE"
    assert decision.reason == "ACTIVE_EXPLICIT_HOST_WALL_WINDOW_REGION"


def test_v3_direct_window_member_with_strong_continuity_is_review_not_quarantine():
    region = ContextRegion(
        id="WINDOW",
        region_type="WINDOW_REGION",
        bbox=DrawingBBox(x_min=290, y_min=285, x_max=400, y_max=325),
        confidence=0.92,
        quarantine_enabled=True,
        member_line_ids=["W1", "W2"],
        metadata={
            "element_role": "OPENING",
            "negative_mask": False,
            "host_embedding_support": 0.9,
            "through_wall_support": 0.0,
        },
    )
    candidate = _candidate(
        "FALSE_FRAME_WALL",
        (250, 305),
        (450, 305),
        face_ids=["REP1", "REP2"],
        metric=0.96,
        metadata={"face_lineage_groups": [["REP1", "W1"], ["REP2", "W2"]]},
    )
    result = CandidateContextGate().apply(candidates=[candidate], regions=[region])
    decision = result.decisions[0]
    assert decision.state == "REVIEW"
    assert "STRONG_WALL_CONTINUITY" in decision.reason


def test_v3_local_verified_window_member_can_still_be_quarantined():
    region = ContextRegion(
        id="WINDOW",
        region_type="WINDOW_REGION",
        bbox=DrawingBBox(x_min=290, y_min=285, x_max=400, y_max=325),
        confidence=0.92,
        quarantine_enabled=True,
        member_line_ids=["W1", "W2"],
        metadata={
            "element_role": "OPENING",
            "negative_mask": False,
            "host_embedding_support": 0.9,
            "through_wall_support": 0.0,
        },
    )
    frame = _candidate(
        "FRAME",
        (300, 305),
        (390, 305),
        face_ids=["REP1", "REP2"],
        metric=0.62,
        metadata={"face_lineage_groups": [["REP1", "W1"], ["REP2", "W2"]]},
    )
    result = CandidateContextGate().apply(candidates=[frame], regions=[region])
    assert result.decisions[0].state == "QUARANTINE"
