from __future__ import annotations

import math

from app.quantia_spatialV1.phase_02_boundaries.perimeter_delivery import (
    EditablePerimeterModel,
    EditablePerimeterVertex,
    EditablePerimeterWall,
    PerimeterComparisonBaseline,
    PerimeterMetricSummary,
)
from app.quantia_spatialV1.phase_02_boundaries.perimeter_models import PerimeterPointPx
from app.quantia_spatialV1.reconstruction_core.candidate_context_gate import CandidateContextGate
from app.quantia_spatialV1.reconstruction_core.candidate_models import WallCandidate, WallEvidenceVector
from app.quantia_spatialV1.reconstruction_core.context_region_detector import ContextRegionDetector
from app.quantia_spatialV1.reconstruction_core.drawing_model import (
    DrawingBBox,
    DrawingLine,
    DrawingModel,
    DrawingModelDiagnostics,
    DrawingPoint,
    DrawingText,
)


def _line(line_id: str, x1: float, y1: float, x2: float, y2: float, *, dashed: bool = False) -> DrawingLine:
    dx, dy = x2 - x1, y2 - y1
    return DrawingLine(
        id=line_id,
        start=DrawingPoint(x=x1, y=y1),
        end=DrawingPoint(x=x2, y=y2),
        length_px=math.hypot(dx, dy),
        angle_deg=math.degrees(math.atan2(dy, dx)) % 180.0,
        stroke_width_px=1.0,
        dashed=dashed,
        evidence_ids=[line_id],
        sources=["PYMUPDF"],
        confidence=1.0,
    )


def _drawing(lines: list[DrawingLine], *, texts: list[DrawingText] | None = None) -> DrawingModel:
    return DrawingModel(
        level_view_id="LV",
        width_px=600,
        height_px=400,
        lines=lines,
        texts=texts or [],
        diagnostics=DrawingModelDiagnostics(
            raw_evidence_count=len(lines),
            normalized_line_count=len(lines),
            normalized_region_count=0,
            text_count=len(texts or []),
            semantic_observation_count=0,
            lsd_line_count=0,
            region_centerline_count=0,
            source_counts={"PYMUPDF": len(lines)},
        ),
    )


def _perimeter() -> EditablePerimeterModel:
    pts = [(20.0, 20.0), (580.0, 20.0), (580.0, 380.0), (20.0, 380.0)]
    vertices = [
        EditablePerimeterVertex(
            id=f"V{i}",
            sequence_index=i,
            point_px=PerimeterPointPx(x=x, y=y),
            incoming_wall_id=f"W{(i - 1) % 4}",
            outgoing_wall_id=f"W{i}",
        )
        for i, (x, y) in enumerate(pts)
    ]
    walls = []
    for i, ((x1, y1), (x2, y2)) in enumerate(zip(pts, pts[1:] + pts[:1])):
        orientation = "HORIZONTAL" if abs(y2 - y1) < 1e-6 else "VERTICAL"
        side = ["TOP", "RIGHT", "BOTTOM", "LEFT"][i]
        walls.append(
            EditablePerimeterWall(
                id=f"W{i}",
                sequence_index=i,
                start_vertex_id=f"V{i}",
                end_vertex_id=f"V{(i + 1) % 4}",
                drawing_orientation=orientation,
                drawing_side=side,
                length_px=math.hypot(x2 - x1, y2 - y1),
                metric_status="UNRESOLVED",
            )
        )
    return EditablePerimeterModel(
        id="P",
        level_view_id="LV",
        source_wall_layer_id="WL",
        source_candidate_id="PC",
        status="GEOMETRY_ONLY",
        vertices=vertices,
        walls=walls,
        metric_summary=PerimeterMetricSummary(
            status="UNRESOLVED",
            grounded_wall_count=0,
            unresolved_wall_ids=[wall.id for wall in walls],
        ),
        comparison_baseline=PerimeterComparisonBaseline(
            available=False,
            state="UNAVAILABLE",
        ),
    )


def _grid_lines() -> list[DrawingLine]:
    lines: list[DrawingLine] = []
    # 5 columnas x 2 filas = 10 celdas repetidas. Las líneas son físicas y
    # continuas para que el test valide la lógica de celdas, no un caso concreto.
    xs = [160, 200, 240, 280, 320, 360]
    ys = [140, 180, 220]
    for idx, y in enumerate(ys):
        lines.append(_line(f"H{idx}", xs[0], y, xs[-1], y))
    for idx, x in enumerate(xs):
        lines.append(_line(f"V{idx}", x, ys[0], x, ys[-1]))
    return lines


def test_v6_detecta_celdas_repetidas_como_acabado() -> None:
    detector = ContextRegionDetector()
    regions = detector.detect(drawing=_drawing(_grid_lines()), perimeter=_perimeter())
    floor = [region for region in regions if region.region_type == "FLOOR_FINISH_GRID_REGION"]
    assert floor, [region.region_type for region in regions]
    assert max(int(region.metadata.get("cell_count", 0)) for region in floor) >= 6


def test_v6_detecta_hatch_diagonal() -> None:
    lines = []
    for index in range(8):
        offset = index * 12.0
        lines.append(_line(f"D{index}", 120 + offset, 120, 200 + offset, 200))
    detector = ContextRegionDetector()
    regions = detector.detect(drawing=_drawing(lines), perimeter=_perimeter())
    assert any(region.region_type == "HATCH_FILL_REGION" for region in regions)


def test_v6_detecta_ejes_discontinuos_largos() -> None:
    lines = [
        _line("AX0", 80, 90, 520, 90, dashed=True),
        _line("AX1", 80, 180, 520, 180, dashed=True),
        _line("AX2", 80, 270, 520, 270, dashed=True),
    ]
    detector = ContextRegionDetector()
    regions = detector.detect(drawing=_drawing(lines), perimeter=_perimeter())
    assert any(region.region_type == "AXIS_GRID_REGION" for region in regions)


def test_v6_detecta_region_de_cota_por_texto_y_lineas() -> None:
    lines = [
        _line("DIM_H", 200, 100, 340, 100),
        _line("DIM_V1", 200, 85, 200, 115),
        _line("DIM_V2", 340, 85, 340, 115),
    ]
    text = DrawingText(
        id="T1",
        text="3.50",
        bbox=DrawingBBox(x_min=255, y_min=88, x_max=285, y_max=99),
        evidence_ids=["T1"],
        sources=["PYMUPDF"],
        confidence=1.0,
    )
    detector = ContextRegionDetector()
    regions = detector.detect(drawing=_drawing(lines, texts=[text]), perimeter=_perimeter())
    assert any(region.region_type == "DIMENSION_REGION" for region in regions)


def test_v6_publica_proteccion_f02() -> None:
    detector = ContextRegionDetector()
    regions = detector.detect(drawing=_drawing([]), perimeter=_perimeter())
    protected = [region for region in regions if region.region_type == "WALL_PROTECTED_REGION"]
    assert len(protected) == 4


def test_v6_gate_cuarentena_celda_y_protege_perimetro() -> None:
    drawing = _drawing(_grid_lines())
    perimeter = _perimeter()
    detector = ContextRegionDetector()
    regions = detector.detect(drawing=drawing, perimeter=perimeter)

    grid_candidate = WallCandidate(
        id="GRID_CANDIDATE",
        generator="DOUBLE_FACE",
        start=DrawingPoint(x=200, y=140),
        end=DrawingPoint(x=200, y=220),
        angle_deg=90.0,
        length_px=80.0,
        thickness_px=4.0,
        face_ids=["V1"],
        evidence_ids=["V1"],
        source_names=["PYMUPDF"],
        evidence=WallEvidenceVector(
            pair_overlap=1.0,
            thickness_support=0.9,
            vector_support=1.0,
            raster_line_support=1.0,
            region_support=1.0,
            source_consensus=0.75,
            perimeter_containment=1.0,
        ),
        prior_score=0.90,
    )
    perimeter_candidate = WallCandidate(
        id="PERIMETER_CANDIDATE",
        generator="DOUBLE_FACE",
        start=DrawingPoint(x=40, y=20),
        end=DrawingPoint(x=560, y=20),
        angle_deg=0.0,
        length_px=520.0,
        thickness_px=8.0,
        face_ids=[],
        evidence_ids=[],
        source_names=["PYMUPDF"],
        evidence=WallEvidenceVector(
            pair_overlap=1.0,
            thickness_support=0.9,
            vector_support=1.0,
            raster_line_support=1.0,
            region_support=1.0,
            source_consensus=0.75,
            perimeter_containment=1.0,
        ),
        prior_score=0.95,
    )

    result = CandidateContextGate().apply(
        candidates=[grid_candidate, perimeter_candidate],
        regions=regions,
    )
    decisions = {decision.candidate_id: decision for decision in result.decisions}
    assert decisions["GRID_CANDIDATE"].state in {"QUARANTINE", "REVIEW"}
    assert decisions["PERIMETER_CANDIDATE"].state == "PROTECTED"
