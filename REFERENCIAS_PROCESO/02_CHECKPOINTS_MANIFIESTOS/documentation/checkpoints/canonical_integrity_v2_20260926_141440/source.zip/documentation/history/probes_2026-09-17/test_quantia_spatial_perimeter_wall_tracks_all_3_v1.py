from __future__ import annotations

import json
import math
import shutil
from dataclasses import dataclass
from pathlib import Path
from statistics import median
from typing import Iterable

import cv2
import numpy as np
import pytest

from app.quantia_spatialV1.reconstruction_core import ProposalCReconstructionPipeline
from app.quantia_spatialV1.tests.quantia_case_loader import CASE_LOADERS, LoadedCase


PROBE_VERSION = "PERIMETER_WALL_TRACKS_ALL_3_V1"
BASELINE = (
    "WALL_CANONICALIZATION_ISOLATED_V1 + "
    "F03_ARCHITECTURAL_CORE_VISUAL_V1 + "
    "CANONICAL_METRIC_RASTER_V2_3_VALIDATED"
)
CASE_IDS = ("casa_viri", "miguel_h", "miguel_v")
TARGET_PX_PER_M = 90.0
TARGET_RELATIVE_TOLERANCE = 0.05

TESTS_DIR = Path(__file__).resolve().parent
OUTPUT_ROOT = TESTS_DIR / "output" / "perimeter_wall_tracks_v1"


@dataclass(frozen=True)
class _SourceWall:
    wall_id: str
    role: str
    start: tuple[float, float]
    end: tuple[float, float]
    length_px: float
    thickness_px: float | None
    confidence: float | None
    evidence_ids: tuple[str, ...]
    source_candidate_id: str | None


@dataclass(frozen=True)
class _PhysicalWall:
    wall_id: str
    start: tuple[float, float]
    end: tuple[float, float]
    length_px: float
    thickness_px: float | None
    confidence: float | None
    source_wall_ids: tuple[str, ...]
    source_roles: tuple[str, ...]
    evidence_ids: tuple[str, ...]
    lateral_spread_px: float


@dataclass(frozen=True)
class _PerimeterTrack:
    wall_id: str
    start: tuple[float, float]
    end: tuple[float, float]
    length_px: float
    thickness_px: float | None
    confidence: float | None
    source_wall_ids: tuple[str, ...]
    source_roles: tuple[str, ...]
    evidence_ids: tuple[str, ...]
    dominant_side: str
    side_votes: dict[str, int]


@dataclass(frozen=True)
class _MaskBundle:
    wall_mask: np.ndarray
    closed_mask: np.ndarray
    footprint_mask: np.ndarray


# Probe aislado: no toca F02 ni Spatial. Reutiliza la lógica de consolidación
# de divisorios para formar WallTracks físicos y después infiere el perímetro
# sobre una huella rellenada, produciendo salidas visuales limpias.


def _safe(value: str) -> str:
    text = "".join(ch.lower() if ch.isalnum() else "_" for ch in value.strip())
    while "__" in text:
        text = text.replace("__", "_")
    return text.strip("_") or "level"



def _decode(data: bytes) -> np.ndarray:
    image = cv2.imdecode(np.frombuffer(data, dtype=np.uint8), cv2.IMREAD_COLOR)
    if image is None:
        raise RuntimeError("No se pudo decodificar LevelView raster.")
    return image



def _source_wall(wall) -> _SourceWall:
    a = wall.reference_path[0]
    b = wall.reference_path[-1]
    return _SourceWall(
        wall_id=str(wall.id),
        role=str(wall.role),
        start=(float(a.x_px), float(a.y_px)),
        end=(float(b.x_px), float(b.y_px)),
        length_px=float(wall.length_px),
        thickness_px=float(wall.thickness_px) if wall.thickness_px is not None else None,
        confidence=float(wall.confidence) if wall.confidence is not None else None,
        evidence_ids=tuple(sorted(str(item) for item in wall.evidence_ids)),
        source_candidate_id=(
            str(wall.source_candidate_id) if wall.source_candidate_id is not None else None
        ),
    )



def _physical_as_source(item: _PhysicalWall) -> _SourceWall:
    return _SourceWall(
        wall_id=item.wall_id,
        role="PERIMETER_CANDIDATE",
        start=item.start,
        end=item.end,
        length_px=item.length_px,
        thickness_px=item.thickness_px,
        confidence=item.confidence,
        evidence_ids=item.evidence_ids,
        source_candidate_id=None,
    )



def _vector(segment: _SourceWall | _PhysicalWall | _PerimeterTrack) -> tuple[float, float, float]:
    dx = float(segment.end[0] - segment.start[0])
    dy = float(segment.end[1] - segment.start[1])
    length = max(math.hypot(dx, dy), 1e-9)
    ux, uy = dx / length, dy / length
    if ux < -1e-9 or (abs(ux) <= 1e-9 and uy < 0.0):
        ux, uy = -ux, -uy
    return ux, uy, length



def _midpoint(segment: _SourceWall | _PhysicalWall | _PerimeterTrack) -> tuple[float, float]:
    return (
        (segment.start[0] + segment.end[0]) * 0.5,
        (segment.start[1] + segment.end[1]) * 0.5,
    )



def _angle_diff_deg(
    first: _SourceWall | _PhysicalWall | _PerimeterTrack,
    second: _SourceWall | _PhysicalWall | _PerimeterTrack,
) -> float:
    ux1, uy1, _ = _vector(first)
    ux2, uy2, _ = _vector(second)
    dot = max(-1.0, min(1.0, abs(ux1 * ux2 + uy1 * uy2)))
    return math.degrees(math.acos(dot))



def _interval_on_axis(
    segment: _SourceWall | _PhysicalWall | _PerimeterTrack,
    ux: float,
    uy: float,
) -> tuple[float, float]:
    values = (
        segment.start[0] * ux + segment.start[1] * uy,
        segment.end[0] * ux + segment.end[1] * uy,
    )
    return min(values), max(values)



def _normal_offset(segment: _SourceWall | _PhysicalWall | _PerimeterTrack, ux: float, uy: float) -> float:
    nx, ny = -uy, ux
    mx, my = _midpoint(segment)
    return mx * nx + my * ny



def _pair_geometry(first: _SourceWall, second: _SourceWall) -> dict[str, float]:
    ux, uy, _ = _vector(first)
    a0, a1 = _interval_on_axis(first, ux, uy)
    b0, b1 = _interval_on_axis(second, ux, uy)
    overlap = max(0.0, min(a1, b1) - max(a0, b0))
    min_len = max(1e-9, min(a1 - a0, b1 - b0))
    if a1 < b0:
        gap = b0 - a1
    elif b1 < a0:
        gap = a0 - b1
    else:
        gap = 0.0
    lateral = abs(_normal_offset(first, ux, uy) - _normal_offset(second, ux, uy))
    return {
        "angle_deg": _angle_diff_deg(first, second),
        "overlap_px": overlap,
        "overlap_ratio": overlap / min_len,
        "gap_px": gap,
        "lateral_px": lateral,
    }



def _median_thickness_px(walls: Iterable[_SourceWall | _PhysicalWall], fallback_px: float) -> float:
    values = [float(item.thickness_px) for item in walls if item.thickness_px and item.thickness_px > 0]
    return float(median(values)) if values else float(fallback_px)



def _can_share_physical_wall(
    first: _SourceWall,
    second: _SourceWall,
    *,
    px_per_m: float,
) -> bool:
    geometry = _pair_geometry(first, second)
    if geometry["angle_deg"] > 4.0:
        return False

    pair_thickness = _median_thickness_px((first, second), fallback_px=0.12 * px_per_m)
    lateral_limit = max(3.0, min(0.22 * px_per_m, 1.10 * pair_thickness))
    if geometry["lateral_px"] > lateral_limit:
        return False

    micro_gap_limit = max(3.0, 0.12 * px_per_m)
    return geometry["overlap_ratio"] >= 0.18 or geometry["gap_px"] <= micro_gap_limit



def _weighted_axial_direction(items: list[_SourceWall]) -> tuple[float, float]:
    reference = max(items, key=lambda item: item.length_px)
    rux, ruy, _ = _vector(reference)
    sx = 0.0
    sy = 0.0
    for item in items:
        ux, uy, _ = _vector(item)
        if ux * rux + uy * ruy < 0.0:
            ux, uy = -ux, -uy
        weight = max(item.length_px, 1.0)
        sx += ux * weight
        sy += uy * weight
    norm = max(math.hypot(sx, sy), 1e-9)
    return sx / norm, sy / norm



def _weighted_median(values: list[tuple[float, float]]) -> float:
    ordered = sorted(values, key=lambda item: item[0])
    total = sum(max(weight, 0.0) for _, weight in ordered)
    if total <= 1e-9:
        return float(median(value for value, _ in ordered))
    threshold = total * 0.5
    acc = 0.0
    for value, weight in ordered:
        acc += max(weight, 0.0)
        if acc >= threshold:
            return float(value)
    return float(ordered[-1][0])



def _build_physical_wall(index: int, items: list[_SourceWall]) -> _PhysicalWall:
    assert items
    if len(items) == 1:
        item = items[0]
        return _PhysicalWall(
            wall_id=f"PW_{index:03d}",
            start=item.start,
            end=item.end,
            length_px=item.length_px,
            thickness_px=item.thickness_px,
            confidence=item.confidence,
            source_wall_ids=(item.wall_id,),
            source_roles=(item.role,),
            evidence_ids=item.evidence_ids,
            lateral_spread_px=0.0,
        )

    ux, uy = _weighted_axial_direction(items)
    nx, ny = -uy, ux

    offsets: list[tuple[float, float]] = []
    t_values: list[float] = []
    for item in items:
        weight = max(item.length_px, 1.0)
        mx, my = _midpoint(item)
        offsets.append((mx * nx + my * ny, weight))
        for point in (item.start, item.end):
            t_values.append(point[0] * ux + point[1] * uy)

    offset = _weighted_median(offsets)
    t0 = min(t_values)
    t1 = max(t_values)
    start = (ux * t0 + nx * offset, uy * t0 + ny * offset)
    end = (ux * t1 + nx * offset, uy * t1 + ny * offset)
    length = math.hypot(end[0] - start[0], end[1] - start[1])

    thickness_values = [item.thickness_px for item in items if item.thickness_px is not None]
    thickness = float(median(thickness_values)) if thickness_values else None
    confidence_values = [item.confidence for item in items if item.confidence is not None]
    confidence = (
        sum(float(item.confidence) * item.length_px for item in items if item.confidence is not None)
        / max(sum(item.length_px for item in items if item.confidence is not None), 1e-9)
        if confidence_values
        else None
    )
    spread = max(abs(value - offset) for value, _ in offsets)

    return _PhysicalWall(
        wall_id=f"PW_{index:03d}",
        start=start,
        end=end,
        length_px=length,
        thickness_px=thickness,
        confidence=confidence,
        source_wall_ids=tuple(sorted(item.wall_id for item in items)),
        source_roles=tuple(sorted({item.role for item in items})),
        evidence_ids=tuple(sorted({eid for item in items for eid in item.evidence_ids})),
        lateral_spread_px=float(spread),
    )



def _canonicalize_physical_walls(
    source: list[_SourceWall],
    *,
    px_per_m: float,
) -> list[_PhysicalWall]:
    parent = list(range(len(source)))

    def find(i: int) -> int:
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    def union(a: int, b: int) -> None:
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra

    for i in range(len(source)):
        for j in range(i + 1, len(source)):
            if _can_share_physical_wall(source[i], source[j], px_per_m=px_per_m):
                union(i, j)

    grouped: dict[int, list[_SourceWall]] = {}
    for i, wall in enumerate(source):
        grouped.setdefault(find(i), []).append(wall)

    refined: list[list[_SourceWall]] = []
    for group in grouped.values():
        if len(group) <= 1:
            refined.append(group)
            continue
        ux, uy = _weighted_axial_direction(group)
        values = sorted(
            ((_normal_offset(item, ux, uy), item) for item in group),
            key=lambda pair: pair[0],
        )
        thickness = _median_thickness_px(group, fallback_px=0.12 * px_per_m)
        split_gap = max(0.08 * px_per_m, 1.35 * thickness)
        current: list[_SourceWall] = [values[0][1]]
        prev = values[0][0]
        for offset, item in values[1:]:
            if abs(offset - prev) > split_gap:
                refined.append(current)
                current = [item]
            else:
                current.append(item)
            prev = offset
        refined.append(current)

    physical = [_build_physical_wall(index, group) for index, group in enumerate(refined, 1)]
    physical.sort(key=lambda item: (round(item.start[1], 3), round(item.start[0], 3), item.wall_id))
    return physical



def _draw_segment(image, start, end, color, thickness):
    cv2.line(
        image,
        (int(round(start[0])), int(round(start[1]))),
        (int(round(end[0])), int(round(end[1]))),
        color,
        thickness,
        cv2.LINE_AA,
    )



def _wall_draw_thickness(item: _PhysicalWall | _PerimeterTrack, px_per_m: float) -> int:
    thickness = item.thickness_px if item.thickness_px and item.thickness_px > 0 else 0.12 * px_per_m
    return max(2, int(round(thickness)))



def _build_masks(
    *,
    walls: list[_PhysicalWall],
    shape: tuple[int, int],
    px_per_m: float,
) -> _MaskBundle:
    height, width = shape
    wall_mask = np.zeros((height, width), dtype=np.uint8)
    for item in walls:
        _draw_segment(
            wall_mask,
            item.start,
            item.end,
            255,
            _wall_draw_thickness(item, px_per_m),
        )

    close_kernel = max(3, int(round(0.10 * px_per_m)))
    if close_kernel % 2 == 0:
        close_kernel += 1
    kernel = np.ones((close_kernel, close_kernel), dtype=np.uint8)
    closed = cv2.morphologyEx(wall_mask, cv2.MORPH_CLOSE, kernel, iterations=1)

    bridge_kernel = np.ones((3, 3), dtype=np.uint8)
    closed = cv2.dilate(closed, bridge_kernel, iterations=1)

    flood = closed.copy()
    flood_mask = np.zeros((height + 2, width + 2), dtype=np.uint8)
    cv2.floodFill(flood, flood_mask, (0, 0), 128)
    footprint = np.where(flood == 128, 0, 255).astype(np.uint8)

    num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(footprint, connectivity=8)
    if num_labels > 1:
        best_label = max(range(1, num_labels), key=lambda idx: int(stats[idx, cv2.CC_STAT_AREA]))
        footprint = np.where(labels == best_label, 255, 0).astype(np.uint8)

    return _MaskBundle(wall_mask=wall_mask, closed_mask=closed, footprint_mask=footprint)



def _inside(mask: np.ndarray, point: tuple[float, float]) -> bool:
    x = int(round(point[0]))
    y = int(round(point[1]))
    if x < 0 or y < 0 or y >= mask.shape[0] or x >= mask.shape[1]:
        return False
    return bool(mask[y, x] > 0)



def _sample_votes(
    *,
    wall: _PhysicalWall,
    footprint_mask: np.ndarray,
    px_per_m: float,
) -> tuple[str | None, dict[str, int]]:
    ux, uy, length = _vector(wall)
    nx, ny = -uy, ux
    half_thickness = max((wall.thickness_px or 0.12 * px_per_m) * 0.5, 1.0)
    sample_offset = half_thickness + max(2.0, 0.05 * px_per_m)
    sample_ts = (0.15, 0.30, 0.50, 0.70, 0.85) if length >= 12.0 else (0.50,)

    votes = {"LEFT_INSIDE": 0, "RIGHT_INSIDE": 0, "BOTH_INSIDE": 0, "BOTH_OUTSIDE": 0}
    for t in sample_ts:
        cx = wall.start[0] + (wall.end[0] - wall.start[0]) * t
        cy = wall.start[1] + (wall.end[1] - wall.start[1]) * t
        left = (cx + nx * sample_offset, cy + ny * sample_offset)
        right = (cx - nx * sample_offset, cy - ny * sample_offset)
        left_inside = _inside(footprint_mask, left)
        right_inside = _inside(footprint_mask, right)
        if left_inside and not right_inside:
            votes["LEFT_INSIDE"] += 1
        elif right_inside and not left_inside:
            votes["RIGHT_INSIDE"] += 1
        elif left_inside and right_inside:
            votes["BOTH_INSIDE"] += 1
        else:
            votes["BOTH_OUTSIDE"] += 1

    dominant = max(("LEFT_INSIDE", "RIGHT_INSIDE"), key=lambda key: votes[key])
    dominant_votes = votes[dominant]
    total = len(sample_ts)
    if dominant_votes >= max(1, math.ceil(total * 0.60)) and votes["BOTH_OUTSIDE"] <= 1:
        return dominant, votes
    return None, votes



def _infer_perimeter_tracks(
    *,
    physical: list[_PhysicalWall],
    footprint_mask: np.ndarray,
    px_per_m: float,
) -> list[_PerimeterTrack]:
    selected: list[_PerimeterTrack] = []
    for item in physical:
        dominant_side, votes = _sample_votes(wall=item, footprint_mask=footprint_mask, px_per_m=px_per_m)
        if dominant_side is None:
            continue
        selected.append(
            _PerimeterTrack(
                wall_id=f"PT_{len(selected)+1:03d}",
                start=item.start,
                end=item.end,
                length_px=item.length_px,
                thickness_px=item.thickness_px,
                confidence=item.confidence,
                source_wall_ids=item.source_wall_ids,
                source_roles=item.source_roles,
                evidence_ids=item.evidence_ids,
                dominant_side=dominant_side,
                side_votes=votes,
            )
        )

    if not selected:
        return []

    merged = _canonicalize_physical_walls([_physical_as_source(_PhysicalWall(
        wall_id=item.wall_id,
        start=item.start,
        end=item.end,
        length_px=item.length_px,
        thickness_px=item.thickness_px,
        confidence=item.confidence,
        source_wall_ids=item.source_wall_ids,
        source_roles=item.source_roles,
        evidence_ids=item.evidence_ids,
        lateral_spread_px=0.0,
    )) for item in selected], px_per_m=px_per_m)

    votes_by_source: dict[str, list[tuple[str, dict[str, int]]]] = {}
    for item in selected:
        for source_id in item.source_wall_ids:
            votes_by_source.setdefault(source_id, []).append((item.dominant_side, item.side_votes))

    output: list[_PerimeterTrack] = []
    for index, item in enumerate(merged, 1):
        dominant_counts = {"LEFT_INSIDE": 0, "RIGHT_INSIDE": 0}
        merged_votes = {"LEFT_INSIDE": 0, "RIGHT_INSIDE": 0, "BOTH_INSIDE": 0, "BOTH_OUTSIDE": 0}
        for source_id in item.source_wall_ids:
            for dominant_side, votes in votes_by_source.get(source_id, []):
                if dominant_side in dominant_counts:
                    dominant_counts[dominant_side] += 1
                for key, value in votes.items():
                    merged_votes[key] += int(value)
        dominant_side = max(dominant_counts, key=lambda key: dominant_counts[key])
        output.append(
            _PerimeterTrack(
                wall_id=f"PT_{index:03d}",
                start=item.start,
                end=item.end,
                length_px=item.length_px,
                thickness_px=item.thickness_px,
                confidence=item.confidence,
                source_wall_ids=item.source_wall_ids,
                source_roles=item.source_roles,
                evidence_ids=item.evidence_ids,
                dominant_side=dominant_side,
                side_votes=merged_votes,
            )
        )
    output.sort(key=lambda item: (round(item.start[1], 3), round(item.start[0], 3), item.wall_id))
    return output



def _draw_physical(image, walls: list[_PhysicalWall], px_per_m: float) -> None:
    for wall in walls:
        _draw_segment(image, wall.start, wall.end, (0, 0, 0), _wall_draw_thickness(wall, px_per_m))



def _draw_perimeter(image, walls: list[_PerimeterTrack], px_per_m: float) -> None:
    for wall in walls:
        _draw_segment(image, wall.start, wall.end, (0, 0, 0), max(3, _wall_draw_thickness(wall, px_per_m)))



def _draw_perimeter_overlay(image, walls: list[_PerimeterTrack], px_per_m: float) -> None:
    for wall in walls:
        _draw_segment(image, wall.start, wall.end, (0, 0, 255), max(3, _wall_draw_thickness(wall, px_per_m)))



def _serialize_physical(item: _PhysicalWall) -> dict:
    return {
        "id": item.wall_id,
        "start": [item.start[0], item.start[1]],
        "end": [item.end[0], item.end[1]],
        "length_px": item.length_px,
        "thickness_px": item.thickness_px,
        "confidence": item.confidence,
        "source_wall_ids": list(item.source_wall_ids),
        "source_roles": list(item.source_roles),
        "evidence_ids": list(item.evidence_ids),
        "source_wall_count": len(item.source_wall_ids),
        "lateral_spread_px": item.lateral_spread_px,
    }



def _serialize_perimeter(item: _PerimeterTrack) -> dict:
    return {
        "id": item.wall_id,
        "start": [item.start[0], item.start[1]],
        "end": [item.end[0], item.end[1]],
        "length_px": item.length_px,
        "thickness_px": item.thickness_px,
        "confidence": item.confidence,
        "source_wall_ids": list(item.source_wall_ids),
        "source_roles": list(item.source_roles),
        "evidence_ids": list(item.evidence_ids),
        "source_wall_count": len(item.source_wall_ids),
        "dominant_side": item.dominant_side,
        "side_votes": item.side_votes,
    }



def _run_level(*, pipeline, loaded, output_dir: Path, case_id: str, scale_profile) -> dict:
    level_result = loaded.level_result
    perimeter = level_result.perimeter.editable_perimeter
    assert perimeter is not None

    spatial = pipeline.run(
        level_view=level_result.level_view,
        perimeter=perimeter,
        evidence=list(level_result.evidence.evidence),
        scale_profile=scale_profile,
    )
    level = spatial.parametric_model.levels[0]
    before_snapshot = [wall.model_dump(mode="json") for wall in level.walls]

    px_per_m = 1.0 / float(scale_profile.local_m_per_px)
    source = [_source_wall(item) for item in level.walls]
    physical = _canonicalize_physical_walls(source, px_per_m=px_per_m)

    after_snapshot = [wall.model_dump(mode="json") for wall in level.walls]
    assert after_snapshot == before_snapshot, "El probe aislado modificó muros Spatial."

    raster = _decode(level_result.level_view.raster_bytes)
    masks = _build_masks(walls=physical, shape=raster.shape[:2], px_per_m=px_per_m)
    inferred = _infer_perimeter_tracks(
        physical=physical,
        footprint_mask=masks.footprint_mask,
        px_per_m=px_per_m,
    )

    source_perimeter = [item for item in source if item.role == "PERIMETER"]
    source_dividers = [item for item in source if item.role == "DIVIDER"]

    assert physical, "No se generaron WallTracks físicos."
    assert inferred, "No se infirieron tracks perimetrales."

    white = np.full_like(raster, 255)
    faded = cv2.addWeighted(raster, 0.15, np.full_like(raster, 255), 0.85, 0.0)

    all_tracks = white.copy()
    perimeter_clean = white.copy()
    overlay = faded.copy()
    footprint_visual = cv2.cvtColor(masks.footprint_mask, cv2.COLOR_GRAY2BGR)

    _draw_physical(all_tracks, physical, px_per_m)
    _draw_perimeter(perimeter_clean, inferred, px_per_m)
    _draw_perimeter_overlay(overlay, inferred, px_per_m)

    safe = _safe(loaded.level_name)
    tracks_path = output_dir / f"{case_id}__{safe}__all_physical_wall_tracks.png"
    footprint_path = output_dir / f"{case_id}__{safe}__building_footprint_mask.png"
    clean_path = output_dir / f"{case_id}__{safe}__perimeter_clean.png"
    overlay_path = output_dir / f"{case_id}__{safe}__perimeter_overlay.png"
    wall_mask_path = output_dir / f"{case_id}__{safe}__wall_mask.png"
    closed_mask_path = output_dir / f"{case_id}__{safe}__closed_wall_mask.png"

    cv2.imwrite(str(tracks_path), all_tracks)
    cv2.imwrite(str(footprint_path), footprint_visual)
    cv2.imwrite(str(clean_path), perimeter_clean)
    cv2.imwrite(str(overlay_path), overlay)
    cv2.imwrite(str(wall_mask_path), masks.wall_mask)
    cv2.imwrite(str(closed_mask_path), masks.closed_mask)

    inferred_length_px = sum(item.length_px for item in inferred)
    source_length_px = sum(item.length_px for item in source_perimeter)

    return {
        "level": loaded.level_name,
        "level_view_id": level_result.level_view.id,
        "scale_profile": scale_profile.model_dump(mode="json"),
        "px_per_m": px_per_m,
        "source_wall_count": len(source),
        "source_perimeter_count": len(source_perimeter),
        "source_divider_count": len(source_dividers),
        "physical_wall_count": len(physical),
        "inferred_perimeter_count": len(inferred),
        "source_perimeter_length_px": source_length_px,
        "inferred_perimeter_length_px": inferred_length_px,
        "physical_walls": [_serialize_physical(item) for item in physical],
        "inferred_perimeter": [_serialize_perimeter(item) for item in inferred],
        "all_tracks_visual": str(tracks_path),
        "footprint_visual": str(footprint_path),
        "perimeter_clean_visual": str(clean_path),
        "perimeter_overlay_visual": str(overlay_path),
        "wall_mask_visual": str(wall_mask_path),
        "closed_mask_visual": str(closed_mask_path),
    }



def _run_case(case: LoadedCase) -> None:
    output_dir = OUTPUT_ROOT / case.case_id
    if output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    pipeline = ProposalCReconstructionPipeline()
    scale_inputs = []
    for loaded in case.levels:
        perimeter = loaded.level_result.perimeter.editable_perimeter
        assert perimeter is not None
        scale_inputs.append((loaded.level_result.level_view, perimeter))

    project_scale = pipeline.build_project_scale_context(levels=scale_inputs)
    assert project_scale.state == "RESOLVED"

    report = {
        "probe_version": PROBE_VERSION,
        "baseline": BASELINE,
        "case_id": case.case_id,
        "case": case.case_name,
        "gemini_calls_added": 0,
        "engine_files_modified": 0,
        "perimeter_strategy": "PHYSICAL_WALL_TRACKS_PLUS_FILLED_FOOTPRINT",
        "visual_contract": {
            "main_validation_image": "perimeter_clean.png",
            "style": "WHITE_BACKGROUND_BLACK_LINES",
        },
        "project_scale": project_scale.model_dump(mode="json"),
        "levels": [],
        "failures": [],
    }

    for loaded in case.levels:
        profile = project_scale.for_level(loaded.level_result.level_view.id)
        assert profile.local_m_per_px is not None
        px_per_m = 1.0 / profile.local_m_per_px
        relative_error = abs(px_per_m - TARGET_PX_PER_M) / TARGET_PX_PER_M
        if profile.state != "RESOLVED" or relative_error > TARGET_RELATIVE_TOLERANCE:
            report["failures"].append(
                f"{loaded.level_name}:SCALE_GUARD:{profile.state}:{px_per_m:.6f}"
            )
            continue

        level_report = _run_level(
            pipeline=pipeline,
            loaded=loaded,
            output_dir=output_dir,
            case_id=case.case_id,
            scale_profile=profile,
        )
        report["levels"].append(level_report)
        print("\n" + "=" * 100)
        print(f"PERIMETER WALL TRACKS V1 — {case.case_name} — {loaded.level_name}")
        print({
            "source_walls": level_report["source_wall_count"],
            "physical_walls": level_report["physical_wall_count"],
            "source_perimeter": level_report["source_perimeter_count"],
            "inferred_perimeter": level_report["inferred_perimeter_count"],
            "source_perimeter_length_px": round(level_report["source_perimeter_length_px"], 2),
            "inferred_perimeter_length_px": round(level_report["inferred_perimeter_length_px"], 2),
        })

    report["passed"] = not report["failures"]
    json_path = output_dir / f"{case.case_id}__perimeter_wall_tracks_v1.json"
    json_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\nJSON: {json_path}")
    assert not report["failures"], json.dumps(report["failures"], ensure_ascii=False)


@pytest.mark.parametrize("case_id", CASE_IDS)
def test_quantia_spatial_perimeter_wall_tracks_all_3_v1(case_id: str) -> None:
    _run_case(CASE_LOADERS[case_id]())


if __name__ == "__main__":
    for _case_id in CASE_IDS:
        _run_case(CASE_LOADERS[_case_id]())
