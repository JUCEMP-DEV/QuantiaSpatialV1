from __future__ import annotations

import base64
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import pytest
import requests
import time

from app.quantia_spatialV1.providers.vision import GeminiSpatialVisionProvider
from app.quantia_spatialV1.tests.quantia_case_loader import CASE_LOADERS


PROBE_VERSION = "WALL_CONSOLIDATION_SECOND_CALL_MIGUEL_V_PB_V5_RETRY_FALLBACK"
BASELINE = "WALL_CANONICALIZATION_ISOLATED_ALL_3_V1"
CASE_ID = "miguel_v"
MAX_ATTEMPTS_PER_MODEL = 3
DEFAULT_RETRY_DELAYS_SECONDS = (1.0, 2.0)
LEVEL_NAME = "Planta Baja"

TESTS_DIR = Path(__file__).resolve().parent
CANONICAL_ROOT = TESTS_DIR / "output" / "wall_canonicalization_isolated_v1" / CASE_ID
CANONICAL_JSON = CANONICAL_ROOT / "miguel_v__wall_canonicalization_isolated_v1.json"
OUTPUT_ROOT = TESTS_DIR / "output" / "wall_consolidation_second_call_miguel_v_pb_v5_retry_fallback"

# Esta prueba NO modifica Spatial, F02, CandidateGraph, GlobalTopologySolver,
# Architectural Elements Mini-Engine ni el resultado de canonicalización.
# Consume el WallGraph canónico V1 + el raster ORIGINAL del mismo LevelView y realiza
# realiza UNA llamada lógica de consolidación. Intenta el modelo primario una vez y,
# solo ante fallo transitorio de transporte/servicio, hace fallback inmediato al modelo
# configurado como fallback. No hay retry sobre el mismo modelo.


RESPONSE_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "level_view_id": {"type": "string"},
        "wall_graph_state": {
            "type": "string",
            "enum": ["CLOSED", "PARTIAL", "REVIEW"],
        },
        "missing_walls": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "start_px": {
                        "type": "array",
                        "items": {"type": "number"},
                        "minItems": 2,
                        "maxItems": 2,
                    },
                    "end_px": {
                        "type": "array",
                        "items": {"type": "number"},
                        "minItems": 2,
                        "maxItems": 2,
                    },
                    "supporting_wall_ids": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                    "confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0},
                    "reason": {"type": "string"},
                },
                "required": [
                    "start_px",
                    "end_px",
                    "supporting_wall_ids",
                    "confidence",
                    "reason",
                ],
            },
        },
        "wall_extensions": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "wall_id": {"type": "string"},
                    "endpoint": {"type": "string", "enum": ["START", "END"]},
                    "new_point_px": {
                        "type": "array",
                        "items": {"type": "number"},
                        "minItems": 2,
                        "maxItems": 2,
                    },
                    "confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0},
                    "reason": {"type": "string"},
                },
                "required": [
                    "wall_id",
                    "endpoint",
                    "new_point_px",
                    "confidence",
                    "reason",
                ],
            },
        },
        "false_walls": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "wall_id": {"type": "string"},
                    "confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0},
                    "reason": {"type": "string"},
                },
                "required": ["wall_id", "confidence", "reason"],
            },
        },
        "gap_decisions": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "gap_id": {"type": "string"},
                    "classification": {
                        "type": "string",
                        "enum": [
                            "WALL_CONTINUITY",
                            "PROBABLE_OPENING",
                            "UNCERTAIN",
                            "NOT_A_GAP",
                        ],
                    },
                    "logical_wall_continuity": {"type": "boolean"},
                    "confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0},
                    "reason": {"type": "string"},
                },
                "required": [
                    "gap_id",
                    "classification",
                    "logical_wall_continuity",
                    "confidence",
                    "reason",
                ],
            },
        },
        "unresolved_regions": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "bbox_px": {
                        "type": "array",
                        "items": {"type": "number"},
                        "minItems": 4,
                        "maxItems": 4,
                    },
                    "confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0},
                    "reason": {"type": "string"},
                },
                "required": ["bbox_px", "confidence", "reason"],
            },
        },
        "summary": {"type": "string"},
    },
    "required": [
        "level_view_id",
        "wall_graph_state",
        "missing_walls",
        "wall_extensions",
        "false_walls",
        "gap_decisions",
        "unresolved_regions",
        "summary",
    ],
}


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _sha256_json(data: Any) -> str:
    payload = json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return _sha256_bytes(payload)


def _load_level() -> tuple[dict[str, Any], dict[str, Any]]:
    assert CANONICAL_JSON.exists(), (
        "No existe el resultado de Wall Canonicalization V1. Ejecuta primero: "
        "test_quantia_spatial_wall_canonicalization_isolated_all_3_v1.py"
    )
    report = json.loads(CANONICAL_JSON.read_text(encoding="utf-8"))
    for level in report.get("levels", []):
        if str(level.get("level", "")).strip().casefold() == LEVEL_NAME.casefold():
            return report, level
    raise AssertionError(f"No se encontró {LEVEL_NAME!r} en {CANONICAL_JSON}.")


def _load_original_level_view():
    """
    Recupera el MISMO LevelView original usado por el flujo estandarizado de Miguel V.

    CASE_LOADERS usa los replays existentes; este probe no añade una llamada Gemini
    para reconstruir el LevelView. La llamada real de este test sigue siendo CALL 2.
    """
    case = CASE_LOADERS[CASE_ID]()
    for loaded in case.levels:
        if str(loaded.level_name).strip().casefold() == LEVEL_NAME.casefold():
            return loaded.level_result.level_view
    raise AssertionError(f"No se encontró {LEVEL_NAME!r} en CASE_LOADERS[{CASE_ID!r}].")


def _decode_bytes(data: bytes) -> np.ndarray:
    image = cv2.imdecode(np.frombuffer(data, dtype=np.uint8), cv2.IMREAD_COLOR)
    assert image is not None, "No se pudo decodificar el raster original del LevelView."
    return image


def _decode_image(path: Path) -> np.ndarray:
    data = path.read_bytes()
    image = cv2.imdecode(np.frombuffer(data, dtype=np.uint8), cv2.IMREAD_COLOR)
    assert image is not None, f"No se pudo decodificar {path}."
    return image


def _state_capsule(level: dict[str, Any], *, width: int, height: int) -> dict[str, Any]:
    walls = []
    for item in level.get("canonical_walls", []):
        length_px = float(item["length_px"])
        px_per_m = float(level["px_per_m"])
        walls.append(
            {
                "id": str(item["id"]),
                "role": str(item["role"]),
                "start_px": [round(float(item["start"][0]), 2), round(float(item["start"][1]), 2)],
                "end_px": [round(float(item["end"][0]), 2), round(float(item["end"][1]), 2)],
                "length_m": round(length_px / px_per_m, 3),
                "source_wall_count": int(item.get("source_wall_count", 1)),
            }
        )

    gaps = []
    for index, item in enumerate(level.get("gap_candidates", []), start=1):
        gaps.append(
            {
                "id": f"G{index:03d}",
                "between": [str(item["first_wall_id"]), str(item["second_wall_id"])],
                "start_px": [round(float(item["start"][0]), 2), round(float(item["start"][1]), 2)],
                "end_px": [round(float(item["end"][0]), 2), round(float(item["end"][1]), 2)],
                "gap_m": round(float(item["gap_m"]), 3) if item.get("gap_m") is not None else None,
            }
        )

    return {
        "level_view_id": str(level["level_view_id"]),
        "level_name": LEVEL_NAME,
        "image_size_px": [width, height],
        "coordinate_system": "origin top-left; x right; y down; coordinates are LevelView pixels",
        "px_per_m": round(float(level["px_per_m"]), 6),
        "canonical_wall_count": len(walls),
        "canonical_walls": walls,
        "gap_candidate_count": len(gaps),
        "gap_candidates": gaps,
    }


def _build_prompt(capsule: dict[str, Any]) -> str:
    capsule_json = json.dumps(capsule, ensure_ascii=False, separators=(",", ":"))
    return f"""
Eres la SEGUNDA LLAMADA de consolidación geométrica de Quantia Spatial.
No eres un extractor inicial y NO debes reconstruir el plano desde cero.

ENTRADA VISUAL
La imagen adjunta ES EL RASTER ORIGINAL COMPLETO DEL LEVELVIEW, sin atenuación y sin líneas de Quantia dibujadas encima.
Debes usarla como fuente visual primaria para comprobar qué existe realmente en el plano.

El STATE CAPSULE contiene, por separado, las centerlines canónicas que Quantia ya reconstruyó y los gap_candidates actuales.
No asumas que un muro ausente del STATE CAPSULE está ausente del plano: compara activamente el plano original contra el WallGraph actual.
El perímetro publicado por F02 es inmutable.

OBJETIVO
Usando simultáneamente EL PLANO ORIGINAL y el STATE CAPSULE:
1. Conserva como implícitos los muros canónicos correctos; NO los repitas en la salida.
2. Busca ACTIVAMENTE en el plano original tramos de muro que Quantia no haya reconstruido todavía, aunque no existan como candidatos actuales.
   Si hay evidencia visual suficiente, publícalos en missing_walls.
3. Detecta extensiones necesarias de muros DIVIDER existentes para cerrar junctions o espacios.
4. Señala muros DIVIDER claramente falsos. Nunca elimines ni modifiques muros PERIMETER.
5. Decide TODOS los gap_candidates recibidos:
   - WALL_CONTINUITY: falta cerrar geométricamente un tramo de muro.
   - PROBABLE_OPENING: existe continuidad lógica del muro pero debe permanecer un vano para la tercera llamada.
   - UNCERTAIN: la evidencia no permite decidir con certeza.
   - NOT_A_GAP: el candidato no representa un problema real.
6. Puedes usar arcos de puerta, ventanas, textos y otros símbolos visibles como EVIDENCIA para comprender la continuidad del muro,
   pero NO clasifiques todavía PROBABLE_OPENING como puerta o ventana. Esa responsabilidad pertenece a una tercera llamada.
7. Un PROBABLE_OPENING puede cerrar topológicamente un espacio sin dibujar un muro sólido sobre el vano.
8. No inventes muros por simetría, estilo o expectativa arquitectónica. Si no existe evidencia suficiente, usa unresolved_regions o UNCERTAIN.
9. Las coordenadas que propongas deben estar dentro de image_size_px y usar exactamente el sistema de coordenadas del STATE CAPSULE.
10. Devuelve únicamente DELTAS/correcciones. No vuelvas a enumerar los muros existentes.

STATE CAPSULE
{capsule_json}
""".strip()


def _extract_text(raw: dict[str, Any]) -> str:
    candidates = raw.get("candidates")
    if not isinstance(candidates, list) or not candidates:
        return ""
    content = candidates[0].get("content") if isinstance(candidates[0], dict) else None
    parts = content.get("parts") if isinstance(content, dict) else None
    if not isinstance(parts, list):
        return ""
    chunks = [part.get("text") for part in parts if isinstance(part, dict) and isinstance(part.get("text"), str)]
    return "".join(chunks).strip()


def _gemini_call_with_fallback(
    *,
    prompt: str,
    image_bytes: bytes,
    image_mime_type: str,
) -> tuple[dict[str, Any], str, str, int, list[dict[str, Any]], bool]:
    """
    Una sola operación semántica de consolidación.

    Transporte V5:
      - Hasta 3 POST por modelo SOLO ante error transitorio:
        408/429/500/502/503/504 o RequestException.
      - Respeta Retry-After cuando el servidor lo envía.
      - Si no existe Retry-After: backoff 1 s, 2 s.
      - Agotado el primario, pasa al fallback.
      - Un 400/422 u otro error no transitorio falla inmediatamente.
      - No fija maxOutputTokens/temperature/topP/topK.
      - Cada POST queda registrado en attempts.
    """
    provider = GeminiSpatialVisionProvider()
    assert provider.api_key, "GEMINI_API_KEY no está configurada."
    assert provider.primary_model, "gemini_primary_model no está configurado."
    assert provider.fallback_model, "gemini_fallback_model no está configurado."

    prepared_schema = provider._prepare_schema_for_gemini(RESPONSE_SCHEMA)
    payload = {
        "contents": [
            {
                "role": "user",
                "parts": [
                    {"text": prompt},
                    {
                        "inlineData": {
                            "mimeType": image_mime_type,
                            "data": base64.b64encode(image_bytes).decode("utf-8"),
                        }
                    },
                ],
            }
        ],
        "generationConfig": {
            "responseMimeType": "application/json",
            "responseJsonSchema": prepared_schema,
        },
    }

    models: list[str] = []
    for candidate in (provider.primary_model, provider.fallback_model):
        normalized = str(candidate).strip()
        if normalized and normalized not in models:
            models.append(normalized)

    assert models, "No existen modelos Gemini configurados para la segunda llamada."

    attempts: list[dict[str, Any]] = []
    transient_status = set(provider.TRANSIENT_HTTP_STATUS)

    def _retry_delay(response: requests.Response | None, retry_index: int) -> float:
        if response is not None:
            retry_after = response.headers.get("Retry-After")
            try:
                if retry_after is not None:
                    return max(0.0, float(retry_after))
            except (TypeError, ValueError):
                pass

        if retry_index <= len(DEFAULT_RETRY_DELAYS_SECONDS):
            return DEFAULT_RETRY_DELAYS_SECONDS[retry_index - 1]
        return float(2 ** max(0, retry_index - 1))

    last_error: str | None = None

    for model_index, model in enumerate(models):
        url = f"{provider.BASE_URL}/{model}:generateContent"

        for per_model_attempt in range(1, MAX_ATTEMPTS_PER_MODEL + 1):
            attempt_started = datetime.now(timezone.utc).isoformat()
            response: requests.Response | None = None

            try:
                response = requests.post(
                    url,
                    headers={
                        "x-goog-api-key": provider.api_key,
                        "Content-Type": "application/json",
                    },
                    json=payload,
                    timeout=180,
                )
            except requests.RequestException as exc:
                record = {
                    "attempt": len(attempts) + 1,
                    "attempt_in_model": per_model_attempt,
                    "timestamp_utc": attempt_started,
                    "model": model,
                    "http_status": None,
                    "ok": False,
                    "transient": True,
                    "transport_error": str(exc),
                }

                last_error = str(exc)

                if per_model_attempt < MAX_ATTEMPTS_PER_MODEL:
                    delay = _retry_delay(None, per_model_attempt)
                    record["retry_scheduled"] = True
                    record["retry_delay_seconds"] = delay
                    attempts.append(record)
                    time.sleep(delay)
                    continue

                record["retry_scheduled"] = False
                record["model_exhausted"] = True
                attempts.append(record)
                break

            raw_http = response.text
            try:
                raw = response.json()
            except ValueError:
                raw = {"non_json_http_body": raw_http}

            status = int(response.status_code)
            is_transient = status in transient_status

            record: dict[str, Any] = {
                "attempt": len(attempts) + 1,
                "attempt_in_model": per_model_attempt,
                "timestamp_utc": attempt_started,
                "model": model,
                "http_status": status,
                "ok": bool(response.ok),
                "transient": bool(is_transient),
            }

            if response.ok:
                text = _extract_text(raw)
                if not text:
                    record["ok"] = False
                    record["empty_text"] = True
                    attempts.append(record)
                    raise AssertionError(
                        f"Gemini respondió HTTP 200 con {model} pero sin contenido textual utilizable."
                    )

                attempts.append(record)
                return (
                    raw,
                    text,
                    model,
                    status,
                    attempts,
                    model_index > 0,
                )

            record["response_excerpt"] = raw_http[:1200]
            last_error = raw_http[:1200]

            if not is_transient:
                record["retry_scheduled"] = False
                attempts.append(record)
                raise AssertionError(
                    f"Gemini falló HTTP {status} con {model}. "
                    f"Error no transitorio; no se reintenta ni se oculta con fallback. "
                    f"Respuesta: {raw_http[:1200]}"
                )

            if per_model_attempt < MAX_ATTEMPTS_PER_MODEL:
                delay = _retry_delay(response, per_model_attempt)
                record["retry_scheduled"] = True
                record["retry_delay_seconds"] = delay
                attempts.append(record)
                time.sleep(delay)
                continue

            record["retry_scheduled"] = False
            record["model_exhausted"] = True
            attempts.append(record)
            break

        # Solo llegamos aquí si el modelo agotó sus intentos transitorios.
        # El for externo pasa al fallback si existe.
        continue

    raise AssertionError(
        "La segunda llamada agotó todos los modelos configurados tras "
        f"{len(attempts)} POST. Último error: {last_error}"
    )

def _point(value: list[Any]) -> tuple[float, float]:
    return float(value[0]), float(value[1])


def _in_bounds(point: tuple[float, float], *, width: int, height: int) -> bool:
    x, y = point
    return 0.0 <= x <= float(width - 1) and 0.0 <= y <= float(height - 1)


def _draw_line(image: np.ndarray, start, end, color, thickness: int = 4) -> None:
    cv2.line(
        image,
        (int(round(start[0])), int(round(start[1]))),
        (int(round(end[0])), int(round(end[1]))),
        color,
        thickness,
        cv2.LINE_AA,
    )


def _render_preview(
    *,
    image: np.ndarray,
    capsule: dict[str, Any],
    result: dict[str, Any],
) -> np.ndarray:
    preview = image.copy()
    wall_index = {item["id"]: item for item in capsule["canonical_walls"]}
    gap_index = {item["id"]: item for item in capsule["gap_candidates"]}

    # Missing walls: green.
    for item in result.get("missing_walls", []):
        _draw_line(preview, _point(item["start_px"]), _point(item["end_px"]), (0, 170, 0), 5)

    # Extensions: blue/cyan from current endpoint to proposed endpoint.
    for item in result.get("wall_extensions", []):
        wall = wall_index.get(item["wall_id"])
        if not wall:
            continue
        anchor_key = "start_px" if item["endpoint"] == "START" else "end_px"
        _draw_line(preview, _point(wall[anchor_key]), _point(item["new_point_px"]), (255, 160, 0), 5)

    # False walls: red over existing canonical line.
    for item in result.get("false_walls", []):
        wall = wall_index.get(item["wall_id"])
        if wall:
            _draw_line(preview, _point(wall["start_px"]), _point(wall["end_px"]), (0, 0, 255), 6)

    # Gap decisions: colored circles/segments; no physical fill for probable opening.
    colors = {
        "WALL_CONTINUITY": (0, 170, 0),
        "PROBABLE_OPENING": (255, 0, 255),
        "UNCERTAIN": (0, 200, 255),
        "NOT_A_GAP": (150, 150, 150),
    }
    for item in result.get("gap_decisions", []):
        gap = gap_index.get(item["gap_id"])
        if not gap:
            continue
        start = _point(gap["start_px"])
        end = _point(gap["end_px"])
        color = colors.get(item["classification"], (0, 200, 255))
        if item["classification"] == "WALL_CONTINUITY":
            _draw_line(preview, start, end, color, 4)
        else:
            cx = int(round((start[0] + end[0]) * 0.5))
            cy = int(round((start[1] + end[1]) * 0.5))
            cv2.circle(preview, (cx, cy), 9, color, 3, cv2.LINE_AA)

    # Unresolved regions: yellow rectangle.
    for item in result.get("unresolved_regions", []):
        x0, y0, x1, y1 = [int(round(float(v))) for v in item["bbox_px"]]
        cv2.rectangle(preview, (x0, y0), (x1, y1), (0, 200, 255), 3, cv2.LINE_AA)

    return preview


def _validate_contract(
    *,
    capsule: dict[str, Any],
    result: dict[str, Any],
    width: int,
    height: int,
) -> list[str]:
    failures: list[str] = []
    wall_index = {item["id"]: item for item in capsule["canonical_walls"]}
    expected_gap_ids = [item["id"] for item in capsule["gap_candidates"]]
    returned_gap_ids = [str(item.get("gap_id", "")) for item in result.get("gap_decisions", [])]

    if result.get("level_view_id") != capsule["level_view_id"]:
        failures.append("LEVEL_VIEW_ID_MISMATCH")

    if sorted(returned_gap_ids) != sorted(expected_gap_ids):
        failures.append(
            f"GAP_COVERAGE expected={expected_gap_ids} returned={returned_gap_ids}"
        )
    if len(returned_gap_ids) != len(set(returned_gap_ids)):
        failures.append("DUPLICATE_GAP_DECISION")

    for item in result.get("missing_walls", []):
        for key in ("start_px", "end_px"):
            if not _in_bounds(_point(item[key]), width=width, height=height):
                failures.append(f"OUT_OF_BOUNDS_MISSING_WALL:{key}:{item[key]}")
        for wall_id in item.get("supporting_wall_ids", []):
            if wall_id not in wall_index:
                failures.append(f"UNKNOWN_SUPPORTING_WALL:{wall_id}")

    for item in result.get("wall_extensions", []):
        wall = wall_index.get(item.get("wall_id"))
        if wall is None:
            failures.append(f"UNKNOWN_EXTENSION_WALL:{item.get('wall_id')}")
            continue
        if wall["role"] == "PERIMETER":
            failures.append(f"PERIMETER_EXTENSION_FORBIDDEN:{item['wall_id']}")
        if not _in_bounds(_point(item["new_point_px"]), width=width, height=height):
            failures.append(f"OUT_OF_BOUNDS_EXTENSION:{item['wall_id']}:{item['new_point_px']}")

    for item in result.get("false_walls", []):
        wall = wall_index.get(item.get("wall_id"))
        if wall is None:
            failures.append(f"UNKNOWN_FALSE_WALL:{item.get('wall_id')}")
            continue
        if wall["role"] == "PERIMETER":
            failures.append(f"PERIMETER_REMOVAL_FORBIDDEN:{item['wall_id']}")

    for item in result.get("unresolved_regions", []):
        bbox = item.get("bbox_px", [])
        if len(bbox) != 4:
            failures.append(f"INVALID_UNRESOLVED_BBOX:{bbox}")
            continue
        x0, y0, x1, y1 = map(float, bbox)
        if not (0 <= x0 <= x1 < width and 0 <= y0 <= y1 < height):
            failures.append(f"OUT_OF_BOUNDS_UNRESOLVED_BBOX:{bbox}")

    return failures


def test_quantia_spatial_wall_consolidation_second_call_miguel_v_pb_v5_retry_fallback() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    report, level = _load_level()
    original_level_view = _load_original_level_view()

    assert str(original_level_view.id) == str(level["level_view_id"]), (
        "El LevelView original no coincide con el usado por Wall Canonicalization. "
        f"original={original_level_view.id} canonical={level['level_view_id']}"
    )

    image_bytes = bytes(original_level_view.raster_bytes)
    image_mime_type = str(original_level_view.raster_mime_type or "image/png")
    image = _decode_bytes(image_bytes)
    height, width = image.shape[:2]

    # Evidencia verificable de la entrada REAL enviada a Gemini.
    input_original_path = OUTPUT_ROOT / "miguel_v__planta_baja__second_call_input_original_levelview.png"
    cv2.imwrite(str(input_original_path), image)

    capsule = _state_capsule(level, width=width, height=height)
    prompt = _build_prompt(capsule)

    call_started_at = datetime.now(timezone.utc).isoformat()
    raw, text, model, http_status, attempts, fallback_used = _gemini_call_with_fallback(
        prompt=prompt,
        image_bytes=image_bytes,
        image_mime_type=image_mime_type,
    )

    attempts_path = OUTPUT_ROOT / "miguel_v__planta_baja__second_call_transport_attempts.json"
    attempts_path.write_text(
        json.dumps(attempts, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    raw_path = OUTPUT_ROOT / "miguel_v__planta_baja__second_call_raw.json"
    text_path = OUTPUT_ROOT / "miguel_v__planta_baja__second_call_text.txt"
    raw_path.write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding="utf-8")
    text_path.write_text(text, encoding="utf-8")

    try:
        result = json.loads(text)
    except json.JSONDecodeError as exc:
        history = {
            "probe_version": PROBE_VERSION,
            "timestamp_utc": call_started_at,
            "case_id": CASE_ID,
            "level_name": LEVEL_NAME,
            "level_view_id": capsule["level_view_id"],
            "model": model,
            "http_status": http_status,
            "transport_attempts": attempts,
            "logical_calls": 1,
            "http_posts": len(attempts),
            "fallback_used": fallback_used,
            "retry_used": len(attempts) > len({item.get("model") for item in attempts}),
            "generation_budget_policy": "PROVIDER_DEFAULT_NO_MAX_OUTPUT_TOKENS",
        "transport_policy": "3_ATTEMPTS_PER_MODEL_THEN_FALLBACK",
            "prompt_sha256": _sha256_bytes(prompt.encode("utf-8")),
            "schema_sha256": _sha256_json(RESPONSE_SCHEMA),
            "image_sha256": _sha256_bytes(image_bytes),
                "image_mode": "ORIGINAL_LEVELVIEW_RASTER_FULL",
            "raw_response_file": str(raw_path),
            "transport_attempts_file": str(attempts_path),
            "text_response_file": str(text_path),
            "parse_status": "INVALID_JSON",
            "parse_error": str(exc),
            "usage_metadata": raw.get("usageMetadata") if isinstance(raw, dict) else None,
        }
        history_path = OUTPUT_ROOT / "gemini_second_call_history.jsonl"
        with history_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(history, ensure_ascii=False) + "\n")
        raise AssertionError(f"Gemini devolvió JSON inválido: {exc}. RAW persistido en {raw_path}") from exc

    failures = _validate_contract(
        capsule=capsule,
        result=result,
        width=width,
        height=height,
    )

    preview = _render_preview(image=image, capsule=capsule, result=result)
    preview_path = OUTPUT_ROOT / "miguel_v__planta_baja__second_call_consolidation_preview.png"
    cv2.imwrite(str(preview_path), preview)

    result_path = OUTPUT_ROOT / "miguel_v__planta_baja__second_call_result.json"
    result_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")

    audit = {
        "probe_version": PROBE_VERSION,
        "baseline": BASELINE,
        "case_id": CASE_ID,
        "level": LEVEL_NAME,
        "level_view_id": capsule["level_view_id"],
        "engine_files_modified": 0,
        "input_from_existing_canonicalization": True,
        "logical_calls": 1,
        "http_posts": len(attempts),
        "fallback_used": fallback_used,
        "retry_used": len(attempts) > len({item.get("model") for item in attempts}),
        "generation_budget_policy": "PROVIDER_DEFAULT_NO_MAX_OUTPUT_TOKENS",
        "transport_policy": "3_ATTEMPTS_PER_MODEL_THEN_FALLBACK",
        "model": model,
        "transport_attempts": attempts,
        "input_canonical_wall_count": capsule["canonical_wall_count"],
        "input_gap_count": capsule["gap_candidate_count"],
        "wall_graph_state": result.get("wall_graph_state"),
        "missing_wall_count": len(result.get("missing_walls", [])),
        "extension_count": len(result.get("wall_extensions", [])),
        "false_wall_count": len(result.get("false_walls", [])),
        "gap_decision_count": len(result.get("gap_decisions", [])),
        "unresolved_region_count": len(result.get("unresolved_regions", [])),
        "failures": failures,
        "input_visual_mode": "ORIGINAL_LEVELVIEW_RASTER_FULL",
        "input_visual": str(input_original_path),
        "input_visual_mime_type": image_mime_type,
        "input_original_raster_sha256": _sha256_bytes(image_bytes),
        "preview_visual": str(preview_path),
        "result_json": str(result_path),
        "raw_response": str(raw_path),
        "transport_attempts_file": str(attempts_path),
    }
    audit_path = OUTPUT_ROOT / "miguel_v__planta_baja__second_call_audit.json"
    audit_path.write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding="utf-8")

    history = {
        "probe_version": PROBE_VERSION,
        "timestamp_utc": call_started_at,
        "case_id": CASE_ID,
        "level_name": LEVEL_NAME,
        "level_view_id": capsule["level_view_id"],
        "model": model,
        "http_status": http_status,
        "transport_attempts": attempts,
        "logical_calls": 1,
        "http_posts": len(attempts),
        "fallback_used": fallback_used,
        "retry_used": len(attempts) > len({item.get("model") for item in attempts}),
        "generation_budget_policy": "PROVIDER_DEFAULT_NO_MAX_OUTPUT_TOKENS",
        "transport_policy": "3_ATTEMPTS_PER_MODEL_THEN_FALLBACK",
        "prompt_sha256": _sha256_bytes(prompt.encode("utf-8")),
        "schema_sha256": _sha256_json(RESPONSE_SCHEMA),
        "state_capsule_sha256": _sha256_json(capsule),
        "image_sha256": _sha256_bytes(image_bytes),
                "image_mode": "ORIGINAL_LEVELVIEW_RASTER_FULL",
        "raw_response_sha256": _sha256_json(raw),
        "normalized_response_sha256": _sha256_json(result),
        "usage_metadata": raw.get("usageMetadata") if isinstance(raw, dict) else None,
        "parse_status": "VALID_JSON",
        "contract_failures": failures,
        "raw_response_file": str(raw_path),
        "transport_attempts_file": str(attempts_path),
        "normalized_response_file": str(result_path),
        "preview_visual": str(preview_path),
    }
    history_path = OUTPUT_ROOT / "gemini_second_call_history.jsonl"
    with history_path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(history, ensure_ascii=False) + "\n")

    print("\n" + "=" * 100)
    print("WALL CONSOLIDATION SECOND CALL V5 RETRY/FALLBACK — MIGUEL V — PLANTA BAJA")
    print(
        {
            "model": model,
            "http_posts": len(attempts),
            "fallback_used": fallback_used,
            "canonical_walls": capsule["canonical_wall_count"],
            "gap_candidates": capsule["gap_candidate_count"],
            "wall_graph_state": result.get("wall_graph_state"),
            "missing_walls": len(result.get("missing_walls", [])),
            "extensions": len(result.get("wall_extensions", [])),
            "false_walls": len(result.get("false_walls", [])),
            "gap_decisions": len(result.get("gap_decisions", [])),
            "unresolved_regions": len(result.get("unresolved_regions", [])),
            "contract_failures": failures,
        }
    )
    print(f"PREVIEW: {preview_path}")
    print(f"JSON: {result_path}")
    print(f"RAW: {raw_path}")

    assert not failures, json.dumps(failures, ensure_ascii=False)
