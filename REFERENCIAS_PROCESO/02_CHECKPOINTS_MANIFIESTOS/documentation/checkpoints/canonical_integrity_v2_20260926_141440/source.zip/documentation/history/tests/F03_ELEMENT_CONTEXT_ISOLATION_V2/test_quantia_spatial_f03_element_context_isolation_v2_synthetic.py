import math

from shapely.geometry import box

from app.quantia_spatialV1.reconstruction_core.candidate_context_gate import CandidateContextGate
from app.quantia_spatialV1.reconstruction_core.candidate_models import WallCandidate, WallEvidenceVector
from app.quantia_spatialV1.reconstruction_core.context_models import ContextRegion
from app.quantia_spatialV1.reconstruction_core.drawing_model import (
    DrawingBBox,
    DrawingCurve,
    DrawingLine,
    DrawingModel,
    DrawingModelDiagnostics,
    DrawingPoint,
    DrawingText,
)
from app.quantia_spatialV1.reconstruction_core.element_context_detector import ElementContextDetector
from app.quantia_spatialV1.reconstruction_core.level_scale_normalizer import LevelScaleProfile
from app.quantia_spatialV1.reconstruction_core.wall_track_consolidator import WallTrackConsolidator


def _profile():
    return LevelScaleProfile(
        level_view_id="LV",
        state="RESOLVED",
        local_m_per_px=1.0 / 90.0,
        canonical_m_per_px=1.0 / 90.0,
        scale_factor_to_canonical=1.0,
        local_min_dim_px=800.0,
        normalized_min_dim_px=800.0,
        project_reference_min_dim_normalized_px=800.0,
        project_reference_area_normalized_px2=800000.0,
        source="TEST",
        confidence=1.0,
    )


def _line(ident, a, b, *, dashed=False, metadata=None):
    dx = b[0] - a[0]
    dy = b[1] - a[1]
    return DrawingLine(
        id=ident,
        start=DrawingPoint(x=a[0], y=a[1]),
        end=DrawingPoint(x=b[0], y=b[1]),
        length_px=math.hypot(dx, dy),
        angle_deg=math.degrees(math.atan2(dy, dx)) % 180.0,
        dashed=dashed,
        evidence_ids=[ident],
        sources=["PYMUPDF"],
        metadata=dict(metadata or {}),
    )


def _drawing(*, lines=None, curves=None, texts=None):
    return DrawingModel(
        level_view_id="LV",
        width_px=1200,
        height_px=900,
        lines=list(lines or []),
        curves=list(curves or []),
        texts=list(texts or []),
        diagnostics=DrawingModelDiagnostics(
            raw_evidence_count=0,
            normalized_line_count=len(lines or []),
            normalized_region_count=0,
            normalized_curve_count=len(curves or []),
            text_count=len(texts or []),
            semantic_observation_count=0,
            lsd_line_count=0,
            region_centerline_count=0,
            source_counts={},
        ),
    )


def _candidate(ident, a, b, *, face_ids, metric=0.9, metadata=None):
    dx = b[0] - a[0]
    dy = b[1] - a[1]
    payload = {"metric_wall_band_support": metric}
    payload.update(metadata or {})
    return WallCandidate(
        id=ident,
        generator="DOUBLE_FACE",
        start=DrawingPoint(x=a[0], y=a[1]),
        end=DrawingPoint(x=b[0], y=b[1]),
        angle_deg=math.degrees(math.atan2(dy, dx)) % 180.0,
        length_px=math.hypot(dx, dy),
        thickness_px=12.0,
        face_ids=list(face_ids),
        evidence_ids=list(face_ids),
        source_names=["PYMUPDF"],
        evidence=WallEvidenceVector(
            pair_overlap=1.0,
            thickness_support=0.9,
            vector_support=1.0,
            raster_line_support=1.0,
            region_support=0.9,
            source_consensus=0.75,
            perimeter_containment=1.0,
        ),
        prior_score=0.8,
        metadata=payload,
    )


def _door_curve(x=100, y=100, r=90):
    return DrawingCurve(
        id=f"CURVE_{x}_{y}",
        control_points=[
            DrawingPoint(x=x, y=y + r),
            DrawingPoint(x=x, y=y + r * 0.55),
            DrawingPoint(x=x + r * 0.55, y=y),
            DrawingPoint(x=x + r, y=y),
        ],
        bbox=DrawingBBox(x_min=x, y_min=y, x_max=x + r, y_max=y + r),
        evidence_ids=[f"CURVE_{x}_{y}"],
        sources=["PYMUPDF"],
    )


def test_axis_bubble_outside_architecture_is_not_door_even_if_curved():
    curve = _door_curve(x=30, y=30, r=35)  # físicamente demasiado pequeño y fuera.
    lines = [
        _line("FALSE_RADIAL", (30, 65), (30, 32)),
        _line("FALSE_GRID", (0, 30), (180, 30)),
    ]
    regions = ElementContextDetector().detect(
        drawing=_drawing(lines=lines, curves=[curve]),
        scale_profile=_profile(),
        architectural_polygon=box(200, 200, 1100, 850),
    )
    assert not any(region.region_type == "DOOR_REGION" for region in regions)


def test_door_requires_leaf_and_host_inside_architecture():
    curve = _door_curve(x=100, y=100, r=90)
    lines = [
        _line("LEAF", (100, 190), (100, 105)),
        _line("HOST", (40, 100), (330, 100)),
    ]
    regions = ElementContextDetector().detect(
        drawing=_drawing(lines=lines, curves=[curve]),
        scale_profile=_profile(),
        architectural_polygon=box(20, 20, 1000, 800),
    )
    door = next(region for region in regions if region.region_type == "DOOR_REGION")
    assert door.metadata["validation_contract"] == "ARC_LEAF_HOST_ARCHITECTURE_V2"
    assert "LEAF" in door.member_line_ids
    assert "HOST" not in door.member_line_ids
    assert door.metadata["door_leaf_support"] >= 0.72
    assert door.metadata["door_host_support"] >= 0.22


def test_parallel_frame_with_host_wall_creates_window_region():
    frames = [
        _line("W1", (300, 300), (390, 300)),
        _line("W2", (300, 306), (390, 306)),
        _line("W3", (300, 312), (390, 312)),
    ]
    host = _line("HOST_LONG", (170, 294), (570, 294))
    regions = ElementContextDetector().detect(
        drawing=_drawing(lines=[*frames, host]),
        scale_profile=_profile(),
        architectural_polygon=box(50, 50, 1100, 850),
    )
    windows = [region for region in regions if region.region_type == "WINDOW_REGION"]
    assert windows
    assert {"W1", "W2", "W3"}.issubset(set(windows[0].member_line_ids))
    assert "HOST_LONG" not in windows[0].member_line_ids


def test_direct_member_support_uses_face_lineage_not_surface_id_only():
    candidate = _candidate(
        "C",
        (100, 100),
        (300, 100),
        face_ids=["REP_A", "REP_B"],
        metadata={
            "face_lineage_groups": [
                ["REP_A", "RAW_A"],
                ["REP_B", "RAW_B"],
            ],
            "lineage_line_ids": ["REP_A", "REP_B", "RAW_A", "RAW_B"],
        },
    )
    region = ContextRegion(
        id="R",
        region_type="FLOOR_FINISH_GRID_REGION",
        bbox=DrawingBBox(x_min=90, y_min=80, x_max=310, y_max=120),
        confidence=0.98,
        quarantine_enabled=True,
        member_line_ids=["RAW_A", "RAW_B"],
    )
    support = CandidateContextGate._direct_member_support(candidate=candidate, region=region)
    assert support == 1.0


def test_window_member_can_be_quarantined_while_host_wall_is_preserved():
    region = ContextRegion(
        id="WINDOW",
        region_type="WINDOW_REGION",
        bbox=DrawingBBox(x_min=290, y_min=285, x_max=400, y_max=325),
        confidence=0.9,
        quarantine_enabled=True,
        member_line_ids=["W1", "W2"],
        metadata={"element_role": "OPENING", "negative_mask": False},
    )
    frame = _candidate(
        "FRAME",
        (300, 305),
        (390, 305),
        face_ids=["REP1", "REP2"],
        metric=0.95,
        metadata={"face_lineage_groups": [["REP1", "W1"], ["REP2", "W2"]]},
    )
    host = _candidate("HOST", (220, 305), (500, 305), face_ids=["H1", "H2"], metric=1.0)
    result = CandidateContextGate().apply(candidates=[frame, host], regions=[region])
    decisions = {item.candidate_id: item for item in result.decisions}
    assert decisions["FRAME"].state == "QUARANTINE"
    assert decisions["HOST"].state == "ACTIVE"
    assert decisions["HOST"].context_risk == 0.0


def test_text_regions_stay_local_and_are_not_merged_into_giant_bbox():
    texts = [
        DrawingText(id="T1", text="A", bbox=DrawingBBox(x_min=100, y_min=100, x_max=130, y_max=120), sources=["PYMUPDF"]),
        DrawingText(id="T2", text="B", bbox=DrawingBBox(x_min=125, y_min=100, x_max=155, y_max=120), sources=["PYMUPDF"]),
    ]
    regions = ElementContextDetector().detect(
        drawing=_drawing(texts=texts),
        scale_profile=_profile(),
        architectural_polygon=box(0, 0, 1200, 900),
    )
    text_regions = [region for region in regions if region.region_type == "TEXT_SYMBOL_REGION"]
    assert len(text_regions) == 2


def test_track_consolidation_preserves_face_lineage_groups():
    first = _candidate(
        "C1", (100, 100), (180, 100), face_ids=["A1", "A2"],
        metadata={"face_lineage_groups": [["A1", "RAW_A1"], ["A2", "RAW_A2"]], "lineage_line_ids": ["RAW_A1", "RAW_A2"]},
    )
    second = _candidate(
        "C2", (185, 100), (260, 100), face_ids=["B1", "B2"],
        metadata={"face_lineage_groups": [["B1", "RAW_B1"], ["B2", "RAW_B2"]], "lineage_line_ids": ["RAW_B1", "RAW_B2"]},
    )
    merged = WallTrackConsolidator().consolidate(candidates=[first, second], width_px=1200, height_px=900)
    assert len(merged) == 1
    lineage = set(merged[0].metadata["lineage_line_ids"])
    assert {"RAW_A1", "RAW_A2", "RAW_B1", "RAW_B2"}.issubset(lineage)
    assert len(merged[0].metadata["face_lineage_groups"]) == 4
